// SPDX-License-Identifier: LicenseRef-AGPL-3.0-only-OpenSSL
//
// VisionPlay ⇄ Chiaki bridge.
//
// A thin C API over the chiaki-ng Remote Play core so Swift never has to manage
// Chiaki's large structs, unions, threads or function-pointer tables directly.
// Every callback below is invoked on a Chiaki-owned background thread; Swift
// callers must hop to their own queues/actors before touching UI state.

#ifndef VISIONPLAY_BRIDGE_H
#define VISIONPLAY_BRIDGE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include <chiaki/common.h>
#include <chiaki/controller.h>
#include <chiaki/regist.h>
#include <chiaki/discovery.h>
#include <chiaki/orientation.h>

#ifdef __cplusplus
extern "C" {
#endif

// MARK: - Library / logging

typedef void (*VPLogCallback)(int level, const char *message, void *user);

/// Initialise the Chiaki library once per process. Safe to call repeatedly.
ChiakiErrorCode vp_lib_init(void);

/// Route Chiaki log output to `cb`. `level_mask` uses CHIAKI_LOG_* bits.
void vp_set_log_callback(VPLogCallback cb, void *user, uint32_t level_mask);

const char *vp_error_string(ChiakiErrorCode err);

/// Path of the PEM CA bundle libcurl uses for HTTPS/WSS to PlayStation Network.
void vp_set_ca_bundle_path(const char *path);
const char *vp_curl_ca_bundle_path(void);

// MARK: - PlayStation Network (internet Remote Play)

typedef struct VPRemoteDevice
{
	char name[33];
	char duid_hex[65];        // device unique id, 32 bytes as hex
	bool remoteplay_enabled;
	bool ps5;
} VPRemoteDevice;

/// Internet Play: bind the PSN connection to fixed UDP ports (forward both on your router to
/// this device). 0 = random ports (default).
void vp_set_internet_ports(uint16_t control_port, uint16_t data_port);
uint16_t vp_holepunch_preferred_port(bool control);

/// Measures round-trip time to a console by timing discovery probes (UDP 9302/987).
/// Writes up to `count` samples in milliseconds to `rtt_ms_out` (-1 = no reply within
/// `timeout_ms`). Blocks for up to count × timeout_ms.
ChiakiErrorCode vp_measure_rtt(const char *ipv4, bool ps5, int count, int timeout_ms, double *rtt_ms_out);

/// Lists consoles on the PSN account (needs a valid OAuth access token).
ChiakiErrorCode vp_psn_list_devices(const char *psn_token, bool ps5, VPRemoteDevice *out, size_t max_count, size_t *count_out);

// MARK: - Discovery

typedef struct VPDiscoveredHost
{
	int state;                 // ChiakiDiscoveryHostState
	bool is_ps5;
	uint16_t host_request_port;
	const char *host_addr;
	const char *host_name;
	const char *host_type;
	const char *host_id;       // console MAC as hex, used as the stable console identifier
	const char *system_version;
	const char *running_app_name;
	const char *running_app_titleid;
} VPDiscoveredHost;

typedef void (*VPDiscoveryCallback)(const VPDiscoveredHost *host, void *user);

typedef struct VPDiscovery VPDiscovery;

/// Opens the discovery UDP socket and starts a background receive thread.
VPDiscovery *vp_discovery_create(VPDiscoveryCallback cb, void *user, ChiakiErrorCode *err_out);

/// Sends a SRCH probe to one IPv4 address (unicast), or to 255.255.255.255 when
/// `broadcast` is true. Unicast probes do not need Apple's multicast entitlement.
ChiakiErrorCode vp_discovery_probe(VPDiscovery *discovery, const char *ipv4, bool ps5, bool broadcast);

/// Stops the receive thread and closes the socket. `discovery` is invalid afterwards.
void vp_discovery_destroy(VPDiscovery *discovery);

/// Parses a raw discovery response (exposed for unit tests).
ChiakiErrorCode vp_discovery_parse(const char *response, size_t response_size, const char *sender_ipv4,
		VPDiscoveryCallback cb, void *user);

/// Sends a Wake-on-LAN style wakeup packet using the registration key as credential.
ChiakiErrorCode vp_wakeup(const char *host, const char regist_key[CHIAKI_SESSION_AUTH_SIZE], bool ps5);

// MARK: - Registration

typedef struct VPRegistResult
{
	int result;                     // 0 = success, 1 = failed, 2 = canceled
	int target;                     // ChiakiTarget
	char server_nickname[0x21];     // zero terminated
	uint8_t server_mac[6];
	char rp_regist_key[CHIAKI_SESSION_AUTH_SIZE];
	uint32_t rp_key_type;
	uint8_t rp_key[0x10];
	uint32_t console_pin;
} VPRegistResult;

typedef void (*VPRegistCallback)(const VPRegistResult *result, void *user);

typedef struct VPRegist VPRegist;

/// Starts PS5/PS4 registration. `psn_account_id` must be the 8-byte account id.
/// `pin` is the 8-digit code shown on the console (Settings › System › Remote Play › Pair Device).
VPRegist *vp_regist_start(const char *host, bool ps5, bool broadcast,
		const uint8_t psn_account_id[CHIAKI_PSN_ACCOUNT_ID_SIZE], uint32_t pin,
		VPRegistCallback cb, void *user, ChiakiErrorCode *err_out);

void vp_regist_cancel(VPRegist *regist);

/// Joins the registration thread and frees it. Must not be called from the callback.
void vp_regist_destroy(VPRegist *regist);

// MARK: - Streaming session

typedef enum VPEventKind
{
	VP_EVENT_CONNECTED = 0,
	VP_EVENT_QUIT = 1,              // a = ChiakiQuitReason, b = is_error, text = reason string
	VP_EVENT_LOGIN_PIN_REQUEST = 2, // a = pin_incorrect
	VP_EVENT_RUMBLE = 3,            // a = left (low freq), b = right (high freq)
	VP_EVENT_NICKNAME = 4,          // text = server nickname
	VP_EVENT_FEC_FAILURE = 5,       // a = frame index, b = idr requested
	VP_EVENT_LED_COLOR = 6,         // a = 0xRRGGBB
	VP_EVENT_PLAYER_INDEX = 7,      // a = index
	VP_EVENT_MOTION_RESET = 8,
	VP_EVENT_HOLEPUNCH = 9,         // a = finished (data connection)
	VP_EVENT_PSN_REGIST = 10,       // remote auto-registration finished
	VP_EVENT_OTHER = 99             // a = raw ChiakiEventType
} VPEventKind;

typedef struct VPSessionCallbacks
{
	void (*event)(int kind, int32_t a, int32_t b, const char *text, void *user);
	/// One complete Annex-B access unit. Return false if it could not be consumed
	/// (Chiaki will then request a new keyframe).
	bool (*video)(const uint8_t *buf, size_t size, int32_t frames_lost, bool frame_recovered, void *user);
	void (*audio_header)(uint32_t channels, uint32_t bits, uint32_t rate, uint32_t frame_size, void *user);
	/// One Opus packet.
	void (*audio_frame)(const uint8_t *buf, size_t size, void *user);
	void (*trigger_effects)(uint8_t type_left, const uint8_t *left10, uint8_t type_right, const uint8_t *right10, void *user);
	/// DualSense haptics stream (PS5 only): interleaved stereo int16 PCM, normally 30 frames
	/// (10 ms at 3 kHz). Left = left grip actuator, right = right grip actuator.
	void (*haptics_frame)(const int16_t *samples, size_t frames, void *user);
} VPSessionCallbacks;

typedef struct VPConnectConfig
{
	const char *host;
	bool ps5;
	char regist_key[CHIAKI_SESSION_AUTH_SIZE];
	uint8_t morning[0x10];          // rp_key from registration
	uint8_t psn_account_id[CHIAKI_PSN_ACCOUNT_ID_SIZE];
	int resolution_preset;          // ChiakiVideoResolutionPreset (1..4)
	int fps;                        // 30 or 60
	uint32_t bitrate_kbps;          // 0 = Chiaki preset default
	int codec;                      // ChiakiCodec
	bool auto_downgrade;
	bool enable_dualsense;
	double packet_loss_max;         // 0 = Chiaki default
} VPConnectConfig;

typedef struct VPSession VPSession;

VPSession *vp_session_create(const VPConnectConfig *config, VPSessionCallbacks callbacks, void *user, ChiakiErrorCode *err_out);
/// Internet session through PSN: the console is reached by NAT hole punching instead of
/// its LAN address. `config->host` is ignored. Call vp_session_connect_psn (blocking) and
/// then vp_session_start.
VPSession *vp_session_create_remote(const VPConnectConfig *config, const char *psn_token,
		const uint8_t *duid, size_t duid_len,
		VPSessionCallbacks callbacks, void *user, ChiakiErrorCode *err_out);
/// Creates the PSN session, exchanges network candidates and punches the control hole.
/// Blocks for up to ~30 s; call from a background thread.
ChiakiErrorCode vp_session_connect_psn(VPSession *session);
/// Aborts a running vp_session_connect_psn.
void vp_session_cancel_psn(VPSession *session);

ChiakiErrorCode vp_session_start(VPSession *session);
ChiakiErrorCode vp_session_stop(VPSession *session);
/// Stops (if needed), joins the session thread and frees everything.
/// Never call from inside a session callback.
void vp_session_destroy(VPSession *session);

ChiakiErrorCode vp_session_set_controller_state(VPSession *session, const ChiakiControllerState *state);
ChiakiErrorCode vp_session_request_idr(VPSession *session);
ChiakiErrorCode vp_session_set_login_pin(VPSession *session, const char *pin);
ChiakiErrorCode vp_session_go_home(VPSession *session);
ChiakiErrorCode vp_session_goto_bed(VPSession *session);

// Microphone: 48 kHz stereo int16, 480-frame (10 ms) blocks, Opus-encoded at the constant
// bitrate the Remote Play protocol requires (exactly 40 bytes per packet).
#define VP_MIC_SAMPLE_RATE 48000
#define VP_MIC_CHANNELS 2
#define VP_MIC_FRAMES_PER_PACKET 480

/// Tells the console a microphone is attached (once per session) and sets the mute state.
ChiakiErrorCode vp_session_set_microphone_enabled(VPSession *session, bool enabled);
/// Encodes and sends one 10 ms block (VP_MIC_FRAMES_PER_PACKET × VP_MIC_CHANNELS samples).
/// Returns false if the session is not streaming or the microphone is muted.
bool vp_session_send_microphone(VPSession *session, const int16_t *interleaved);

/// Returns the negotiated video profile once connected.
void vp_session_video_profile(VPSession *session, uint32_t *width, uint32_t *height, uint32_t *fps, uint32_t *bitrate, int *codec);

/// Measured round-trip time in microseconds (0 if unknown).
uint64_t vp_session_rtt_us(VPSession *session);

/// Packet loss ratio reported by the congestion controller in [0, 1].
double vp_session_packet_loss(VPSession *session);

#ifdef __cplusplus
}
#endif

#endif
