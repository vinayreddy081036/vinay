// SPDX-License-Identifier: LicenseRef-AGPL-3.0-only-OpenSSL
//
// VisionPlay ⇄ Chiaki bridge implementation. See vp_bridge.h.

#include "vp_bridge.h"

#include <chiaki/session.h>
#include <chiaki/log.h>
#include <chiaki/thread.h>
#include <chiaki/opusencoder.h>
#include <chiaki/remote/holepunch.h>

#include <arpa/inet.h>
#include <poll.h>
#include <time.h>
#include <unistd.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>

// chiaki/src/discovery.c exports this but it is not in the public header.
ChiakiErrorCode chiaki_discovery_srch_response_parse(ChiakiDiscoveryHost *response, struct sockaddr *addr,
		char *addr_buf, size_t addr_buf_size, char *buf, size_t buf_size);

// MARK: - Library / logging

static pthread_once_t g_init_once = PTHREAD_ONCE_INIT;
static ChiakiErrorCode g_init_result = CHIAKI_ERR_UNINITIALIZED;

static VPLogCallback g_log_cb = NULL;
static void *g_log_user = NULL;
static uint32_t g_log_mask = CHIAKI_LOG_ALL & ~CHIAKI_LOG_VERBOSE;

static void do_lib_init(void)
{
	g_init_result = chiaki_lib_init();
}

ChiakiErrorCode vp_lib_init(void)
{
	pthread_once(&g_init_once, do_lib_init);
	return g_init_result;
}

static void vp_log_forward(ChiakiLogLevel level, const char *msg, void *user)
{
	(void)user;
	VPLogCallback cb = g_log_cb;
	if(cb)
		cb((int)level, msg, g_log_user);
}

void vp_set_log_callback(VPLogCallback cb, void *user, uint32_t level_mask)
{
	g_log_user = user;
	g_log_mask = level_mask;
	g_log_cb = cb;
}

static void vp_log_init(ChiakiLog *log)
{
	chiaki_log_init(log, g_log_mask, vp_log_forward, NULL);
}

const char *vp_error_string(ChiakiErrorCode err)
{
	return chiaki_error_string(err);
}

static char *g_ca_bundle_path = NULL;

void vp_set_ca_bundle_path(const char *path)
{
	char *copy = path ? strdup(path) : NULL;
	char *old = g_ca_bundle_path;
	g_ca_bundle_path = copy;
	free(old);
}

// Called by the patched libcurl (Curl/lib/url.c) for every new handle.
const char *vp_curl_ca_bundle_path(void)
{
	return g_ca_bundle_path;
}

static volatile uint16_t g_internet_port_ctrl = 0;
static volatile uint16_t g_internet_port_data = 0;

void vp_set_internet_ports(uint16_t control_port, uint16_t data_port)
{
	g_internet_port_ctrl = control_port;
	g_internet_port_data = data_port;
}

uint16_t vp_holepunch_preferred_port(bool control)
{
	return control ? g_internet_port_ctrl : g_internet_port_data;
}

ChiakiErrorCode vp_psn_list_devices(const char *psn_token, bool ps5, VPRemoteDevice *out, size_t max_count, size_t *count_out)
{
	if(count_out) *count_out = 0;
	if(!psn_token || !out)
		return CHIAKI_ERR_INVALID_DATA;
	ChiakiErrorCode err = vp_lib_init();
	if(err != CHIAKI_ERR_SUCCESS)
		return err;
	ChiakiLog log;
	vp_log_init(&log);
	ChiakiHolepunchDeviceInfo *devices = NULL;
	size_t count = 0;
	err = chiaki_holepunch_list_devices(psn_token, ps5 ? CHIAKI_HOLEPUNCH_CONSOLE_TYPE_PS5 : CHIAKI_HOLEPUNCH_CONSOLE_TYPE_PS4,
			&devices, &count, &log);
	if(err != CHIAKI_ERR_SUCCESS)
		return err;
	size_t n = count < max_count ? count : max_count;
	for(size_t i = 0; i < n; i++)
	{
		memset(&out[i], 0, sizeof(out[i]));
		memcpy(out[i].name, devices[i].device_name, sizeof(devices[i].device_name));
		out[i].name[sizeof(out[i].name) - 1] = '\0';
		for(size_t b = 0; b < sizeof(devices[i].device_uid); b++)
			snprintf(out[i].duid_hex + b * 2, 3, "%02x", devices[i].device_uid[b]);
		out[i].remoteplay_enabled = devices[i].remoteplay_enabled;
		out[i].ps5 = devices[i].type == CHIAKI_HOLEPUNCH_CONSOLE_TYPE_PS5;
	}
	chiaki_holepunch_free_device_list(&devices);
	if(count_out) *count_out = n;
	return CHIAKI_ERR_SUCCESS;
}

// MARK: - Discovery

struct VPDiscovery
{
	ChiakiLog log;
	ChiakiDiscovery discovery;
	ChiakiDiscoveryThread thread;
	VPDiscoveryCallback cb;
	void *user;
};

static void fill_discovered(VPDiscoveredHost *out, ChiakiDiscoveryHost *host)
{
	memset(out, 0, sizeof(*out));
	out->state = (int)host->state;
	out->is_ps5 = chiaki_discovery_host_is_ps5(host);
	out->host_request_port = host->host_request_port;
	out->host_addr = host->host_addr;
	out->host_name = host->host_name;
	out->host_type = host->host_type;
	out->host_id = host->host_id;
	out->system_version = host->system_version;
	out->running_app_name = host->running_app_name;
	out->running_app_titleid = host->running_app_titleid;
}

static void discovery_cb(ChiakiDiscoveryHost *host, void *user)
{
	VPDiscovery *d = user;
	if(!d->cb)
		return;
	VPDiscoveredHost out;
	fill_discovered(&out, host);
	d->cb(&out, d->user);
}

VPDiscovery *vp_discovery_create(VPDiscoveryCallback cb, void *user, ChiakiErrorCode *err_out)
{
	ChiakiErrorCode err = vp_lib_init();
	if(err != CHIAKI_ERR_SUCCESS)
	{
		if(err_out) *err_out = err;
		return NULL;
	}

	VPDiscovery *d = calloc(1, sizeof(VPDiscovery));
	if(!d)
	{
		if(err_out) *err_out = CHIAKI_ERR_MEMORY;
		return NULL;
	}
	vp_log_init(&d->log);
	d->cb = cb;
	d->user = user;

	err = chiaki_discovery_init(&d->discovery, &d->log, AF_INET);
	if(err != CHIAKI_ERR_SUCCESS)
	{
		free(d);
		if(err_out) *err_out = err;
		return NULL;
	}

	err = chiaki_discovery_thread_start(&d->thread, &d->discovery, discovery_cb, d);
	if(err != CHIAKI_ERR_SUCCESS)
	{
		chiaki_discovery_fini(&d->discovery);
		free(d);
		if(err_out) *err_out = err;
		return NULL;
	}

	if(err_out) *err_out = CHIAKI_ERR_SUCCESS;
	return d;
}

ChiakiErrorCode vp_discovery_probe(VPDiscovery *d, const char *ipv4, bool ps5, bool broadcast)
{
	if(!d)
		return CHIAKI_ERR_INVALID_DATA;

	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(ps5 ? CHIAKI_DISCOVERY_PORT_PS5 : CHIAKI_DISCOVERY_PORT_PS4);
	if(broadcast)
		addr.sin_addr.s_addr = htonl(INADDR_BROADCAST);
	else if(!ipv4 || inet_pton(AF_INET, ipv4, &addr.sin_addr) != 1)
		return CHIAKI_ERR_PARSE_ADDR;

	ChiakiDiscoveryPacket packet;
	memset(&packet, 0, sizeof(packet));
	packet.cmd = CHIAKI_DISCOVERY_CMD_SRCH;
	packet.protocol_version = ps5 ? CHIAKI_DISCOVERY_PROTOCOL_VERSION_PS5 : CHIAKI_DISCOVERY_PROTOCOL_VERSION_PS4;
	return chiaki_discovery_send(&d->discovery, &packet, (struct sockaddr *)&addr, sizeof(addr));
}

void vp_discovery_destroy(VPDiscovery *d)
{
	if(!d)
		return;
	chiaki_discovery_thread_stop(&d->thread);
	chiaki_discovery_fini(&d->discovery);
	free(d);
}

ChiakiErrorCode vp_discovery_parse(const char *response, size_t response_size, const char *sender_ipv4,
		VPDiscoveryCallback cb, void *user)
{
	if(!response || !sender_ipv4)
		return CHIAKI_ERR_INVALID_DATA;

	char buf[512];
	if(response_size > sizeof(buf) - 1)
		response_size = sizeof(buf) - 1;
	memcpy(buf, response, response_size);
	buf[response_size] = '\0';

	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	if(inet_pton(AF_INET, sender_ipv4, &addr.sin_addr) != 1)
		return CHIAKI_ERR_PARSE_ADDR;

	char addr_buf[64];
	ChiakiDiscoveryHost host;
	memset(&host, 0, sizeof(host));
	ChiakiErrorCode err = chiaki_discovery_srch_response_parse(&host, (struct sockaddr *)&addr,
			addr_buf, sizeof(addr_buf), buf, response_size);
	if(err != CHIAKI_ERR_SUCCESS)
		return err;

	if(cb)
	{
		VPDiscoveredHost out;
		fill_discovered(&out, &host);
		cb(&out, user);
	}
	return CHIAKI_ERR_SUCCESS;
}

static double vp_now_ms(void)
{
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
}

ChiakiErrorCode vp_measure_rtt(const char *ipv4, bool ps5, int count, int timeout_ms, double *rtt_ms_out)
{
	if(!ipv4 || !rtt_ms_out || count <= 0)
		return CHIAKI_ERR_INVALID_DATA;
	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(ps5 ? CHIAKI_DISCOVERY_PORT_PS5 : CHIAKI_DISCOVERY_PORT_PS4);
	if(inet_pton(AF_INET, ipv4, &addr.sin_addr) != 1)
		return CHIAKI_ERR_PARSE_ADDR;

	int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(fd < 0)
		return CHIAKI_ERR_NETWORK;
	if(connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
	{
		close(fd);
		return CHIAKI_ERR_NETWORK;
	}

	ChiakiDiscoveryPacket packet;
	memset(&packet, 0, sizeof(packet));
	packet.cmd = CHIAKI_DISCOVERY_CMD_SRCH;
	packet.protocol_version = ps5 ? CHIAKI_DISCOVERY_PROTOCOL_VERSION_PS5 : CHIAKI_DISCOVERY_PROTOCOL_VERSION_PS4;
	char buf[512];
	int len = chiaki_discovery_packet_fmt(buf, sizeof(buf), &packet);
	if(len <= 0)
	{
		close(fd);
		return CHIAKI_ERR_UNKNOWN;
	}

	for(int i = 0; i < count; i++)
	{
		rtt_ms_out[i] = -1;
		// Drain stale replies from earlier probes.
		char drain[1024];
		while(recv(fd, drain, sizeof(drain), MSG_DONTWAIT) > 0) {}
		double start = vp_now_ms();
		if(send(fd, buf, (size_t)len, 0) < 0)
			continue;
		struct pollfd pfd = { .fd = fd, .events = POLLIN };
		int remaining = timeout_ms;
		while(remaining > 0)
		{
			int r = poll(&pfd, 1, remaining);
			if(r <= 0)
				break;
			char reply[1024];
			ssize_t n = recv(fd, reply, sizeof(reply), 0);
			if(n > 0 && n >= 8 && memcmp(reply, "HTTP/1.1", 8) == 0)
			{
				rtt_ms_out[i] = vp_now_ms() - start;
				break;
			}
			remaining = timeout_ms - (int)(vp_now_ms() - start);
		}
		// Space samples out so they reflect jitter rather than a single burst.
		if(i + 1 < count)
			usleep(50 * 1000);
	}
	close(fd);
	return CHIAKI_ERR_SUCCESS;
}

ChiakiErrorCode vp_wakeup(const char *host, const char regist_key[CHIAKI_SESSION_AUTH_SIZE], bool ps5)
{
	ChiakiErrorCode err = vp_lib_init();
	if(err != CHIAKI_ERR_SUCCESS)
		return err;

	// The wakeup credential is the registration key's ASCII hex digits read as a number.
	char key_str[CHIAKI_SESSION_AUTH_SIZE + 1];
	memcpy(key_str, regist_key, CHIAKI_SESSION_AUTH_SIZE);
	key_str[CHIAKI_SESSION_AUTH_SIZE] = '\0';
	uint64_t credential = strtoull(key_str, NULL, 16);

	ChiakiLog log;
	vp_log_init(&log);
	return chiaki_discovery_wakeup(&log, NULL, host, credential, ps5);
}

// MARK: - Registration

struct VPRegist
{
	ChiakiLog log;
	ChiakiRegist regist;
	char *host;
	VPRegistCallback cb;
	void *user;
	bool started;
};

static void regist_cb(ChiakiRegistEvent *event, void *user)
{
	VPRegist *r = user;
	VPRegistResult result;
	memset(&result, 0, sizeof(result));
	switch(event->type)
	{
		case CHIAKI_REGIST_EVENT_TYPE_FINISHED_SUCCESS:
			result.result = 0;
			break;
		case CHIAKI_REGIST_EVENT_TYPE_FINISHED_CANCELED:
			result.result = 2;
			break;
		case CHIAKI_REGIST_EVENT_TYPE_FINISHED_FAILED:
		default:
			result.result = 1;
			break;
	}
	if(result.result == 0 && event->registered_host)
	{
		ChiakiRegisteredHost *h = event->registered_host;
		result.target = (int)h->target;
		memcpy(result.server_nickname, h->server_nickname, sizeof(h->server_nickname));
		result.server_nickname[sizeof(result.server_nickname) - 1] = '\0';
		memcpy(result.server_mac, h->server_mac, sizeof(result.server_mac));
		memcpy(result.rp_regist_key, h->rp_regist_key, sizeof(result.rp_regist_key));
		result.rp_key_type = h->rp_key_type;
		memcpy(result.rp_key, h->rp_key, sizeof(result.rp_key));
		result.console_pin = h->console_pin;
	}
	if(r->cb)
		r->cb(&result, r->user);
}

VPRegist *vp_regist_start(const char *host, bool ps5, bool broadcast,
		const uint8_t psn_account_id[CHIAKI_PSN_ACCOUNT_ID_SIZE], uint32_t pin,
		VPRegistCallback cb, void *user, ChiakiErrorCode *err_out)
{
	ChiakiErrorCode err = vp_lib_init();
	if(err != CHIAKI_ERR_SUCCESS)
	{
		if(err_out) *err_out = err;
		return NULL;
	}
	if(!host)
	{
		if(err_out) *err_out = CHIAKI_ERR_INVALID_DATA;
		return NULL;
	}

	VPRegist *r = calloc(1, sizeof(VPRegist));
	if(!r)
	{
		if(err_out) *err_out = CHIAKI_ERR_MEMORY;
		return NULL;
	}
	vp_log_init(&r->log);
	r->host = strdup(host);
	r->cb = cb;
	r->user = user;

	ChiakiRegistInfo info;
	memset(&info, 0, sizeof(info));
	// PS5 firmware reports itself with the latest PS5 target; Chiaki adapts on the response.
	info.target = ps5 ? CHIAKI_TARGET_PS5_1 : CHIAKI_TARGET_PS4_10;
	info.host = r->host;
	info.broadcast = broadcast;
	info.psn_online_id = NULL; // PS4 < 7.0 only
	memcpy(info.psn_account_id, psn_account_id, CHIAKI_PSN_ACCOUNT_ID_SIZE);
	info.pin = pin;
	info.console_pin = 0;
	info.holepunch_info = NULL;
	info.rudp = NULL;

	err = chiaki_regist_start(&r->regist, &r->log, &info, regist_cb, r);
	if(err != CHIAKI_ERR_SUCCESS)
	{
		free(r->host);
		free(r);
		if(err_out) *err_out = err;
		return NULL;
	}
	r->started = true;
	if(err_out) *err_out = CHIAKI_ERR_SUCCESS;
	return r;
}

void vp_regist_cancel(VPRegist *r)
{
	if(r && r->started)
		chiaki_regist_stop(&r->regist);
}

void vp_regist_destroy(VPRegist *r)
{
	if(!r)
		return;
	if(r->started)
		chiaki_regist_fini(&r->regist); // joins the thread
	free(r->host);
	free(r);
}

// MARK: - Session

struct VPSession
{
	ChiakiLog log;
	ChiakiSession session;
	VPSessionCallbacks cb;
	void *user;
	char *host;
	bool started;
	bool stopped;
	ChiakiHolepunchSession holepunch;
	uint8_t duid[32];
	size_t duid_len;
	bool remote_ps5;
	ChiakiOpusEncoder mic_encoder;
	bool mic_encoder_ready;
	bool mic_connected;
	bool mic_enabled;
	ChiakiMutex mic_mutex;
};

static void session_haptics_frame_cb(uint8_t *buf, size_t buf_size, void *user)
{
	VPSession *s = user;
	if(!s->cb.haptics_frame || buf_size < 4 || (buf_size % 4) != 0)
		return;
	s->cb.haptics_frame((const int16_t *)buf, buf_size / 4, s->user);
}

static void session_event_cb(ChiakiEvent *event, void *user)
{
	VPSession *s = user;
	if(!s->cb.event && event->type != CHIAKI_EVENT_TRIGGER_EFFECTS)
		return;

	switch(event->type)
	{
		case CHIAKI_EVENT_CONNECTED:
			s->cb.event(VP_EVENT_CONNECTED, 0, 0, NULL, s->user);
			break;
		case CHIAKI_EVENT_QUIT:
			s->cb.event(VP_EVENT_QUIT, (int32_t)event->quit.reason,
					chiaki_quit_reason_is_error(event->quit.reason) ? 1 : 0,
					event->quit.reason_str ? event->quit.reason_str : chiaki_quit_reason_string(event->quit.reason),
					s->user);
			break;
		case CHIAKI_EVENT_LOGIN_PIN_REQUEST:
			s->cb.event(VP_EVENT_LOGIN_PIN_REQUEST, event->login_pin_request.pin_incorrect ? 1 : 0, 0, NULL, s->user);
			break;
		case CHIAKI_EVENT_RUMBLE:
			s->cb.event(VP_EVENT_RUMBLE, event->rumble.left, event->rumble.right, NULL, s->user);
			break;
		case CHIAKI_EVENT_NICKNAME_RECEIVED:
		{
			char nick[sizeof(event->server_nickname) + 1];
			memcpy(nick, event->server_nickname, sizeof(event->server_nickname));
			nick[sizeof(event->server_nickname)] = '\0';
			s->cb.event(VP_EVENT_NICKNAME, 0, 0, nick, s->user);
			break;
		}
		case CHIAKI_EVENT_VIDEO_FEC_FAILURE:
			s->cb.event(VP_EVENT_FEC_FAILURE, event->video_fec_failure.frame_index,
					event->video_fec_failure.idr_request_sent ? 1 : 0, NULL, s->user);
			break;
		case CHIAKI_EVENT_LED_COLOR:
			s->cb.event(VP_EVENT_LED_COLOR,
					((int32_t)event->led_state[0] << 16) | ((int32_t)event->led_state[1] << 8) | event->led_state[2],
					0, NULL, s->user);
			break;
		case CHIAKI_EVENT_PLAYER_INDEX:
			s->cb.event(VP_EVENT_PLAYER_INDEX, event->player_index, 0, NULL, s->user);
			break;
		case CHIAKI_EVENT_MOTION_RESET:
			s->cb.event(VP_EVENT_MOTION_RESET, 0, 0, NULL, s->user);
			break;
		case CHIAKI_EVENT_HOLEPUNCH:
			s->cb.event(VP_EVENT_HOLEPUNCH, event->data_holepunch.finished ? 1 : 0, 0, NULL, s->user);
			break;
		case CHIAKI_EVENT_REGIST:
			s->cb.event(VP_EVENT_PSN_REGIST, 0, 0, NULL, s->user);
			break;
		case CHIAKI_EVENT_TRIGGER_EFFECTS:
			if(s->cb.trigger_effects)
				s->cb.trigger_effects(event->trigger_effects.type_left, event->trigger_effects.left,
						event->trigger_effects.type_right, event->trigger_effects.right, s->user);
			break;
		default:
			s->cb.event(VP_EVENT_OTHER, (int32_t)event->type, 0, NULL, s->user);
			break;
	}
}

static bool session_video_cb(uint8_t *buf, size_t buf_size, int32_t frames_lost, bool frame_recovered, void *user)
{
	VPSession *s = user;
	if(!s->cb.video)
		return true;
	return s->cb.video(buf, buf_size, frames_lost, frame_recovered, s->user);
}

static void session_audio_header_cb(ChiakiAudioHeader *header, void *user)
{
	VPSession *s = user;
	if(s->cb.audio_header)
		s->cb.audio_header(header->channels, header->bits, header->rate, header->frame_size, s->user);
}

static void session_audio_frame_cb(uint8_t *buf, size_t buf_size, void *user)
{
	VPSession *s = user;
	if(s->cb.audio_frame)
		s->cb.audio_frame(buf, buf_size, s->user);
}

/* holepunch_taken (optional) is set to true once chiaki_session_init has been called: from then
 * on the session owns the holepunch session and frees it itself, even if init fails. */
static VPSession *session_create_internal(const VPConnectConfig *config, ChiakiHolepunchSession holepunch,
		VPSessionCallbacks callbacks, void *user, ChiakiErrorCode *err_out, bool *holepunch_taken);

static ChiakiLog g_remote_log;
static pthread_once_t g_remote_log_once = PTHREAD_ONCE_INIT;
static void remote_log_init(void) { vp_log_init(&g_remote_log); }

VPSession *vp_session_create(const VPConnectConfig *config, VPSessionCallbacks callbacks, void *user, ChiakiErrorCode *err_out)
{
	return session_create_internal(config, NULL, callbacks, user, err_out, NULL);
}

VPSession *vp_session_create_remote(const VPConnectConfig *config, const char *psn_token,
		const uint8_t *duid, size_t duid_len,
		VPSessionCallbacks callbacks, void *user, ChiakiErrorCode *err_out)
{
	ChiakiErrorCode err = vp_lib_init();
	if(err != CHIAKI_ERR_SUCCESS || !config || !psn_token || !duid || duid_len == 0 || duid_len > 32)
	{
		if(err_out) *err_out = err != CHIAKI_ERR_SUCCESS ? err : CHIAKI_ERR_INVALID_DATA;
		return NULL;
	}
	// The holepunch session keeps a pointer to this log, so it must outlive it: use a
	// process-lifetime log for remote sessions.
	pthread_once(&g_remote_log_once, remote_log_init);
	ChiakiHolepunchSession hp = chiaki_holepunch_session_init(psn_token, &g_remote_log);
	if(!hp)
	{
		if(err_out) *err_out = CHIAKI_ERR_MEMORY;
		return NULL;
	}
	VPConnectConfig remote_config = *config;
	remote_config.host = "psn-remote";
	bool hp_taken = false;
	VPSession *s = session_create_internal(&remote_config, hp, callbacks, user, err_out, &hp_taken);
	if(!s)
	{
		// If chiaki_session_init already ran, it freed hp on its error path: don't free it twice.
		if(!hp_taken)
			chiaki_holepunch_session_fini(hp);
		return NULL;
	}
	s->holepunch = hp;
	memcpy(s->duid, duid, duid_len);
	s->duid_len = duid_len;
	s->remote_ps5 = config->ps5;
	return s;
}

ChiakiErrorCode vp_session_connect_psn(VPSession *s)
{
	if(!s || !s->holepunch)
		return CHIAKI_ERR_INVALID_DATA;
	ChiakiHolepunchSession hp = s->holepunch;
	ChiakiErrorCode err = chiaki_holepunch_upnp_discover(hp);
	if(err != CHIAKI_ERR_SUCCESS)
		return err;
	err = chiaki_holepunch_session_create(hp);
	if(err != CHIAKI_ERR_SUCCESS)
		return err;
	err = holepunch_session_create_offer(hp);
	if(err != CHIAKI_ERR_SUCCESS)
		return err;
	err = chiaki_holepunch_session_start(hp, s->duid,
			s->remote_ps5 ? CHIAKI_HOLEPUNCH_CONSOLE_TYPE_PS5 : CHIAKI_HOLEPUNCH_CONSOLE_TYPE_PS4);
	if(err != CHIAKI_ERR_SUCCESS)
		return err;
	return chiaki_holepunch_session_punch_hole(hp, CHIAKI_HOLEPUNCH_PORT_TYPE_CTRL);
}

void vp_session_cancel_psn(VPSession *s)
{
	if(s && s->holepunch)
		chiaki_holepunch_main_thread_cancel(s->holepunch, true);
}

static VPSession *session_create_internal(const VPConnectConfig *config, ChiakiHolepunchSession holepunch,
		VPSessionCallbacks callbacks, void *user, ChiakiErrorCode *err_out, bool *holepunch_taken)
{
	ChiakiErrorCode err = vp_lib_init();
	if(err != CHIAKI_ERR_SUCCESS)
	{
		if(err_out) *err_out = err;
		return NULL;
	}
	if(!config || !config->host)
	{
		if(err_out) *err_out = CHIAKI_ERR_INVALID_DATA;
		return NULL;
	}

	VPSession *s = calloc(1, sizeof(VPSession));
	if(!s)
	{
		if(err_out) *err_out = CHIAKI_ERR_MEMORY;
		return NULL;
	}
	vp_log_init(&s->log);
	s->cb = callbacks;
	s->user = user;
	s->host = strdup(config->host);

	ChiakiConnectInfo info;
	memset(&info, 0, sizeof(info));
	info.ps5 = config->ps5;
	info.host = s->host;
	memcpy(info.regist_key, config->regist_key, sizeof(info.regist_key));
	memcpy(info.morning, config->morning, sizeof(info.morning));

	int res = config->resolution_preset;
	if(res < CHIAKI_VIDEO_RESOLUTION_PRESET_360p || res > CHIAKI_VIDEO_RESOLUTION_PRESET_1080p)
		res = CHIAKI_VIDEO_RESOLUTION_PRESET_1080p;
	ChiakiVideoFPSPreset fps = config->fps == 30 ? CHIAKI_VIDEO_FPS_PRESET_30 : CHIAKI_VIDEO_FPS_PRESET_60;
	chiaki_connect_video_profile_preset(&info.video_profile, (ChiakiVideoResolutionPreset)res, fps);
	if(config->bitrate_kbps)
		info.video_profile.bitrate = config->bitrate_kbps;
	info.video_profile.codec = (ChiakiCodec)config->codec;
	if(!config->ps5 && info.video_profile.codec != CHIAKI_CODEC_H264)
		info.video_profile.codec = CHIAKI_CODEC_H264; // PS4 is H.264 only

	info.video_profile_auto_downgrade = config->auto_downgrade;
	info.enable_keyboard = false;
	info.enable_dualsense = config->enable_dualsense;
	info.audio_video_disabled = 0;
	info.auto_regist = false;
	info.holepunch_session = holepunch;
	info.rudp_sock = NULL;
	memcpy(info.psn_account_id, config->psn_account_id, sizeof(info.psn_account_id));
	info.packet_loss_max = config->packet_loss_max > 0 ? config->packet_loss_max : 0.05;
	info.enable_idr_on_fec_failure = true;

	err = chiaki_session_init(&s->session, &info, &s->log);
	if(holepunch_taken)
		*holepunch_taken = true;
	if(err != CHIAKI_ERR_SUCCESS)
	{
		free(s->host);
		free(s);
		if(err_out) *err_out = err;
		return NULL;
	}

	chiaki_session_set_event_cb(&s->session, session_event_cb, s);
	chiaki_session_set_video_sample_cb(&s->session, session_video_cb, s);

	ChiakiAudioSink sink;
	memset(&sink, 0, sizeof(sink));
	sink.user = s;
	sink.header_cb = session_audio_header_cb;
	sink.frame_cb = session_audio_frame_cb;
	chiaki_session_set_audio_sink(&s->session, &sink);

	if(config->ps5)
	{
		ChiakiAudioSink haptics;
		memset(&haptics, 0, sizeof(haptics));
		haptics.user = s;
		haptics.frame_cb = session_haptics_frame_cb;
		chiaki_session_set_haptics_sink(&s->session, &haptics);
	}

	// Microphone encoder (same setup as chiaki-ng's GUI: stereo, 16 bit, 48 kHz, 480-sample frames).
	chiaki_mutex_init(&s->mic_mutex, false);
	chiaki_opus_encoder_init(&s->mic_encoder, &s->log);
	ChiakiAudioHeader mic_header;
	chiaki_audio_header_set(&mic_header, VP_MIC_CHANNELS, 16, VP_MIC_SAMPLE_RATE, VP_MIC_FRAMES_PER_PACKET);
	chiaki_opus_encoder_header(&mic_header, &s->mic_encoder, &s->session);
	s->mic_encoder_ready = s->mic_encoder.opus_encoder != NULL && s->mic_encoder.audio_sender != NULL;

	if(err_out) *err_out = CHIAKI_ERR_SUCCESS;
	return s;
}

ChiakiErrorCode vp_session_start(VPSession *s)
{
	if(!s || s->started)
		return CHIAKI_ERR_INVALID_DATA;
	ChiakiErrorCode err = chiaki_session_start(&s->session);
	if(err == CHIAKI_ERR_SUCCESS)
		s->started = true;
	return err;
}

ChiakiErrorCode vp_session_stop(VPSession *s)
{
	if(!s || !s->started || s->stopped)
		return CHIAKI_ERR_SUCCESS;
	s->stopped = true;
	return chiaki_session_stop(&s->session);
}

void vp_session_destroy(VPSession *s)
{
	if(!s)
		return;
	if(s->started)
	{
		if(!s->stopped)
		{
			s->stopped = true;
			chiaki_session_stop(&s->session);
		}
		chiaki_session_join(&s->session);
	}
	chiaki_mutex_lock(&s->mic_mutex);
	s->mic_enabled = false;
	s->mic_encoder_ready = false;
	chiaki_opus_encoder_fini(&s->mic_encoder);
	chiaki_mutex_unlock(&s->mic_mutex);
	chiaki_mutex_fini(&s->mic_mutex);
	chiaki_session_fini(&s->session);
	free(s->host);
	free(s);
}

ChiakiErrorCode vp_session_set_controller_state(VPSession *s, const ChiakiControllerState *state)
{
	if(!s || !state || !s->started)
		return CHIAKI_ERR_INVALID_DATA;
	ChiakiControllerState copy = *state;
	return chiaki_session_set_controller_state(&s->session, &copy);
}

ChiakiErrorCode vp_session_request_idr(VPSession *s)
{
	if(!s || !s->started)
		return CHIAKI_ERR_INVALID_DATA;
	return chiaki_session_request_idr(&s->session);
}

ChiakiErrorCode vp_session_set_login_pin(VPSession *s, const char *pin)
{
	if(!s || !pin)
		return CHIAKI_ERR_INVALID_DATA;
	return chiaki_session_set_login_pin(&s->session, (const uint8_t *)pin, strlen(pin));
}

ChiakiErrorCode vp_session_go_home(VPSession *s)
{
	if(!s || !s->started)
		return CHIAKI_ERR_INVALID_DATA;
	return chiaki_session_go_home(&s->session);
}

ChiakiErrorCode vp_session_goto_bed(VPSession *s)
{
	if(!s || !s->started)
		return CHIAKI_ERR_INVALID_DATA;
	return chiaki_session_goto_bed(&s->session);
}

ChiakiErrorCode vp_session_set_microphone_enabled(VPSession *s, bool enabled)
{
	if(!s || !s->started || s->stopped)
		return CHIAKI_ERR_INVALID_DATA;
	chiaki_mutex_lock(&s->mic_mutex);
	ChiakiErrorCode err = CHIAKI_ERR_SUCCESS;
	if(!s->mic_encoder_ready)
		err = CHIAKI_ERR_UNINITIALIZED;
	else
	{
		if(enabled && !s->mic_connected)
		{
			err = chiaki_session_connect_microphone(&s->session);
			if(err == CHIAKI_ERR_SUCCESS)
				s->mic_connected = true;
		}
		if(err == CHIAKI_ERR_SUCCESS && s->mic_connected)
		{
			// The console's flag is "muted".
			err = chiaki_session_toggle_microphone(&s->session, !enabled);
			if(err == CHIAKI_ERR_SUCCESS)
				s->mic_enabled = enabled;
		}
	}
	chiaki_mutex_unlock(&s->mic_mutex);
	return err;
}

bool vp_session_send_microphone(VPSession *s, const int16_t *interleaved)
{
	if(!s || !interleaved)
		return false;
	bool sent = false;
	chiaki_mutex_lock(&s->mic_mutex);
	if(s->mic_enabled && s->mic_encoder_ready && !s->stopped)
	{
		chiaki_opus_encoder_frame((int16_t *)interleaved, &s->mic_encoder);
		sent = true;
	}
	chiaki_mutex_unlock(&s->mic_mutex);
	return sent;
}

void vp_session_video_profile(VPSession *s, uint32_t *width, uint32_t *height, uint32_t *fps, uint32_t *bitrate, int *codec)
{
	if(!s)
		return;
	const ChiakiConnectVideoProfile *p = &s->session.connect_info.video_profile;
	if(width) *width = p->width;
	if(height) *height = p->height;
	if(fps) *fps = p->max_fps;
	if(bitrate) *bitrate = p->bitrate;
	if(codec) *codec = (int)p->codec;
}

uint64_t vp_session_rtt_us(VPSession *s)
{
	return s ? s->session.rtt_us : 0;
}

double vp_session_packet_loss(VPSession *s)
{
	if(!s)
		return 0.0;
	return s->session.stream_connection.congestion_control.packet_loss;
}
