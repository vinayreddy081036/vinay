// SPDX-License-Identifier: LicenseRef-AGPL-3.0-only-OpenSSL
// VisionPlay: hand-written replacement for the CMake-generated config.h.
// libopus (Opus target) is used for the microphone encoder; game audio is decoded by AudioToolbox.
#ifndef CHIAKI_CONFIG_H
#define CHIAKI_CONFIG_H

#define CHIAKI_LIB_ENABLE_OPUS 1
#define CHIAKI_LIB_ENABLE_PI_DECODER 0
#define CHIAKI_LIB_ENABLE_FFMPEG_DECODER 0

#endif
