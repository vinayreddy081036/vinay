import Foundation
import Security

enum KeychainError: Error, Equatable {
    case unexpectedStatus(OSStatus)
    case encodingFailed
    case decodingFailed
}

/// Stores Remote Play registration secrets (regist key, rp key, PSN account id)
/// as generic-password items. Items are device-only and available after first unlock,
/// so they are never synced to iCloud or included in unencrypted backups.
struct KeychainStore: Sendable {
    let service: String

    init(service: String = "com.visionplay.credentials") {
        self.service = service
    }

    private func baseQuery(account: String) -> [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
    }

    func setData(_ data: Data, account: String) throws {
        var query = baseQuery(account: account)
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
        ]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            query.merge(attributes) { _, new in new }
            let addStatus = SecItemAdd(query as CFDictionary, nil)
            guard addStatus == errSecSuccess else { throw KeychainError.unexpectedStatus(addStatus) }
        } else if status != errSecSuccess {
            throw KeychainError.unexpectedStatus(status)
        }
    }

    func data(account: String) throws -> Data? {
        var query = baseQuery(account: account)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess else { throw KeychainError.unexpectedStatus(status) }
        return result as? Data
    }

    func delete(account: String) throws {
        let status = SecItemDelete(baseQuery(account: account) as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw KeychainError.unexpectedStatus(status)
        }
    }

    // MARK: Typed helpers

    private static func consoleAccount(_ consoleID: String) -> String { "console.\(consoleID)" }
    private static let psnAccountKey = "psn.accountID"

    func saveCredentials(_ credentials: ConsoleCredentials, consoleID: String) throws {
        guard let data = try? JSONEncoder().encode(credentials) else { throw KeychainError.encodingFailed }
        try setData(data, account: Self.consoleAccount(consoleID))
    }

    func credentials(consoleID: String) throws -> ConsoleCredentials? {
        guard let data = try data(account: Self.consoleAccount(consoleID)) else { return nil }
        guard let decoded = try? JSONDecoder().decode(ConsoleCredentials.self, from: data) else {
            throw KeychainError.decodingFailed
        }
        return decoded
    }

    func deleteCredentials(consoleID: String) throws {
        try delete(account: Self.consoleAccount(consoleID))
    }

    /// The 8-byte PSN account id is reused for registering additional consoles.
    func savePSNAccountID(_ accountID: Data) throws {
        try setData(accountID, account: Self.psnAccountKey)
    }

    func psnAccountID() throws -> Data? {
        try data(account: Self.psnAccountKey)
    }

    func deletePSNAccountID() throws {
        try delete(account: Self.psnAccountKey)
    }
}
