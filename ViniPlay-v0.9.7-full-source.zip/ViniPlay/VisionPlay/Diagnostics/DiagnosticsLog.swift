import Foundation
import Observation
import os

/// In-memory ring of recent log lines for the Connection Diagnostics screen.
/// Also mirrors everything into the unified logging system (subsystem "VisionPlay").
@Observable
final class DiagnosticsLog: @unchecked Sendable {
    struct Entry: Identifiable, Sendable {
        enum Level: String, Sendable { case debug = "DEBUG", info = "INFO", warning = "WARN", error = "ERROR" }
        let id = UUID()
        let date: Date
        let level: Level
        let category: String
        let message: String
    }

    static let shared = DiagnosticsLog()

    private(set) var entries: [Entry] = []
    @ObservationIgnored private let lock = NSLock()
    @ObservationIgnored private var pending: [Entry] = []
    @ObservationIgnored private var flushScheduled = false
    @ObservationIgnored private let capacity = 600
    @ObservationIgnored private let logger = Logger(subsystem: "VisionPlay", category: "app")
    /// Sees every line as it is logged (any thread). Used to follow connection progress.
    @ObservationIgnored var lineObserver: (@Sendable (Entry.Level, String, String) -> Void)?
    /// Everything logged since `markAttemptStart()`, for "Copy Log" (capped).
    @ObservationIgnored private var attemptLines: [String] = []
    @ObservationIgnored private let attemptCapacity = 1500

    func log(_ level: Entry.Level, _ category: String, _ message: String) {
        let entry = Entry(date: Date(), level: level, category: category, message: message)
        switch level {
        case .debug: logger.debug("[\(category, privacy: .public)] \(message, privacy: .public)")
        case .info: logger.info("[\(category, privacy: .public)] \(message, privacy: .public)")
        case .warning: logger.warning("[\(category, privacy: .public)] \(message, privacy: .public)")
        case .error: logger.error("[\(category, privacy: .public)] \(message, privacy: .public)")
        }
        lineObserver?(level, category, message)
        lock.lock()
        pending.append(entry)
        if attemptLines.count < attemptCapacity {
            attemptLines.append("\(Self.timeFormatter.string(from: entry.date)) \(level.rawValue) [\(category)] \(message)")
        }
        let shouldSchedule = !flushScheduled
        flushScheduled = true
        lock.unlock()
        if shouldSchedule {
            // Batch UI updates so a chatty core cannot flood the main thread.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { [weak self] in self?.flush() }
        }
    }

    private func flush() {
        lock.lock()
        let batch = pending
        pending.removeAll()
        flushScheduled = false
        lock.unlock()
        guard !batch.isEmpty else { return }
        var updated = entries
        updated.append(contentsOf: batch)
        if updated.count > capacity { updated.removeFirst(updated.count - capacity) }
        entries = updated
    }

    private static let timeFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss.SSS"
        return f
    }()

    /// Starts a fresh log for one connection attempt.
    func markAttemptStart() {
        lock.lock(); attemptLines.removeAll(); lock.unlock()
    }

    /// The last connection attempt's log as text (already redacted, like the rest of the log).
    var lastAttemptText: String {
        lock.lock(); defer { lock.unlock() }
        return attemptLines.isEmpty ? "(no connection attempt logged yet)" : attemptLines.joined(separator: "\n")
    }

    func clear() {
        lock.lock(); pending.removeAll(); lock.unlock()
        entries.removeAll()
    }

    var exportText: String {
        let formatter = ISO8601DateFormatter()
        return entries.map { "\(formatter.string(from: $0.date)) [\($0.level.rawValue)] [\($0.category)] \($0.message)" }
            .joined(separator: "\n")
    }
}

func vpLog(_ level: DiagnosticsLog.Entry.Level, _ category: String, _ message: String) {
    DiagnosticsLog.shared.log(level, category, message)
}
