import Foundation
import MetricKit
import UIKit

/// Collects crash and hang reports from the system (MetricKit delivers them on the next
/// launch after a crash) and keeps the last few on disk, so they can be shared.
final class CrashCollector: NSObject, MXMetricManagerSubscriber {
    static let shared = CrashCollector()
    private let folder: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("CrashReports", isDirectory: true)
    }()

    func start() {
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        MXMetricManager.shared.add(self)
    }

    func didReceive(_ payloads: [MXDiagnosticPayload]) {
        for payload in payloads {
            let crashes = payload.crashDiagnostics?.count ?? 0
            let hangs = payload.hangDiagnostics?.count ?? 0
            guard crashes + hangs > 0 else { continue }
            let name = "report-\(Int(Date().timeIntervalSince1970))-\(crashes)c\(hangs)h.json"
            try? payload.jsonRepresentation().write(to: folder.appendingPathComponent(name))
            vpLog(.error, "crash", "System reported \(crashes) crash(es), \(hangs) hang(s) from a previous run")
        }
        prune()
    }

    var reports: [URL] {
        ((try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.creationDateKey])) ?? [])
            .filter { $0.pathExtension == "json" }
            .sorted { $0.lastPathComponent > $1.lastPathComponent }
    }

    private func prune() {
        for old in reports.dropFirst(5) { try? FileManager.default.removeItem(at: old) }
    }
}

/// One shareable text file: app/device info, settings, last stream statistics, the log
/// (secrets are already redacted when logged) and any crash reports.
enum ProblemReport {
    @MainActor
    static func make(model: AppModel) -> URL {
        let info = Bundle.main.infoDictionary
        let s = model.settings
        let stats = model.stream.statistics
        var lines: [String] = []
        lines.append("VisionPlay problem report — \(Date().formatted(date: .abbreviated, time: .standard))")
        lines.append("App \(info?["CFBundleShortVersionString"] as? String ?? "?") (\(info?["CFBundleVersion"] as? String ?? "?")), \(UIDevice.current.systemName) \(UIDevice.current.systemVersion)")
        lines.append("")
        lines.append("## Settings")
        lines.append("Resolution \(s.resolution.label), \(s.effectiveFPS) FPS, \(s.codec.label), upscaling \(s.upscalingEnabled ? s.upscaleMode.rawValue : "off") → \(s.outputTarget.rawValue), sharpening \(Int(s.sharpening * 100))%, clean-up \(s.deblock)")
        lines.append("Low latency \(s.lowLatency), Smooth Motion \(s.effectiveSmoothMotion), spatial \(s.spatialAudio), room \(s.roomAcoustics), upmix \(s.surroundUpmix), cinema \(s.cinemaRoom), HDR \(s.codec == .hevcHDR)")
        lines.append("Consoles registered: \(model.consoles.consoles.count); state: \(model.stream.phase.rawValue)")
        lines.append("Last error: \(model.stream.lastError?.code.label ?? "none")")
        lines.append("")
        lines.append("## Last stream statistics")
        lines.append("\(stats.streamWidth)×\(stats.streamHeight) \(stats.codec), net \(String(format: "%.1f", stats.networkFPS)) fps, out \(String(format: "%.1f", stats.render.presentedFPS)) fps, RTT \(String(format: "%.0f", stats.rttMilliseconds)) ms, loss \(String(format: "%.1f", stats.packetLossPercent))%")
        lines.append("\(stats.lag.summary) — \(stats.lag.breakdown)")
        lines.append("Frames lost \(stats.framesLost), late \(stats.lateFrames), dropped \(stats.render.framesDropped), reconnects \(stats.reconnectAttempts)")
        lines.append("")
        lines.append("## Log")
        lines.append(DiagnosticsLog.shared.exportText)
        let crashes = CrashCollector.shared.reports
        if !crashes.isEmpty {
            lines.append("")
            lines.append("## Crash / hang reports (\(crashes.count))")
            for url in crashes {
                lines.append("--- \(url.lastPathComponent)")
                lines.append((try? String(contentsOf: url, encoding: .utf8)) ?? "(unreadable)")
            }
        }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("VisionPlay-report.txt")
        try? lines.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8)
        return url
    }
}
