import SwiftUI

enum SceneID {
    static let main = "main"
    static let playback = "playback"
    static let settings = "settings"
    static let customScreen = "customScreen"
}

@main
struct VisionPlayApp: App {
    @State private var model = AppModel()
    @State private var customScreenStyle: ImmersionStyle = .mixed
    /// Mixed immersion: the "dark background" option surrounds the viewer with a dark
    /// environment sphere instead of switching to full immersion, so the system can
    /// still show passthrough for hands and nearby people.
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        Window("ViniPlay", id: SceneID.main) {
            HomeView().environment(model)
                .controllerPlaysTheGame()
        }
        .defaultSize(width: 1100, height: 760)
        .restorationBehavior(.disabled)
        // Always open Home when the app launches or you tap its icon.
        .defaultLaunchBehavior(.presented)

        // The game window: drag it anywhere by its bar, resize from a corner, and it works
        // inside Apple's Environments. Single instance, so it can never open twice.
        Window("ViniPlay Game", id: SceneID.playback) {
            GameWindowView().environment(model)
        }
        .windowStyle(.plain)
        .defaultSize(width: 1600, height: 900)
        .windowResizability(.contentMinSize)
        .restorationBehavior(.disabled)
        .defaultLaunchBehavior(.suppressed)

        // Settings: its own window, movable anywhere.
        Window("ViniPlay Settings", id: SceneID.settings) {
            SettingsWindowRoot().environment(model)
                .controllerPlaysTheGame()
        }
        .defaultSize(width: 880, height: 760)
        .defaultWindowPlacement { _, _ in WindowPlacement(.utilityPanel) }
        .restorationBehavior(.disabled)
        .defaultLaunchBehavior(.suppressed)

        ImmersiveSpace(id: SceneID.customScreen) {
            CustomScreenImmersiveView().environment(model)
        }
        .immersionStyle(selection: $customScreenStyle, in: .mixed)
        // Your hands always show on top of the screen and panel, never cut into by them.
        .upperLimbVisibility(.visible)
        // Keep controller and stream recovery alive regardless of which native
        // window currently has visual focus.
        .onChange(of: scenePhase) { _, phase in
            switch phase {
            case .background: model.stream.appDidEnterBackground()
            case .active:
                model.stream.appDidBecomeActive()
            default: break
            }
        }

    }
}
