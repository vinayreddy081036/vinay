import Foundation
import Observation
import SwiftUI

/// Root object shared by every scene.
@Observable
@MainActor
final class AppModel {
    let settings: AppSettings
    let consoles: ConsoleStore
    let discovery: DiscoveryService
    let registration: RegistrationService
    let controllers: ControllerManager
    let stream: StreamCoordinator
    let profiles: GameProfileStore
    /// Game PSN says is running (nil if unknown / not signed in).
    var currentGameTitle: String?
    @ObservationIgnored private var presenceTask: Task<Void, Never>?
    @ObservationIgnored private var stopObserver: NSObjectProtocol?

    /// True while the Custom Screen (the one game screen) is open. Set only by the screen's own
    /// onAppear / onDisappear, so it always matches what is really on screen.
    var theaterOpen = false { didSet { if oldValue != theaterOpen { refreshAudioLayout() } } }
    /// True while the app-owned, manually positioned Custom Screen is active.
    var customScreenOpen = false
    /// Bumped by the Airplane button: the Cinema starts a 10-second fly-by.
    var airplaneRequest = 0
    /// The game window is open.
    var gameWindowOpen = false
    /// Swapping between the game window and the Cinema: the game keeps running.
    @ObservationIgnored var switchingScreens = false
    /// An open request for the Custom Screen is in flight (don't ask twice).
    @ObservationIgnored var customScreenOpening = false
    /// Custom Screen's settings panel folded into its small button (Done).
    var screenPanelCollapsed = false
    /// Size/Distance drag in progress (drives the live preview and the outline in the room).
    let screenEditor = ScreenEditor()

    init(defaults: UserDefaults = .standard) {
        settings = AppSettings(defaults: defaults)
        consoles = ConsoleStore(defaults: defaults)
        discovery = DiscoveryService()
        registration = RegistrationService()
        controllers = ControllerManager()
        stream = StreamCoordinator(settings: settings, store: consoles, discovery: discovery, controllers: controllers)
        profiles = GameProfileStore(defaults: defaults)
        ChiakiRuntime.ensureInitialized()
        CrashCollector.shared.start()
        refreshAudioLayout()
        watchStreamQuality()
        // "Stop Remote Play" (Siri / Shortcuts) works whichever window is open — the home
        // window is closed while you play, so it can't be the one listening.
        stopObserver = NotificationCenter.default.addObserver(forName: .visionPlayStopRequest, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.stream.disconnect() }
        }
    }

    // MARK: Stream quality mid-game

    @ObservationIgnored private var qualityRestart: Task<Void, Never>?

    /// Resolution, frame rate, codec or bitrate changed — from anywhere, mid-game too: restart
    /// the stream with them. Waits a moment so a slider drag restarts once. Only real value
    /// changes count (Observation also fires on same-value assignments).
    private func watchStreamQuality() {
        let s = settings
        let read = { "\(s.resolution)-\(s.fps)-\(s.codec)-\(s.customBitrateMbps)-\(s.networkMode)-\(s.effectiveFPS)" }
        let before = read()
        withObservationTracking { _ = read() } onChange: { [weak self] in
            Task { @MainActor [weak self] in
                guard let self else { return }
                if read() != before {
                    self.qualityRestart?.cancel()
                    self.qualityRestart = Task { @MainActor [weak self] in
                        try? await Task.sleep(for: .milliseconds(900))
                        guard !Task.isCancelled else { return }
                        self?.stream.applyStreamSettingsLive()
                    }
                }
                self.watchStreamQuality()
            }
        }
    }

    /// Applies a game profile (or nil to keep the current settings) and pushes it to the stream.
    func applyProfile(_ profile: GameProfile?) {
        profiles.activeID = profile?.id
        guard let profile else { return }
        settings.apply(profile)
        stream.applyUpscalerSettings()
        stream.applyMotionAndCaptureSettings()
        refreshAudioLayout()
        vpLog(.info, "profiles", "Applied profile \(profile.name)")
    }

    /// While streaming, checks every minute which game PSN reports and switches profile.
    func startGameDetection() {
        presenceTask?.cancel()
        guard !profiles.profiles.isEmpty, PSNTokenStore.shared.hasRefreshToken else { return }
        presenceTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                guard let self else { return }
                if self.stream.phase == .streaming, let console = self.stream.connectedConsole,
                   let accountID = (try? self.consoles.credentials(for: console.id))?.psnAccountID,
                   let token = try? await PSNTokenStore.shared.accessToken(),
                   let title = await GamePresence.currentTitle(accessToken: token, accountID: accountID) {
                    if title != self.currentGameTitle {
                        self.currentGameTitle = title
                        if let match = self.profiles.profile(forTitle: title), match.id != self.profiles.activeID {
                            self.applyProfile(match)
                        }
                    }
                }
                try? await Task.sleep(for: .seconds(60))
            }
        }
    }

    func stopGameDetection() {
        presenceTask?.cancel()
        presenceTask = nil
        currentGameTitle = nil
    }

    /// Recomputes where the sound comes from (window vs Theater screen) and the room options.
    func refreshAudioLayout() {
        var layout = SpatialAudioLayout.windowDefault
        layout.enabled = settings.spatialAudio
        layout.roomAcoustics = settings.roomAcoustics
        layout.surroundUpmix = settings.surroundUpmix
        if theaterOpen {
            // Custom Screen: the real width. (renderedScreenWidth is the window-mode estimate.)
            layout.screenWidth = Float(customScreenOpen ? settings.screenWidthMeters : settings.renderedScreenWidth)
            layout.screenDistance = Float(settings.viewingDistance)
        }
        stream.audio.setSpatialLayout(layout)
    }

    /// Discovered consoles that are not registered yet.
    var unregisteredDiscoveries: [DiscoveredConsole] {
        discovery.consoles.filter { found in !consoles.consoles.contains { $0.mac == found.hostID } }
    }

    func discoveryInfo(for console: RegisteredConsole) -> DiscoveredConsole? {
        discovery.console(forHostID: console.mac)
    }

    func removeConsole(_ console: RegisteredConsole) {
        if stream.connectedConsole?.id == console.id { stream.disconnect() }
        do {
            try consoles.remove(consoleID: console.id)
            vpLog(.info, "consoles", "Removed \(console.nickname) and its Keychain credentials")
        } catch {
            vpLog(.error, "consoles", "Could not remove credentials: \(error)")
        }
    }

    func wake(_ console: RegisteredConsole) {
        guard let credentials = try? consoles.credentials(for: console.id) else { return }
        let host = discoveryInfo(for: console)?.address ?? console.lastKnownAddress
        let key = credentials.registKey
        DispatchQueue.global(qos: .userInitiated).async {
            let result = key.withUnsafeBytes { raw in
                host.withCString { vp_wakeup($0, raw.bindMemory(to: CChar.self).baseAddress, console.isPS5) }
            }
            vpLog(result == CHIAKI_ERR_SUCCESS ? .info : .error, "consoles",
                  "Wake \(console.nickname) at \(host): \(ChiakiRuntime.describe(result))")
        }
    }
}
