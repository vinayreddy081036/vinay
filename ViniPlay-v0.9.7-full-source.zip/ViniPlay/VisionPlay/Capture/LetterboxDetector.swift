import CoreVideo
import Foundation

/// Finds black bars above and below the picture (letterboxed cutscenes), a couple of times a
/// second, from a sparse sample of luma rows. A bar must be seen for 3 checks in a row before
/// it is reported and must disappear for 2 before it is cleared, so dark scenes and fades
/// don't make the picture jump.
final class LetterboxDetector: @unchecked Sendable {
    private let lock = NSLock()
    private var reported: (top: Float, bottom: Float) = (0, 0)
    private var candidate: (top: Float, bottom: Float) = (0, 0)
    private var agreeing = 0
    private var lastCheck: UInt64 = 0
    private let intervalNs: UInt64 = 400_000_000

    /// Bar heights as fractions of the picture height (0 when there are none).
    var bars: (top: Float, bottom: Float) {
        lock.lock(); defer { lock.unlock() }
        return reported
    }

    func reset() {
        lock.lock(); reported = (0, 0); candidate = (0, 0); agreeing = 0; lock.unlock()
    }

    func sample(_ buffer: CVPixelBuffer) {
        let now = DispatchTime.now().uptimeNanoseconds
        lock.lock()
        let due = now &- lastCheck >= intervalNs
        if due { lastCheck = now }
        lock.unlock()
        guard due, let found = Self.measure(buffer) else { return }
        lock.lock()
        update(with: found)
        lock.unlock()
    }

    /// Must hold `lock`.
    private func update(with found: (top: Float, bottom: Float)) {
        let close = abs(found.top - candidate.top) < 0.01 && abs(found.bottom - candidate.bottom) < 0.01
        if close { agreeing += 1 } else { candidate = found; agreeing = 1 }
        let needed = (found.top == 0 && found.bottom == 0) ? 2 : 3
        if agreeing >= needed { reported = candidate }
    }

    /// Testable core: given per-row "is this row black" answers, the bar fractions.
    /// Bars must be symmetric within 2 % and between 4 % and 30 % of the height each;
    /// anything else (a dark sky at the top only, a black loading screen) is not a letterbox.
    static func bars(rows: Int, isBlack: (Int) -> Bool) -> (top: Float, bottom: Float) {
        guard rows > 8 else { return (0, 0) }
        var top = 0
        while top < rows / 2 && isBlack(top) { top += 1 }
        var bottom = 0
        while bottom < rows / 2 && isBlack(rows - 1 - bottom) { bottom += 1 }
        let t = Float(top) / Float(rows), b = Float(bottom) / Float(rows)
        if top >= rows / 2 { return (0, 0) }                 // fully black frame
        guard t >= 0.04, b >= 0.04, t <= 0.3, b <= 0.3, abs(t - b) <= 0.02 else { return (0, 0) }
        // Round in slightly so a soft bar edge is covered.
        return (t + 0.002, b + 0.002)
    }

    /// Luma-only check of 90 rows × 32 columns. A row is black when every sample is at or
    /// below video black + a small margin.
    static func measure(_ buffer: CVPixelBuffer) -> (top: Float, bottom: Float)? {
        guard CVPixelBufferGetPlaneCount(buffer) == 2 else { return nil }
        let format = CVPixelBufferGetPixelFormatType(buffer)
        let tenBit = format == kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange || format == kCVPixelFormatType_420YpCbCr10BiPlanarFullRange
        CVPixelBufferLockBaseAddress(buffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddressOfPlane(buffer, 0) else { return nil }
        let w = CVPixelBufferGetWidthOfPlane(buffer, 0), h = CVPixelBufferGetHeightOfPlane(buffer, 0)
        let stride = CVPixelBufferGetBytesPerRowOfPlane(buffer, 0)
        let rows = 90
        let threshold: Float = 26.0 / 255   // video black is 16/255
        return bars(rows: rows) { r in
            let y = min(h - 1, (r * h) / rows + h / (rows * 2))
            let row = base.advanced(by: y * stride)
            for i in 0..<32 {
                let x = (i * 2 + 1) * w / 64
                let value: Float = tenBit
                    ? Float(row.assumingMemoryBound(to: UInt16.self)[x] >> 6) / 1023
                    : Float(row.assumingMemoryBound(to: UInt8.self)[x]) / 255
                if value > threshold { return false }
            }
            return true
        }
    }
}
