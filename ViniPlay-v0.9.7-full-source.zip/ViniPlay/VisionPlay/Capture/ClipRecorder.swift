import Foundation
import AVFoundation
import CoreImage
import CoreMedia
import ImageIO
import Photos
import VideoToolbox

/// Screenshots and Instant Replay (save the last 30 seconds) to Photos.
///
/// Remote Play sends a keyframe only when a stream starts or recovers, so the PS5's own
/// video can't be cut at arbitrary points. While Instant Replay is on, decoded frames are
/// re-encoded with the hardware H.264 encoder (keyframe every second) into a rolling
/// ~32 s buffer, alongside the decoded game audio. Saving writes an MP4 and adds it to Photos.
final class ClipRecorder: @unchecked Sendable {
    enum CaptureError: Error, LocalizedError {
        case nothingRecorded
        case noFrame
        case photosDenied
        case writerFailed(String)

        var errorDescription: String? {
            switch self {
            case .nothingRecorded: return "Nothing recorded yet. Turn on Instant Replay in Settings and play for a few seconds."
            case .noFrame: return "No video frame to capture yet."
            case .photosDenied: return "VisionPlay isn't allowed to add to Photos (Settings › Privacy & Security › Photos)."
            case .writerFailed(let detail): return "Couldn't write the clip: \(detail)"
            }
        }
    }

    private struct AudioChunk { let time: CMTime; let samples: [Float] }

    private let lock = NSLock()
    private var compression: VTCompressionSession?
    private var sessionSize = (width: 0, height: 0)
    private var videoSamples: [CMSampleBuffer] = []
    private var audioChunks: [AudioChunk] = []
    private var lastEncodeTime = CMTime.zero
    private let keep = CMTime(seconds: 32, preferredTimescale: 600)
    private(set) var enabled = false

    deinit { invalidate() }

    func setEnabled(_ on: Bool) {
        lock.lock()
        enabled = on
        if !on {
            videoSamples.removeAll()
            audioChunks.removeAll()
        }
        lock.unlock()
        if !on { invalidate() }
    }

    func invalidate() {
        lock.lock()
        let session = compression
        compression = nil
        sessionSize = (0, 0)
        lock.unlock()
        if let session {
            VTCompressionSessionCompleteFrames(session, untilPresentationTimeStamp: .invalid)
            VTCompressionSessionInvalidate(session)
        }
    }

    var bufferedSeconds: Double {
        lock.lock(); defer { lock.unlock() }
        guard let first = videoSamples.first, let last = videoSamples.last else { return 0 }
        return (CMSampleBufferGetPresentationTimeStamp(last) - CMSampleBufferGetPresentationTimeStamp(first)).seconds
    }

    static var now: CMTime { CMClockGetTime(CMClockGetHostTimeClock()) }

    // MARK: Feeding (decoder / audio threads)

    func appendVideo(_ pixelBuffer: CVPixelBuffer) {
        lock.lock()
        guard enabled else { lock.unlock(); return }
        let time = Self.now
        // At most 60 fps into the encoder.
        if (time - lastEncodeTime).seconds < 1.0 / 62 { lock.unlock(); return }
        lastEncodeTime = time
        let width = CVPixelBufferGetWidth(pixelBuffer), height = CVPixelBufferGetHeight(pixelBuffer)
        if compression == nil || sessionSize.width != width || sessionSize.height != height {
            lock.unlock()
            makeSession(width: width, height: height)
            lock.lock()
        }
        let session = compression
        lock.unlock()
        guard let session else { return }
        VTCompressionSessionEncodeFrame(session, imageBuffer: pixelBuffer, presentationTimeStamp: time,
                                        duration: .invalid, frameProperties: nil, infoFlagsOut: nil) { [weak self] status, _, sample in
            guard status == noErr, let sample, let self else { return }
            self.store(sample)
        }
    }

    /// Interleaved stereo Float32 PCM from the game audio decoder.
    func appendAudio(_ samples: UnsafeBufferPointer<Float>) {
        lock.lock(); defer { lock.unlock() }
        guard enabled else { return }
        audioChunks.append(AudioChunk(time: Self.now, samples: Array(samples)))
        let cutoff = Self.now - keep
        if let index = audioChunks.firstIndex(where: { $0.time >= cutoff }), index > 0 {
            audioChunks.removeFirst(index)
        }
    }

    private func makeSession(width: Int, height: Int) {
        invalidate()
        var session: VTCompressionSession?
        let status = VTCompressionSessionCreate(allocator: nil, width: Int32(width), height: Int32(height),
                                                codecType: kCMVideoCodecType_H264, encoderSpecification: nil,
                                                imageBufferAttributes: nil, compressedDataAllocator: nil,
                                                outputCallback: nil, refcon: nil, compressionSessionOut: &session)
        guard status == noErr, let session else {
            vpLog(.error, "capture", "Instant Replay encoder unavailable (OSStatus \(status))")
            return
        }
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_RealTime, value: kCFBooleanTrue)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_AllowFrameReordering, value: kCFBooleanFalse)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_ProfileLevel, value: kVTProfileLevel_H264_High_AutoLevel)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_MaxKeyFrameIntervalDuration, value: 1.0 as CFNumber)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_ExpectedFrameRate, value: 60 as CFNumber)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_AverageBitRate, value: 16_000_000 as CFNumber)
        VTCompressionSessionPrepareToEncodeFrames(session)
        lock.lock()
        compression = session
        sessionSize = (width, height)
        lock.unlock()
        vpLog(.info, "capture", "Instant Replay recording \(width)×\(height) H.264")
    }

    private func store(_ sample: CMSampleBuffer) {
        lock.lock(); defer { lock.unlock() }
        guard enabled else { return }
        videoSamples.append(sample)
        let cutoff = Self.now - keep
        if let index = videoSamples.firstIndex(where: { CMSampleBufferGetPresentationTimeStamp($0) >= cutoff }), index > 0 {
            videoSamples.removeFirst(index)
        }
    }

    static func isKeyframe(_ sample: CMSampleBuffer) -> Bool {
        guard let attachments = CMSampleBufferGetSampleAttachmentsArray(sample, createIfNecessary: false) as? [[CFString: Any]],
              let first = attachments.first else { return true }
        return !(first[kCMSampleAttachmentKey_NotSync] as? Bool ?? false)
    }

    // MARK: Saving

    /// Writes the last `seconds` to an MP4 and adds it to Photos.
    func saveClip(seconds: Double = 30) async throws -> URL {
        lock.lock()
        let video = videoSamples
        let audio = audioChunks
        lock.unlock()
        guard let lastVideo = video.last else { throw CaptureError.nothingRecorded }
        let end = CMSampleBufferGetPresentationTimeStamp(lastVideo)
        let start = end - CMTime(seconds: seconds, preferredTimescale: 600)
        guard let firstIndex = video.firstIndex(where: { CMSampleBufferGetPresentationTimeStamp($0) >= start && Self.isKeyframe($0) }) else {
            throw CaptureError.nothingRecorded
        }
        let clipVideo = Array(video[firstIndex...])
        let clipStart = CMSampleBufferGetPresentationTimeStamp(clipVideo[0])
        let clipAudio = audio.filter { $0.time >= clipStart && $0.time <= end }

        let url = FileManager.default.temporaryDirectory.appendingPathComponent("VisionPlay-\(Int(Date().timeIntervalSince1970)).mp4")
        try? FileManager.default.removeItem(at: url)
        try await Self.write(video: clipVideo, audio: clipAudio, start: clipStart, to: url)
        try await Self.addToPhotos(videoURL: url)
        vpLog(.info, "capture", String(format: "Saved %.0f s clip to Photos", (end - clipStart).seconds))
        return url
    }

    private static func write(video: [CMSampleBuffer], audio: [AudioChunk], start: CMTime, to url: URL) async throws {
        let writer: AVAssetWriter
        do { writer = try AVAssetWriter(outputURL: url, fileType: .mp4) }
        catch { throw CaptureError.writerFailed(error.localizedDescription) }

        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: nil,
                                            sourceFormatHint: CMSampleBufferGetFormatDescription(video[0]))
        videoInput.expectsMediaDataInRealTime = false
        writer.add(videoInput)

        var audioInput: AVAssetWriterInput?
        var audioSamples: [CMSampleBuffer] = []
        if !audio.isEmpty {
            let settings: [String: Any] = [AVFormatIDKey: kAudioFormatMPEG4AAC, AVSampleRateKey: 48_000,
                                           AVNumberOfChannelsKey: 2, AVEncoderBitRateKey: 192_000]
            let input = AVAssetWriterInput(mediaType: .audio, outputSettings: settings)
            input.expectsMediaDataInRealTime = false
            if writer.canAdd(input) {
                writer.add(input)
                audioInput = input
                audioSamples = audio.compactMap { makeAudioSample($0) }
            }
        }

        guard writer.startWriting() else { throw CaptureError.writerFailed(writer.error?.localizedDescription ?? "start") }
        writer.startSession(atSourceTime: start)

        await withTaskGroup(of: Void.self) { group in
            group.addTask { await feed(videoInput, video, label: "VisionPlay.clip.video") }
            if let audioInput {
                let samples = audioSamples
                group.addTask { await feed(audioInput, samples, label: "VisionPlay.clip.audio") }
            }
        }
        await writer.finishWriting()
        if writer.status != .completed {
            throw CaptureError.writerFailed(writer.error?.localizedDescription ?? "status \(writer.status.rawValue)")
        }
    }

    private static func feed(_ input: AVAssetWriterInput, _ samples: [CMSampleBuffer], label: String) async {
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            var index = 0
            input.requestMediaDataWhenReady(on: DispatchQueue(label: label)) {
                while input.isReadyForMoreMediaData && index < samples.count {
                    input.append(samples[index])
                    index += 1
                }
                if index >= samples.count {
                    input.markAsFinished()
                    continuation.resume()
                }
            }
        }
    }

    private static func makeAudioSample(_ chunk: AudioChunk) -> CMSampleBuffer? {
        let frames = chunk.samples.count / 2
        guard frames > 0 else { return nil }
        var asbd = AudioStreamBasicDescription(mSampleRate: 48_000, mFormatID: kAudioFormatLinearPCM,
                                               mFormatFlags: kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked,
                                               mBytesPerPacket: 8, mFramesPerPacket: 1, mBytesPerFrame: 8,
                                               mChannelsPerFrame: 2, mBitsPerChannel: 32, mReserved: 0)
        var format: CMAudioFormatDescription?
        guard CMAudioFormatDescriptionCreate(allocator: kCFAllocatorDefault, asbd: &asbd, layoutSize: 0, layout: nil,
                                             magicCookieSize: 0, magicCookie: nil, extensions: nil,
                                             formatDescriptionOut: &format) == noErr, let format else { return nil }
        let byteCount = chunk.samples.count * MemoryLayout<Float>.size
        var block: CMBlockBuffer?
        guard CMBlockBufferCreateWithMemoryBlock(allocator: kCFAllocatorDefault, memoryBlock: nil, blockLength: byteCount,
                                                 blockAllocator: kCFAllocatorDefault, customBlockSource: nil, offsetToData: 0,
                                                 dataLength: byteCount, flags: kCMBlockBufferAssureMemoryNowFlag,
                                                 blockBufferOut: &block) == kCMBlockBufferNoErr, let block else { return nil }
        let copied = chunk.samples.withUnsafeBytes { raw in
            CMBlockBufferReplaceDataBytes(with: raw.baseAddress!, blockBuffer: block, offsetIntoDestination: 0, dataLength: byteCount)
        }
        guard copied == kCMBlockBufferNoErr else { return nil }
        var sample: CMSampleBuffer?
        let status = CMAudioSampleBufferCreateReadyWithPacketDescriptions(allocator: kCFAllocatorDefault, dataBuffer: block,
                                                                         formatDescription: format, sampleCount: frames,
                                                                         presentationTimeStamp: chunk.time,
                                                                         packetDescriptions: nil, sampleBufferOut: &sample)
        return status == noErr ? sample : nil
    }

    // MARK: Screenshot

    /// Saves the current frame to Photos as a JPEG (HDR frames are converted to SDR).
    static func saveScreenshot(_ pixelBuffer: CVPixelBuffer?) async throws {
        guard let pixelBuffer else { throw CaptureError.noFrame }
        let image = CIImage(cvPixelBuffer: pixelBuffer)
        guard let data = CIContext().jpegRepresentation(of: image, colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!,
                                                        options: [kCGImageDestinationLossyCompressionQuality as CIImageRepresentationOption: 0.92]) else {
            throw CaptureError.writerFailed("JPEG encoding")
        }
        try await addToPhotos(photoData: data)
        vpLog(.info, "capture", "Saved screenshot \(CVPixelBufferGetWidth(pixelBuffer))×\(CVPixelBufferGetHeight(pixelBuffer)) to Photos")
    }

    // MARK: Photos

    private static func ensurePhotosAccess() async throws {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else { throw CaptureError.photosDenied }
    }

    private static func addToPhotos(videoURL: URL) async throws {
        try await ensurePhotosAccess()
        try await PHPhotoLibrary.shared().performChanges {
            PHAssetCreationRequest.forAsset().addResource(with: .video, fileURL: videoURL, options: nil)
        }
    }

    private static func addToPhotos(photoData: Data) async throws {
        try await ensurePhotosAccess()
        try await PHPhotoLibrary.shared().performChanges {
            PHAssetCreationRequest.forAsset().addResource(with: .photo, data: photoData, options: nil)
        }
    }
}
