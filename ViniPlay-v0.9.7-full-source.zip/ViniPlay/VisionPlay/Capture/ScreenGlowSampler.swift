import CoreVideo
import simd
import Foundation

/// Average colour of the picture, used to light the cinema room (walls and seats pick up
/// the screen's glow). Samples a sparse 16×9 grid of a bi-planar YCbCr frame a few times
/// a second, so the cost is negligible.
final class ScreenGlowSampler: @unchecked Sendable {
    private let lock = NSLock()
    private var color = SIMD3<Float>(0.05, 0.05, 0.06)
    private var lastSample: UInt64 = 0
    private let intervalNs: UInt64 = 120_000_000

    /// Smoothed linear RGB (0…1).
    var current: SIMD3<Float> {
        lock.lock(); defer { lock.unlock() }
        return color
    }

    func sample(_ buffer: CVPixelBuffer) {
        let now = DispatchTime.now().uptimeNanoseconds
        lock.lock()
        let due = now &- lastSample >= intervalNs
        if due { lastSample = now }
        lock.unlock()
        guard due, let rgb = Self.average(buffer) else { return }
        lock.lock()
        color = color * 0.6 + rgb * 0.4
        lock.unlock()
    }

    /// Mean colour of a 420 bi-planar frame (8- or 10-bit). nil for other formats.
    static func average(_ buffer: CVPixelBuffer) -> SIMD3<Float>? {
        guard CVPixelBufferGetPlaneCount(buffer) == 2 else { return nil }
        let format = CVPixelBufferGetPixelFormatType(buffer)
        let tenBit = format == kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange || format == kCVPixelFormatType_420YpCbCr10BiPlanarFullRange
        CVPixelBufferLockBaseAddress(buffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }
        guard let yBase = CVPixelBufferGetBaseAddressOfPlane(buffer, 0),
              let cBase = CVPixelBufferGetBaseAddressOfPlane(buffer, 1) else { return nil }
        let w = CVPixelBufferGetWidthOfPlane(buffer, 0), h = CVPixelBufferGetHeightOfPlane(buffer, 0)
        let yStride = CVPixelBufferGetBytesPerRowOfPlane(buffer, 0), cStride = CVPixelBufferGetBytesPerRowOfPlane(buffer, 1)
        var sum = SIMD3<Float>(0, 0, 0)
        var count: Float = 0
        for gy in 0..<9 {
            for gx in 0..<16 {
                let x = (gx * 2 + 1) * w / 32, y = (gy * 2 + 1) * h / 18
                let Y, Cb, Cr: Float
                if tenBit {
                    let yp = yBase.advanced(by: y * yStride).assumingMemoryBound(to: UInt16.self)
                    let cp = cBase.advanced(by: (y / 2) * cStride).assumingMemoryBound(to: UInt16.self)
                    Y = Float(yp[x] >> 6) / 1023; Cb = Float(cp[(x / 2) * 2] >> 6) / 1023; Cr = Float(cp[(x / 2) * 2 + 1] >> 6) / 1023
                } else {
                    let yp = yBase.advanced(by: y * yStride).assumingMemoryBound(to: UInt8.self)
                    let cp = cBase.advanced(by: (y / 2) * cStride).assumingMemoryBound(to: UInt8.self)
                    Y = Float(yp[x]) / 255; Cb = Float(cp[(x / 2) * 2]) / 255; Cr = Float(cp[(x / 2) * 2 + 1]) / 255
                }
                sum += yCbCrToRGB(Y, Cb, Cr)
                count += 1
            }
        }
        return sum / count
    }

    /// BT.709 video range → RGB, clamped.
    static func yCbCrToRGB(_ y: Float, _ cb: Float, _ cr: Float) -> SIMD3<Float> {
        let yl = (y - 16.0 / 255) * (255.0 / 219)
        let u = (cb - 128.0 / 255) * (255.0 / 224), v = (cr - 128.0 / 255) * (255.0 / 224)
        let rgb = SIMD3<Float>(yl + 1.5748 * v, yl - 0.1873 * u - 0.4681 * v, yl + 1.8556 * u)
        return simd_clamp(rgb, SIMD3(repeating: 0), SIMD3(repeating: 1))
    }
}
