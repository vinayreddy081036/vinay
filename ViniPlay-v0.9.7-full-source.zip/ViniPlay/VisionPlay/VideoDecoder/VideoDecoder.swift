import Foundation
import CoreMedia
import CoreVideo
import VideoToolbox

/// Receives decoded frames. Called on a VideoToolbox thread.
protocol VideoDecoderOutput: AnyObject {
    func decoder(_ decoder: VideoDecoder, didDecode pixelBuffer: CVPixelBuffer, frameNumber: UInt64, submittedAt: UInt64)
    func decoderNeedsKeyframe(_ decoder: VideoDecoder, reason: String)
}

/// Hardware H.264 / HEVC decoding with VideoToolbox.
///
/// Input is one Annex-B access unit per call (as delivered by Chiaki). Parameter sets are
/// tracked so the decompression session is rebuilt only when the stream format changes.
/// Output pixel buffers are IOSurface-backed and Metal-compatible, so the renderer can
/// wrap them as textures without copying.
final class VideoDecoder: @unchecked Sendable {
    struct Stats: Sendable {
        var submitted: UInt64 = 0
        var decoded: UInt64 = 0
        var failed: UInt64 = 0
        var droppedWaitingForKeyframe: UInt64 = 0
        var sessionRebuilds: UInt64 = 0
        var lastDecodeMilliseconds: Double = 0
        var averageDecodeMilliseconds: Double = 0
        var width: Int = 0
        var height: Int = 0
    }

    let codec: VideoCodecKind
    let tenBit: Bool
    weak var output: VideoDecoderOutput?

    private let lock = NSLock()
    private var session: VTDecompressionSession?
    private var formatDescription: CMVideoFormatDescription?
    private var parameterSets: [UInt8: Data] = [:]
    private var waitingForKeyframe = true
    private var frameCounter: UInt64 = 0
    private var stats = Stats()

    init(codec: VideoCodecKind, tenBit: Bool = false) {
        self.codec = codec
        self.tenBit = tenBit
    }

    deinit { invalidate() }

    var currentStats: Stats {
        lock.lock(); defer { lock.unlock() }
        return stats
    }

    func invalidate() {
        lock.lock()
        let s = session
        session = nil
        formatDescription = nil
        lock.unlock()
        if let s {
            VTDecompressionSessionWaitForAsynchronousFrames(s)
            VTDecompressionSessionInvalidate(s)
        }
    }

    /// Resets state after a stream interruption; the next frame must be a keyframe.
    func reset() {
        invalidate()
        lock.lock()
        parameterSets.removeAll()
        waitingForKeyframe = true
        lock.unlock()
    }

    /// Decodes one access unit. Returns false if the frame could not be submitted.
    @discardableResult
    func decode(accessUnit: UnsafeBufferPointer<UInt8>) -> Bool {
        let ranges = AnnexBParser.payloadRanges(accessUnit)
        guard !ranges.isEmpty, let base = accessUnit.baseAddress else { return false }

        var sliceRanges: [Range<Int>] = []
        sliceRanges.reserveCapacity(ranges.count)
        var containsKeyframe = false
        var parameterSetsChanged = false

        lock.lock()
        for range in ranges {
            let type = AnnexBParser.nalType(accessUnit, range, codec: codec)
            if AnnexBParser.isParameterSet(type, codec: codec) {
                // Parameter sets are tiny; compare in place and copy only when they change.
                let changed = parameterSets[type].map { stored in
                    stored.count != range.count || stored.withUnsafeBytes { memcmp($0.baseAddress!, base + range.lowerBound, range.count) != 0 }
                } ?? true
                if changed {
                    parameterSets[type] = Data(bytes: base + range.lowerBound, count: range.count)
                    parameterSetsChanged = true
                }
            } else if !AnnexBParser.isDroppable(type, codec: codec) {
                if AnnexBParser.isKeyframe(type, codec: codec) { containsKeyframe = true }
                sliceRanges.append(range)
            }
        }

        if waitingForKeyframe && !containsKeyframe {
            stats.droppedWaitingForKeyframe += 1
            lock.unlock()
            return false
        }

        if parameterSetsChanged || session == nil {
            lock.unlock()
            guard rebuildSession() else { return false }
            lock.lock()
        }
        guard let session, let formatDescription, !sliceRanges.isEmpty else {
            lock.unlock()
            return false
        }
        if containsKeyframe { waitingForKeyframe = false }
        frameCounter += 1
        let frameNumber = frameCounter
        stats.submitted += 1
        lock.unlock()

        // Exactly one copy: network buffer → CoreMedia block buffer with length prefixes
        // (Chiaki reuses its buffer as soon as this callback returns).
        guard let sampleBuffer = makeSampleBuffer(from: accessUnit, ranges: sliceRanges,
                                                  format: formatDescription, frameNumber: frameNumber) else {
            return false
        }

        let submittedAt = mach_absolute_time()
        let flags: VTDecodeFrameFlags = [._EnableAsynchronousDecompression, ._1xRealTimePlayback]
        var infoOut = VTDecodeInfoFlags()
        let status = VTDecompressionSessionDecodeFrame(session, sampleBuffer: sampleBuffer, flags: flags,
                                                       infoFlagsOut: &infoOut) { [weak self] status, _, imageBuffer, _, _ in
            self?.handleOutput(status: status, imageBuffer: imageBuffer, frameNumber: frameNumber, submittedAt: submittedAt)
        }
        if status != noErr {
            markFailure("submit failed (OSStatus \(status))")
            if status == kVTInvalidSessionErr {
                invalidate()
            }
            return false
        }
        return true
    }

    private func handleOutput(status: OSStatus, imageBuffer: CVImageBuffer?, frameNumber: UInt64, submittedAt: UInt64) {
        guard status == noErr, let imageBuffer else {
            if status != noErr { markFailure("decode failed (OSStatus \(status))") }
            return
        }
        let elapsed = MachTime.milliseconds(from: submittedAt, to: mach_absolute_time())
        lock.lock()
        stats.decoded += 1
        stats.lastDecodeMilliseconds = elapsed
        stats.averageDecodeMilliseconds = stats.averageDecodeMilliseconds == 0
            ? elapsed : stats.averageDecodeMilliseconds * 0.95 + elapsed * 0.05
        stats.width = CVPixelBufferGetWidth(imageBuffer)
        stats.height = CVPixelBufferGetHeight(imageBuffer)
        lock.unlock()
        output?.decoder(self, didDecode: imageBuffer, frameNumber: frameNumber, submittedAt: submittedAt)
    }

    private func markFailure(_ reason: String) {
        lock.lock()
        stats.failed += 1
        waitingForKeyframe = true
        lock.unlock()
        vpLog(.warning, "decoder", reason)
        output?.decoderNeedsKeyframe(self, reason: reason)
    }

    // MARK: Session construction

    private func rebuildSession() -> Bool {
        lock.lock()
        let sets = parameterSets
        lock.unlock()

        guard let format = makeFormatDescription(sets) else {
            vpLog(.warning, "decoder", "Waiting for complete parameter sets")
            return false
        }

        lock.lock()
        if let existing = session, VTDecompressionSessionCanAcceptFormatDescription(existing, formatDescription: format) {
            formatDescription = format
            lock.unlock()
            return true
        }
        let old = session
        session = nil
        lock.unlock()
        if let old {
            VTDecompressionSessionWaitForAsynchronousFrames(old)
            VTDecompressionSessionInvalidate(old)
        }

        let pixelFormat = tenBit ? kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange
                                 : kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange
        let destination: [CFString: Any] = [
            kCVPixelBufferPixelFormatTypeKey: pixelFormat,
            kCVPixelBufferMetalCompatibilityKey: true,
            kCVPixelBufferIOSurfacePropertiesKey: [:] as [CFString: Any],
        ]

        var newSession: VTDecompressionSession?
        let status = VTDecompressionSessionCreate(allocator: kCFAllocatorDefault,
                                                  formatDescription: format,
                                                  decoderSpecification: nil, // visionOS always uses the hardware decoder when available
                                                  imageBufferAttributes: destination as CFDictionary,
                                                  outputCallback: nil,
                                                  decompressionSessionOut: &newSession)
        guard status == noErr, let newSession else {
            vpLog(.error, "decoder", "VTDecompressionSessionCreate failed (OSStatus \(status))")
            return false
        }
        VTSessionSetProperty(newSession, key: kVTDecompressionPropertyKey_RealTime, value: kCFBooleanTrue)

        let dimensions = CMVideoFormatDescriptionGetDimensions(format)
        lock.lock()
        session = newSession
        formatDescription = format
        stats.sessionRebuilds += 1
        lock.unlock()
        vpLog(.info, "decoder", "Hardware decoder ready: \(codec == .h264 ? "H.264" : "HEVC") \(dimensions.width)×\(dimensions.height)\(tenBit ? " 10-bit" : "")")
        return true
    }

    private func makeFormatDescription(_ sets: [UInt8: Data]) -> CMVideoFormatDescription? {
        let ordered: [Data]
        switch codec {
        case .h264:
            guard let sps = sets[7], let pps = sets[8] else { return nil }
            ordered = [sps, pps]
        case .hevc:
            guard let vps = sets[32], let sps = sets[33], let pps = sets[34] else { return nil }
            ordered = [vps, sps, pps]
        }

        // Keep the parameter-set bytes alive while CoreMedia copies them.
        let buffers = ordered.map { [UInt8]($0) }
        var format: CMFormatDescription?
        var status: OSStatus = -1
        var pointers: [UnsafePointer<UInt8>] = []
        var sizes: [Int] = []

        func withPointers(_ index: Int, _ body: () -> Void) {
            if index == buffers.count { body(); return }
            buffers[index].withUnsafeBufferPointer { buffer in
                pointers.append(buffer.baseAddress!)
                sizes.append(buffer.count)
                withPointers(index + 1, body)
            }
        }

        withPointers(0) {
            switch codec {
            case .h264:
                status = CMVideoFormatDescriptionCreateFromH264ParameterSets(
                    allocator: kCFAllocatorDefault, parameterSetCount: pointers.count,
                    parameterSetPointers: pointers, parameterSetSizes: sizes,
                    nalUnitHeaderLength: 4, formatDescriptionOut: &format)
            case .hevc:
                status = CMVideoFormatDescriptionCreateFromHEVCParameterSets(
                    allocator: kCFAllocatorDefault, parameterSetCount: pointers.count,
                    parameterSetPointers: pointers, parameterSetSizes: sizes,
                    nalUnitHeaderLength: 4, extensions: nil, formatDescriptionOut: &format)
            }
        }
        guard status == noErr else {
            vpLog(.error, "decoder", "Could not build format description (OSStatus \(status))")
            return nil
        }
        return format
    }

    private func makeSampleBuffer(from buffer: UnsafeBufferPointer<UInt8>, ranges: [Range<Int>],
                                  format: CMVideoFormatDescription, frameNumber: UInt64) -> CMSampleBuffer? {
        guard let source = buffer.baseAddress else { return nil }
        let length = ranges.reduce(0) { $0 + $1.count + 4 }
        var blockBuffer: CMBlockBuffer?
        var status = CMBlockBufferCreateWithMemoryBlock(allocator: kCFAllocatorDefault, memoryBlock: nil,
                                                        blockLength: length, blockAllocator: kCFAllocatorDefault,
                                                        customBlockSource: nil, offsetToData: 0, dataLength: length,
                                                        flags: kCMBlockBufferAssureMemoryNowFlag, blockBufferOut: &blockBuffer)
        guard status == kCMBlockBufferNoErr, let blockBuffer else { return nil }

        var destinationPointer: UnsafeMutablePointer<CChar>?
        var contiguousLength = 0
        status = CMBlockBufferGetDataPointer(blockBuffer, atOffset: 0, lengthAtOffsetOut: nil,
                                             totalLengthOut: &contiguousLength, dataPointerOut: &destinationPointer)
        guard status == kCMBlockBufferNoErr, let destinationPointer, contiguousLength >= length else { return nil }
        let destination = UnsafeMutableRawPointer(destinationPointer)
        var offset = 0
        for range in ranges {
            let prefix = UInt32(range.count).bigEndian
            withUnsafeBytes(of: prefix) { (destination + offset).copyMemory(from: $0.baseAddress!, byteCount: 4) }
            offset += 4
            (destination + offset).copyMemory(from: source + range.lowerBound, byteCount: range.count)
            offset += range.count
        }

        var sampleBuffer: CMSampleBuffer?
        var sampleSize = length
        var timing = CMSampleTimingInfo(duration: .invalid,
                                        presentationTimeStamp: CMTime(value: CMTimeValue(frameNumber), timescale: 60),
                                        decodeTimeStamp: .invalid)
        status = CMSampleBufferCreateReady(allocator: kCFAllocatorDefault, dataBuffer: blockBuffer,
                                           formatDescription: format, sampleCount: 1,
                                           sampleTimingEntryCount: 1, sampleTimingArray: &timing,
                                           sampleSizeEntryCount: 1, sampleSizeArray: &sampleSize,
                                           sampleBufferOut: &sampleBuffer)
        guard status == noErr else { return nil }
        return sampleBuffer
    }
}

enum MachTime {
    private static let timebase: mach_timebase_info_data_t = {
        var info = mach_timebase_info_data_t()
        mach_timebase_info(&info)
        return info
    }()

    static func milliseconds(from start: UInt64, to end: UInt64) -> Double {
        guard end >= start else { return 0 }
        let nanos = Double(end - start) * Double(timebase.numer) / Double(timebase.denom)
        return nanos / 1_000_000
    }

    static func nanoseconds(_ ticks: UInt64) -> UInt64 {
        ticks * UInt64(timebase.numer) / UInt64(timebase.denom)
    }
}
