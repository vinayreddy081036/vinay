import Foundation

/// Splits Annex-B byte streams (start-code delimited) into NAL units and
/// classifies them for H.264 and HEVC.
enum VideoCodecKind: Sendable, Equatable {
    case h264
    case hevc
}

struct NALUnit: Equatable {
    /// NAL payload without the start code.
    var data: Data

    func type(for codec: VideoCodecKind) -> UInt8 {
        guard let first = data.first else { return 0xFF }
        switch codec {
        case .h264: return first & 0x1F
        case .hevc: return (first >> 1) & 0x3F
        }
    }
}

enum AnnexBParser {
    /// Byte ranges of each NAL payload (start codes excluded) in an Annex-B buffer.
    /// No bytes are copied.
    static func payloadRanges(_ buffer: UnsafeBufferPointer<UInt8>) -> [Range<Int>] {
        guard let base = buffer.baseAddress, buffer.count >= 4 else { return [] }
        let count = buffer.count
        var starts: [(payload: Int, codeStart: Int)] = []
        var i = 0
        while i + 2 < count {
            if base[i] == 0, base[i + 1] == 0 {
                if base[i + 2] == 1 {
                    let codeStart = (i > 0 && base[i - 1] == 0) ? i - 1 : i
                    starts.append((payload: i + 3, codeStart: codeStart))
                    i += 3
                    continue
                }
                if base[i + 2] == 0 { i += 1; continue }
            }
            i += 1
        }
        var ranges: [Range<Int>] = []
        ranges.reserveCapacity(starts.count)
        for (index, start) in starts.enumerated() {
            let end = index + 1 < starts.count ? starts[index + 1].codeStart : count
            if end > start.payload { ranges.append(start.payload..<end) }
        }
        return ranges
    }

    /// Returns the NAL units in `buffer`. Leading bytes before the first start code are ignored.
    static func split(_ buffer: UnsafeBufferPointer<UInt8>) -> [NALUnit] {
        guard let base = buffer.baseAddress else { return [] }
        return payloadRanges(buffer).map { NALUnit(data: Data(bytes: base + $0.lowerBound, count: $0.count)) }
    }

    /// NAL type of the payload starting at `buffer[range.lowerBound]`.
    static func nalType(_ buffer: UnsafeBufferPointer<UInt8>, _ range: Range<Int>, codec: VideoCodecKind) -> UInt8 {
        guard !range.isEmpty else { return 0xFF }
        let first = buffer[range.lowerBound]
        switch codec {
        case .h264: return first & 0x1F
        case .hevc: return (first >> 1) & 0x3F
        }
    }

    /// Writes the given payload ranges as one AVCC/HVCC sample (4-byte big-endian length
    /// prefixes) — a single copy from the network buffer.
    static func lengthPrefixed(_ buffer: UnsafeBufferPointer<UInt8>, ranges: [Range<Int>]) -> Data {
        guard let base = buffer.baseAddress else { return Data() }
        var output = Data(capacity: ranges.reduce(0) { $0 + $1.count + 4 })
        for range in ranges {
            var length = UInt32(range.count).bigEndian
            withUnsafeBytes(of: &length) { output.append(contentsOf: $0) }
            output.append(base + range.lowerBound, count: range.count)
        }
        return output
    }

    static func split(_ data: Data) -> [NALUnit] {
        data.withUnsafeBytes { raw in split(raw.bindMemory(to: UInt8.self)) }
    }

    // MARK: Classification

    static func isParameterSet(_ type: UInt8, codec: VideoCodecKind) -> Bool {
        switch codec {
        case .h264: return type == 7 || type == 8
        case .hevc: return type == 32 || type == 33 || type == 34
        }
    }

    static func isKeyframe(_ type: UInt8, codec: VideoCodecKind) -> Bool {
        switch codec {
        case .h264: return type == 5
        case .hevc: return (16...21).contains(type) // BLA/IDR/CRA (IRAP)
        }
    }

    /// Access-unit delimiters and filler data are dropped before decoding.
    static func isDroppable(_ type: UInt8, codec: VideoCodecKind) -> Bool {
        switch codec {
        case .h264: return type == 9 || type == 12
        case .hevc: return type == 35 || type == 38
        }
    }

    /// Converts slice NAL units to AVCC/HVCC sample format (4-byte big-endian length prefixes).
    static func lengthPrefixed(_ units: [NALUnit]) -> Data {
        var output = Data()
        output.reserveCapacity(units.reduce(0) { $0 + $1.data.count + 4 })
        for unit in units {
            var length = UInt32(unit.data.count).bigEndian
            withUnsafeBytes(of: &length) { output.append(contentsOf: $0) }
            output.append(unit.data)
        }
        return output
    }
}
