import Foundation

/// Receives callbacks from a Remote Play session. All methods are called on
/// Chiaki's session/stream threads — implementations must be thread-safe and fast.
protocol RemotePlaySessionDelegate: AnyObject {
    func sessionDidConnect(_ session: RemotePlaySession)
    func session(_ session: RemotePlaySession, didQuitWithReason reason: Int32, isError: Bool, message: String)
    func sessionRequestsLoginPIN(_ session: RemotePlaySession, previousWasIncorrect: Bool)
    /// One Annex-B access unit. Return false to make Chiaki request a new keyframe.
    func session(_ session: RemotePlaySession, didReceiveVideo data: UnsafeBufferPointer<UInt8>, framesLost: Int32, recovered: Bool) -> Bool
    func session(_ session: RemotePlaySession, didReceiveAudioHeader channels: Int, sampleRate: Int, frameSize: Int)
    func session(_ session: RemotePlaySession, didReceiveAudioPacket data: UnsafeBufferPointer<UInt8>)
    func session(_ session: RemotePlaySession, rumbleLeft left: UInt8, right: UInt8)
    func session(_ session: RemotePlaySession, triggerEffectsLeft typeLeft: UInt8, _ left: [UInt8], right typeRight: UInt8, _ right: [UInt8])
    func session(_ session: RemotePlaySession, lightBarColor rgb: UInt32)
    func session(_ session: RemotePlaySession, decoderFailureAtFrame frame: Int32)
    /// DualSense haptics stream block (interleaved stereo int16, 3 kHz).
    func session(_ session: RemotePlaySession, didReceiveHaptics samples: UnsafeBufferPointer<Int16>)
}

struct SessionConfiguration: Sendable, Equatable {
    var host: String
    var isPS5: Bool
    var credentials: ConsoleCredentials
    var resolution: StreamResolution
    var fps: Int
    var codec: StreamCodec
    var bitrateKbps: UInt32?
    var enableDualSense: Bool
    /// Internet Remote Play through PSN (nil = local network).
    var remote: RemoteTarget? = nil

    struct RemoteTarget: Sendable, Equatable {
        var deviceID: Data      // 32-byte PSN device id
        var accessToken: String
    }
}

/// Owns one Chiaki `VPSession`: start, stop, input, and teardown.
final class RemotePlaySession: @unchecked Sendable {
    let configuration: SessionConfiguration
    weak var delegate: RemotePlaySessionDelegate?

    private var handle: OpaquePointer?
    private let lock = NSLock()
    /// Held for all of start() and destroy(): the session can't be freed while it is still
    /// being set up (an Internet connect can block for up to 30 s). stop() doesn't take it,
    /// so cancelling still works and destroy() just waits for start() to return.
    private let lifecycle = NSLock()
    private var context: Unmanaged<RemotePlaySession>?

    init(configuration: SessionConfiguration) {
        self.configuration = configuration
    }

    deinit {
        // destroy() must have been called; as a safety net free on a background queue.
        if let handle {
            let address = Int(bitPattern: handle)
            DispatchQueue.global().async {
                if let pointer = OpaquePointer(bitPattern: address) { vp_session_destroy(pointer) }
            }
        }
    }

    /// Creates the Chiaki session and starts its thread. Connection progress is
    /// reported through the delegate.
    func start() throws {
        lifecycle.lock(); defer { lifecycle.unlock() }
        if case .failure(let error) = ChiakiRuntime.ensureInitialized() { throw error }
        guard configuration.credentials.isValid else { throw ConnectionError.missingCredentials }

        var config = VPConnectConfig()
        config.ps5 = configuration.isPS5
        config.resolution_preset = Int32(configuration.resolution.rawValue)
        config.fps = Int32(configuration.fps)
        config.bitrate_kbps = configuration.bitrateKbps ?? 0
        config.codec = Int32(configuration.codec.rawValue)
        config.auto_downgrade = true
        config.enable_dualsense = configuration.enableDualSense
        config.packet_loss_max = 0.05
        Self.copy(configuration.credentials.registKey, into: &config.regist_key)
        Self.copy(configuration.credentials.rpKey, into: &config.morning)
        Self.copy(configuration.credentials.psnAccountID, into: &config.psn_account_id)

        var callbacks = VPSessionCallbacks()
        callbacks.event = { kind, a, b, text, user in
            guard let user else { return }
            let session = Unmanaged<RemotePlaySession>.fromOpaque(user).takeUnretainedValue()
            session.handleEvent(kind: kind, a: a, b: b, text: text.map { String(cString: $0) })
        }
        callbacks.video = { buf, size, framesLost, recovered, user in
            guard let user, let buf else { return true }
            let session = Unmanaged<RemotePlaySession>.fromOpaque(user).takeUnretainedValue()
            guard let delegate = session.delegate else { return true }
            return delegate.session(session, didReceiveVideo: UnsafeBufferPointer(start: buf, count: size),
                                    framesLost: framesLost, recovered: recovered)
        }
        callbacks.audio_header = { channels, _, rate, frameSize, user in
            guard let user else { return }
            let session = Unmanaged<RemotePlaySession>.fromOpaque(user).takeUnretainedValue()
            session.delegate?.session(session, didReceiveAudioHeader: Int(channels), sampleRate: Int(rate), frameSize: Int(frameSize))
        }
        callbacks.audio_frame = { buf, size, user in
            guard let user, let buf else { return }
            let session = Unmanaged<RemotePlaySession>.fromOpaque(user).takeUnretainedValue()
            session.delegate?.session(session, didReceiveAudioPacket: UnsafeBufferPointer(start: buf, count: size))
        }
        callbacks.trigger_effects = { typeLeft, left, typeRight, right, user in
            guard let user, let left, let right else { return }
            let session = Unmanaged<RemotePlaySession>.fromOpaque(user).takeUnretainedValue()
            let l = Array(UnsafeBufferPointer(start: left, count: 10))
            let r = Array(UnsafeBufferPointer(start: right, count: 10))
            session.delegate?.session(session, triggerEffectsLeft: typeLeft, l, right: typeRight, r)
        }

        // No haptics callback: vibration is not used, so the bridge drops those packets.

        // The C side holds this pointer until vp_session_destroy returns, so retain self.
        let context = Unmanaged.passRetained(self)
        self.context = context

        var err = CHIAKI_ERR_SUCCESS
        let created: OpaquePointer?
        if let remote = configuration.remote {
            created = remote.accessToken.withCString { token in
                remote.deviceID.withUnsafeBytes { raw in
                    vp_session_create_remote(&config, token, raw.bindMemory(to: UInt8.self).baseAddress,
                                             remote.deviceID.count, callbacks, context.toOpaque(), &err)
                }
            }
        } else {
            created = configuration.host.withCString { hostPointer -> OpaquePointer? in
                config.host = hostPointer
                return vp_session_create(&config, callbacks, context.toOpaque(), &err)
            }
        }
        guard let created else {
            context.release()
            self.context = nil
            throw ConnectionError.from(chiaki: err, context: "Session setup")
        }
        lock.lock(); handle = created; lock.unlock()

        if configuration.remote != nil {
            // Blocking PSN exchange: session on Sony's servers, candidate exchange, hole punch.
            vpLog(.info, "session", "Reaching the console over the internet (PSN)…")
            let psnErr = vp_session_connect_psn(created)
            guard psnErr == CHIAKI_ERR_SUCCESS else {
                destroyLocked()
                throw ConnectionError.network("Internet connection through PSN failed (\(ChiakiRuntime.describe(psnErr))). The console must be on, or in rest mode with \"Stay connected to the internet\" enabled.")
            }
            vpLog(.info, "session", "Control connection hole punched")
        }

        let startErr = vp_session_start(created)
        guard startErr == CHIAKI_ERR_SUCCESS else {
            destroyLocked()
            throw ConnectionError.from(chiaki: startErr, context: "Session start")
        }
        vpLog(.info, "session", "Session started → \(configuration.host) (\(configuration.resolution.label)@\(configuration.fps), \(configuration.codec.label))")
    }

    /// Asks the console to end the stream (or aborts a PSN connection attempt). Non-blocking.
    func stop() {
        lock.lock(); let h = handle; lock.unlock()
        guard let h else { return }
        if configuration.remote != nil { vp_session_cancel_psn(h) }
        _ = vp_session_stop(h)
    }

    /// Stops, joins and frees the native session. Blocks until the session thread exits,
    /// so call it off the main thread. Never call from a delegate callback.
    func destroy() {
        lifecycle.lock(); defer { lifecycle.unlock() }
        destroyLocked()
    }

    /// destroy() for callers already holding `lifecycle` (start()'s failure paths).
    private func destroyLocked() {
        lock.lock()
        let h = handle
        handle = nil
        lock.unlock()
        if let h { vp_session_destroy(h) }
        context?.release()
        context = nil
    }

    func send(controllerState: ChiakiControllerState) {
        lock.lock(); defer { lock.unlock() }
        guard let handle else { return }
        var state = controllerState
        _ = vp_session_set_controller_state(handle, &state)
    }

    func requestKeyframe() {
        lock.lock(); defer { lock.unlock() }
        guard let handle else { return }
        _ = vp_session_request_idr(handle)
    }

    func setLoginPIN(_ pin: String) {
        lock.lock(); defer { lock.unlock() }
        guard let handle else { return }
        _ = pin.withCString { vp_session_set_login_pin(handle, $0) }
    }

    /// Tells the console the microphone is attached and sets its mute state.
    @discardableResult
    func setMicrophoneEnabled(_ enabled: Bool) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard let handle else { return false }
        return vp_session_set_microphone_enabled(handle, enabled) == CHIAKI_ERR_SUCCESS
    }

    /// Sends one 10 ms block: 480 frames × 2 channels of 48 kHz int16. Called from the audio thread.
    func sendMicrophone(_ interleaved: UnsafePointer<Int16>) {
        // Hold the lock for the (sub-millisecond) encode so destroy() cannot free the session mid-send.
        lock.lock(); defer { lock.unlock() }
        guard let handle else { return }
        _ = vp_session_send_microphone(handle, interleaved)
    }

    func goHome() {
        lock.lock(); defer { lock.unlock() }
        guard let handle else { return }
        _ = vp_session_go_home(handle)
    }

    func putConsoleToSleep() {
        lock.lock(); defer { lock.unlock() }
        guard let handle else { return }
        _ = vp_session_goto_bed(handle)
    }

    struct NetworkStats: Sendable {
        var rttMilliseconds: Double
        var packetLoss: Double
        var width: Int
        var height: Int
        var fps: Int
        var bitrateKbps: Int
        var codec: StreamCodec?
    }

    func networkStats() -> NetworkStats? {
        lock.lock(); defer { lock.unlock() }
        guard let handle else { return nil }
        var w: UInt32 = 0, h: UInt32 = 0, f: UInt32 = 0, b: UInt32 = 0
        var c: Int32 = 0
        vp_session_video_profile(handle, &w, &h, &f, &b, &c)
        return NetworkStats(rttMilliseconds: Double(vp_session_rtt_us(handle)) / 1000.0,
                            packetLoss: vp_session_packet_loss(handle),
                            width: Int(w), height: Int(h), fps: Int(f), bitrateKbps: Int(b),
                            codec: StreamCodec(rawValue: Int(c)))
    }

    private func handleEvent(kind: Int32, a: Int32, b: Int32, text: String?) {
        guard let delegate else { return }
        switch kind {
        case Int32(VP_EVENT_CONNECTED.rawValue):
            delegate.sessionDidConnect(self)
        case Int32(VP_EVENT_QUIT.rawValue):
            delegate.session(self, didQuitWithReason: a, isError: b != 0, message: text ?? "")
        case Int32(VP_EVENT_LOGIN_PIN_REQUEST.rawValue):
            delegate.sessionRequestsLoginPIN(self, previousWasIncorrect: a != 0)
        case Int32(VP_EVENT_RUMBLE.rawValue):
            delegate.session(self, rumbleLeft: UInt8(clamping: a), right: UInt8(clamping: b))
        case Int32(VP_EVENT_LED_COLOR.rawValue):
            delegate.session(self, lightBarColor: UInt32(bitPattern: a))
        case Int32(VP_EVENT_FEC_FAILURE.rawValue):
            delegate.session(self, decoderFailureAtFrame: a)
        case Int32(VP_EVENT_NICKNAME.rawValue):
            vpLog(.info, "session", "Console nickname: \(text ?? "")")
        case Int32(VP_EVENT_HOLEPUNCH.rawValue):
            vpLog(.info, "session", a != 0 ? "Data connection hole punched" : "Punching hole for data connection…")
        case Int32(VP_EVENT_PSN_REGIST.rawValue):
            vpLog(.info, "session", "PSN registration with the console completed")
        default:
            break
        }
    }

    private static func copy<T>(_ data: Data, into tuple: inout T) {
        withUnsafeMutableBytes(of: &tuple) { destination in
            destination.initializeMemory(as: UInt8.self, repeating: 0)
            data.prefix(destination.count).withUnsafeBytes { source in
                if let base = source.baseAddress, let dest = destination.baseAddress {
                    memcpy(dest, base, min(source.count, destination.count))
                }
            }
        }
    }
}
