import Foundation
import Observation

/// Pairs VisionPlay with a console using the 8-digit code from
/// PS5 › Settings › System › Remote Play › Pair Device.
@Observable
final class RegistrationService {
    enum State: Equatable {
        case idle
        case validating
        case registering(host: String)
        case succeeded(RegisteredConsole)
        case failed(ConnectionError)
        case canceled

        var isBusy: Bool {
            switch self {
            case .validating, .registering: return true
            default: return false
            }
        }
    }

    enum ValidationError: Error, Equatable, LocalizedError {
        case invalidPIN
        case invalidAccountID
        case invalidHost

        var errorDescription: String? {
            switch self {
            case .invalidPIN: return "The pairing code must be exactly 8 digits."
            case .invalidAccountID: return "The PSN account ID must be the Base64 form of 8 bytes (for example “AbCdEfGhIjk=”)."
            case .invalidHost: return "Enter the console's IPv4 address, for example 192.168.1.20."
            }
        }
    }

    private(set) var state: State = .idle

    @ObservationIgnored private var handle: OpaquePointer?
    @ObservationIgnored private var sink: RegistSink?

    // MARK: Validation (pure, unit-tested)

    static func parsePIN(_ text: String) -> Result<UInt32, ValidationError> {
        let digits = text.filter { !$0.isWhitespace && $0 != "-" }
        guard digits.count == 8, digits.allSatisfy(\.isASCII), digits.allSatisfy(\.isNumber),
              let value = UInt32(digits) else { return .failure(.invalidPIN) }
        return .success(value)
    }

    static func parseAccountID(_ base64: String) -> Result<Data, ValidationError> {
        let trimmed = base64.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let data = Data(base64Encoded: trimmed), data.count == 8 else { return .failure(.invalidAccountID) }
        return .success(data)
    }

    static func validateHost(_ host: String) -> Result<String, ValidationError> {
        let trimmed = host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard IPv4Interface.parse(trimmed) != nil else { return .failure(.invalidHost) }
        return .success(trimmed)
    }

    // MARK: Registration

    /// Starts registration. `completion` runs on the main thread once the console answers.
    func register(host: String, isPS5: Bool, pinText: String, accountIDBase64: String,
                  accountName: String? = nil,
                  store: ConsoleStore, completion: ((Result<RegisteredConsole, ConnectionError>) -> Void)? = nil) {
        guard !state.isBusy else { return }
        state = .validating

        let pin: UInt32
        let accountID: Data
        let validHost: String
        switch (Self.parsePIN(pinText), Self.parseAccountID(accountIDBase64), Self.validateHost(host)) {
        case (.success(let p), .success(let a), .success(let h)):
            pin = p; accountID = a; validHost = h
        case (.failure(let e), _, _), (_, .failure(let e), _), (_, _, .failure(let e)):
            let error = ConnectionError.registrationFailed(e.localizedDescription)
            state = .failed(error)
            completion?(.failure(error))
            return
        }

        if case .failure(let error) = ChiakiRuntime.ensureInitialized() {
            state = .failed(error)
            completion?(.failure(error))
            return
        }

        state = .registering(host: validHost)
        vpLog(.info, "regist", "Registering with \(isPS5 ? "PS5" : "PS4") at \(validHost)")

        let sink = RegistSink { [weak self] result in
            DispatchQueue.main.async {
                self?.finish(result: result, host: validHost, isPS5: isPS5, accountID: accountID, accountName: accountName,
                             store: store, completion: completion)
            }
        }
        self.sink = sink

        var err = CHIAKI_ERR_SUCCESS
        let created: OpaquePointer? = accountID.withUnsafeBytes { raw -> OpaquePointer? in
            let bytes = raw.bindMemory(to: UInt8.self).baseAddress
            return validHost.withCString { hostPointer in
                vp_regist_start(hostPointer, isPS5, false, bytes, pin, { resultPointer, user in
                    guard let resultPointer, let user else { return }
                    let sink = Unmanaged<RegistSink>.fromOpaque(user).takeUnretainedValue()
                    sink.handler(resultPointer.pointee)
                }, Unmanaged.passUnretained(sink).toOpaque(), &err)
            }
        }
        guard let created else {
            let error = ConnectionError.from(chiaki: err, context: "Registration")
            state = .failed(error)
            self.sink = nil
            completion?(.failure(error))
            return
        }
        handle = created
    }

    func cancel() {
        guard let handle else { return }
        vp_regist_cancel(handle)
    }

    private func finish(result: VPRegistResult, host: String, isPS5: Bool, accountID: Data, accountName: String?,
                        store: ConsoleStore, completion: ((Result<RegisteredConsole, ConnectionError>) -> Void)?) {
        releaseHandle()
        switch result.result {
        case 0:
            var r = result
            let mac = withUnsafeBytes(of: &r.server_mac) { Data($0) }
            let registKey = withUnsafeBytes(of: &r.rp_regist_key) { Data($0) }
            let rpKey = withUnsafeBytes(of: &r.rp_key) { Data($0) }
            let nickname = withUnsafeBytes(of: &r.server_nickname) { raw -> String in
                let bytes = raw.bindMemory(to: UInt8.self)
                let end = bytes.firstIndex(of: 0) ?? bytes.count
                return String(decoding: bytes[0..<end], as: UTF8.self)
            }
            let id = RegisteredConsole.registrationID(mac: mac.hexString, accountID: accountID,
                                                      existing: store.consoles) { existingID in
                (try? store.credentials(for: existingID))?.psnAccountID
            }
            var console = RegisteredConsole(
                id: id,
                nickname: nickname.isEmpty ? (isPS5 ? "PS5" : "PS4") : nickname,
                lastKnownAddress: host,
                isPS5: isPS5,
                target: r.target,
                registeredAt: Date())
            let trimmedName = accountName?.trimmingCharacters(in: .whitespacesAndNewlines)
            console.accountName = (trimmedName?.isEmpty ?? true) ? nil : trimmedName
            let credentials = ConsoleCredentials(registKey: registKey, rpKey: rpKey,
                                                 rpKeyType: r.rp_key_type, psnAccountID: accountID)
            do {
                try store.register(console, credentials: credentials)
                try? store.keychain.savePSNAccountID(accountID)
                vpLog(.info, "regist", "Registered \(console.nickname) (\(console.displayMAC))")
                state = .succeeded(console)
                completion?(.success(console))
            } catch {
                let failure = ConnectionError.registrationFailed("could not save credentials to the Keychain (\(error))")
                state = .failed(failure)
                completion?(.failure(failure))
            }
        case 2:
            state = .canceled
            completion?(.failure(.registrationFailed("canceled")))
        default:
            // Chiaki reports a generic failure for a wrong PIN, an expired PIN, a mismatched
            // PSN account and a timeout alike; the log has the specific HTTP status.
            let failure = ConnectionError.registrationFailed("the console did not accept the request")
            vpLog(.error, "regist", "Registration failed")
            state = .failed(failure)
            completion?(.failure(failure))
        }
    }

    private func releaseHandle() {
        guard let handle else { return }
        self.handle = nil
        let sink = self.sink
        self.sink = nil
        let address = Int(bitPattern: handle)
        DispatchQueue.global(qos: .utility).async {
            if let pointer = OpaquePointer(bitPattern: address) { vp_regist_destroy(pointer) }
            _ = sink
        }
    }

    func reset() {
        if state.isBusy { cancel() }
        state = .idle
    }
}

final class RegistSink: @unchecked Sendable {
    let handler: (VPRegistResult) -> Void
    init(handler: @escaping (VPRegistResult) -> Void) { self.handler = handler }
}
