import Foundation
import Darwin

/// Local IPv4 interface information used to enumerate the subnet for discovery.
struct IPv4Interface: Equatable, Sendable {
    var name: String
    var address: UInt32   // host byte order
    var netmask: UInt32   // host byte order

    var addressString: String { IPv4Interface.format(address) }
    var prefixLength: Int { netmask.nonzeroBitCount }

    static func format(_ value: UInt32) -> String {
        "\((value >> 24) & 0xFF).\((value >> 16) & 0xFF).\((value >> 8) & 0xFF).\(value & 0xFF)"
    }

    static func parse(_ string: String) -> UInt32? {
        let parts = string.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 4 else { return nil }
        var value: UInt32 = 0
        for part in parts {
            guard let octet = UInt8(part) else { return nil }
            value = (value << 8) | UInt32(octet)
        }
        return value
    }

    /// Unicast host addresses on this interface's subnet, excluding network, broadcast
    /// and our own address. Subnets larger than /22 are clamped to the /24 around us
    /// so a sweep stays quick and polite.
    func subnetHosts() -> [String] {
        var mask = netmask
        if prefixLength < 22 { mask = 0xFFFF_FF00 }
        if prefixLength >= 31 { return [] }
        let network = address & mask
        let broadcast = network | ~mask
        guard broadcast > network + 1 else { return [] }
        var hosts: [String] = []
        hosts.reserveCapacity(Int(broadcast - network))
        var candidate = network + 1
        while candidate < broadcast {
            if candidate != address { hosts.append(IPv4Interface.format(candidate)) }
            candidate += 1
        }
        return hosts
    }

    /// Active, non-loopback IPv4 interfaces (Wi-Fi first).
    static func current() -> [IPv4Interface] {
        var result: [IPv4Interface] = []
        var ifaddrPointer: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddrPointer) == 0, let first = ifaddrPointer else { return [] }
        defer { freeifaddrs(ifaddrPointer) }
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let entry = cursor {
            defer { cursor = entry.pointee.ifa_next }
            let flags = Int32(truncatingIfNeeded: entry.pointee.ifa_flags)
            guard (flags & IFF_UP) != 0, (flags & IFF_LOOPBACK) == 0,
                  let addr = entry.pointee.ifa_addr, addr.pointee.sa_family == UInt8(AF_INET),
                  let mask = entry.pointee.ifa_netmask else { continue }
            let name = String(cString: entry.pointee.ifa_name)
            // Skip tunnels / cellular / link-local-only interfaces.
            guard name.hasPrefix("en") || name.hasPrefix("bridge") else { continue }
            let address = addr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { UInt32(bigEndian: $0.pointee.sin_addr.s_addr) }
            let netmask = mask.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { UInt32(bigEndian: $0.pointee.sin_addr.s_addr) }
            // Ignore 169.254/16 link-local.
            if (address >> 16) == 0xA9FE { continue }
            result.append(IPv4Interface(name: name, address: address, netmask: netmask))
        }
        return result.sorted { $0.name < $1.name }
    }
}
