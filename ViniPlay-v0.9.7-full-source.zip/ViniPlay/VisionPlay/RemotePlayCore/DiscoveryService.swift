import Foundation
import Observation

/// Finds PlayStation consoles on the local network.
///
/// visionOS only allows UDP broadcast with Apple's restricted multicast entitlement,
/// which personal development teams cannot get. VisionPlay therefore sweeps the local
/// IPv4 subnet with *unicast* Sony discovery probes (UDP 9302 for PS5, 987 for PS4).
/// A broadcast probe is still attempted in case the entitlement is present.
@Observable
final class DiscoveryService {
    private(set) var consoles: [DiscoveredConsole] = []
    private(set) var isRunning = false
    private(set) var lastError: ConnectionError?
    private(set) var interfaceDescription = "—"
    private(set) var probesSent = 0

    @ObservationIgnored private var handle: OpaquePointer?
    @ObservationIgnored private var sink: DiscoverySink?
    @ObservationIgnored private var sweepTask: Task<Void, Never>?
    @ObservationIgnored private let probeQueue = DispatchQueue(label: "VisionPlay.discovery.probe", qos: .userInitiated)

    deinit {
        sweepTask?.cancel()
        if let handle { vp_discovery_destroy(handle) }
    }

    func start(extraAddresses: [String] = []) {
        guard !isRunning else { return }
        if case .failure(let error) = ChiakiRuntime.ensureInitialized() {
            lastError = error
            return
        }

        let sink = DiscoverySink { [weak self] host in
            DispatchQueue.main.async { self?.upsert(host) }
        }
        var err = CHIAKI_ERR_SUCCESS
        let unmanaged = Unmanaged.passUnretained(sink).toOpaque()
        guard let created = vp_discovery_create({ hostPointer, user in
            guard let hostPointer, let user else { return }
            let sink = Unmanaged<DiscoverySink>.fromOpaque(user).takeUnretainedValue()
            if let console = DiscoveryService.makeConsole(from: hostPointer.pointee) {
                sink.handler(console)
            }
        }, unmanaged, &err) else {
            lastError = .discoveryFailed(ChiakiRuntime.describe(err))
            vpLog(.error, "discovery", "Failed to open discovery socket: \(ChiakiRuntime.describe(err))")
            return
        }

        self.sink = sink
        handle = created
        isRunning = true
        lastError = nil
        probesSent = 0

        let interfaces = IPv4Interface.current()
        interfaceDescription = interfaces.isEmpty
            ? "No active IPv4 network"
            : interfaces.map { "\($0.name) \($0.addressString)/\($0.prefixLength)" }.joined(separator: ", ")
        vpLog(.info, "discovery", "Starting discovery on \(interfaceDescription)")

        // Known console addresses go first so a registered PS5 is usually found in well under
        // a second; the rest of the subnet follows.
        var seen = Set<String>()
        let targets = (extraAddresses + interfaces.flatMap { $0.subnetHosts() }).filter { seen.insert($0).inserted }
        let handleAddress = Int(bitPattern: created)
        let owner = WeakDiscoveryRef(self)
        sweepTask = Task.detached(priority: .userInitiated) {
            var round = 0
            while !Task.isCancelled {
                guard let pointer = OpaquePointer(bitPattern: handleAddress) else { break }
                // Broadcast (works only with the multicast entitlement) — failures are expected.
                _ = vp_discovery_probe(pointer, nil, true, true)
                var sent = 0
                for (index, address) in targets.enumerated() {
                    if Task.isCancelled { break }
                    _ = address.withCString { vp_discovery_probe(pointer, $0, true, false) }
                    sent += 1
                    // Pace the sweep: ~254 probes in roughly 130 ms.
                    if index % 32 == 31 { try? await Task.sleep(nanoseconds: 15_000_000) }
                }
                let total = sent
                await MainActor.run { owner.value?.probesSent += total }
                round += 1
                // Fast re-probe at first, then settle to a slower cadence.
                let pause: UInt64 = round < 3 ? 1_500_000_000 : 5_000_000_000
                try? await Task.sleep(nanoseconds: pause)
                await MainActor.run { owner.value?.expireStale() }
            }
        }
    }

    func stop() {
        let sweep = sweepTask
        sweep?.cancel()
        sweepTask = nil
        if let handle {
            // Destroy joins the receive thread; do it off the main thread, and only after the
            // sweep has really finished and every queued single-address probe has run — both
            // still hold the raw pointer.
            let address = Int(bitPattern: handle)
            let sink = self.sink
            let queue = probeQueue
            Task.detached(priority: .utility) {
                await sweep?.value
                queue.async {
                    if let pointer = OpaquePointer(bitPattern: address) { vp_discovery_destroy(pointer) }
                    _ = sink // keep the callback target alive until the thread has stopped
                }
            }
        }
        handle = nil
        sink = nil
        isRunning = false
    }

    /// Probes a single address (manual IP entry). Starts discovery if needed.
    func probe(address: String) {
        if !isRunning { start(extraAddresses: [address]) }
        guard let handle else { return }
        let pointerAddress = Int(bitPattern: handle)
        probeQueue.async {
            guard let pointer = OpaquePointer(bitPattern: pointerAddress) else { return }
            _ = address.withCString { vp_discovery_probe(pointer, $0, true, false) }
            _ = address.withCString { vp_discovery_probe(pointer, $0, false, false) }
        }
    }

    private func upsert(_ console: DiscoveredConsole) {
        if let index = consoles.firstIndex(where: { $0.id == console.id }) {
            consoles[index] = console
        } else {
            consoles.append(console)
            vpLog(.info, "discovery", "Found \(console.isPS5 ? "PS5" : "PS4") \"\(console.hostName)\" at \(console.address) (\(console.state.rawValue))")
        }
        consoles.sort { $0.hostName.localizedCaseInsensitiveCompare($1.hostName) == .orderedAscending }
    }

    private func expireStale() {
        let cutoff = Date().addingTimeInterval(-20)
        consoles.removeAll { $0.lastSeen < cutoff }
    }

    func console(forHostID hostID: String) -> DiscoveredConsole? {
        consoles.first { $0.hostID.caseInsensitiveCompare(hostID) == .orderedSame }
    }

    /// Converts the C struct (valid only during the callback) into a Swift value.
    static func makeConsole(from host: VPDiscoveredHost) -> DiscoveredConsole? {
        func string(_ pointer: UnsafePointer<CChar>?) -> String? {
            guard let pointer else { return nil }
            let value = String(cString: pointer)
            return value.isEmpty ? nil : value
        }
        guard let address = string(host.host_addr) else { return nil }
        let state: DiscoveredConsole.PowerState
        switch host.state {
        case 1: state = .ready
        case 2: state = .standby
        default: state = .unknown
        }
        let type = string(host.host_type) ?? ""
        let isPS5 = host.is_ps5 || type.uppercased() == "PS5"
        return DiscoveredConsole(
            hostID: (string(host.host_id) ?? "").uppercased(),
            hostName: string(host.host_name) ?? (isPS5 ? "PS5" : "PS4"),
            address: address,
            isPS5: isPS5,
            state: state,
            systemVersion: string(host.system_version),
            runningAppName: string(host.running_app_name),
            runningAppTitleID: string(host.running_app_titleid),
            lastSeen: Date())
    }
}

/// Retained object passed to C as the callback context.
final class DiscoverySink: @unchecked Sendable {
    let handler: (DiscoveredConsole) -> Void
    init(handler: @escaping (DiscoveredConsole) -> Void) { self.handler = handler }
}

/// Weak, Sendable handle so the background sweep never captures `self` directly.
final class WeakDiscoveryRef: @unchecked Sendable {
    weak var value: DiscoveryService?
    init(_ value: DiscoveryService) { self.value = value }
}
