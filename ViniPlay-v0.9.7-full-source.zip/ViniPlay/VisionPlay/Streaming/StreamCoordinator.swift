import UIKit
import Foundation
import Observation
import CoreVideo

/// Owns the active Remote Play stream and the connection state machine.
///
/// Main-thread state (`phase`, `statistics`, …) drives the UI. Media callbacks arrive on
/// Chiaki/VideoToolbox threads and go straight to the decoder/renderer/audio engine
/// without touching the main thread.
@Observable
final class StreamCoordinator {
    private(set) var machine = ConnectionStateMachine()
    private(set) var statistics = StreamStatistics()
    private(set) var connectedConsole: RegisteredConsole?
    private(set) var statusDetail: String = ""
    /// 0…1 while waiting for a console to wake from rest mode, nil otherwise.
    private(set) var wakeProgress: Double?
    private(set) var microphoneOn = false
    /// How the current/last session is connected ("Home network" or "Internet (PSN)").
    private(set) var routeDescription: String = "—"
    /// Shown when smart connect couldn't find the console locally and Internet Play isn't set up.
    var lanNotFoundMessage: String?
    /// Short notices from adaptive quality / network handling ("Lowered to 720p for this network").
    private(set) var connectionNotice: String?
    private(set) var qualityStepLabel: String = AdaptiveQuality.Step.full.label
    let network = NetworkMonitor()
    private(set) var microphoneError: String?
    var loginPINRequest: LoginPINRequest?

    struct LoginPINRequest: Identifiable, Equatable {
        let id = UUID()
        let previousWasIncorrect: Bool
    }

    var phase: ConnectionPhase { machine.phase }
    var lastError: ConnectionError? { machine.lastError }
    var isActive: Bool { phase == .connecting || phase == .streaming || phase == .reconnecting || phase == .disconnecting }

    @ObservationIgnored let renderer: StreamRenderer?
    @ObservationIgnored let rendererError: String?
    @ObservationIgnored let audio = StreamAudioEngine()
    @ObservationIgnored let controllers: ControllerManager
    @ObservationIgnored let capture = ClipRecorder()
    @ObservationIgnored let glow = ScreenGlowSampler()
    @ObservationIgnored private var pacer: DisplayPacer?
    /// Short message after a screenshot/clip ("Saved to Photos", or the error).
    var captureMessage: String?
    var savingClip = false
    /// Before/after compare (left half: raw stream, right half: processed).
    var compareOn = false {
        didSet { renderer?.compareSplit = compareOn ? 0.5 : 0 }
    }
    @ObservationIgnored private let settings: AppSettings
    @ObservationIgnored private let store: ConsoleStore
    @ObservationIgnored private let discovery: DiscoveryService

    @ObservationIgnored private var session: RemotePlaySession?
    @ObservationIgnored private var sink: SessionSink?
    @ObservationIgnored private var decoder: VideoDecoder?
    @ObservationIgnored private var timing = FrameTimingMonitor()
    @ObservationIgnored private let timingLock = NSLock()
    /// Received video bytes (under timingLock) and the last sample, for the measured bitrate.
    @ObservationIgnored private var videoBytes: UInt64 = 0
    @ObservationIgnored private var lastBitrateSample: (bytes: UInt64, time: Date)?
    @ObservationIgnored private var statsTimer: Timer?
    @ObservationIgnored private var lastStoppedConsoleID: String?
    @ObservationIgnored private var lastStoppedAt: Date?
    @ObservationIgnored private var reconnectAttempt = 0
    /// True once the current connection has shown video at least once. A session that has
    /// never streamed is retried only once — repeating a failing start just hides the cause.
    @ObservationIgnored private var everStreamed = false
    /// Live stages of the current connection attempt (shown while connecting).
    let progress = ConnectionProgress()
    /// Second attempt after a failed start uses safe settings (720p, H.264, 5 Mbps).
    @ObservationIgnored private(set) var safeModeAttempt = false
    /// Set when the PS5 rejected the saved pairing — the UI offers "Pair Again".
    var needsRepairing: RegisteredConsole?
    @ObservationIgnored private var psnConnectTask: Task<Void, Never>?
    @ObservationIgnored private var reconnectTask: Task<Void, Never>?
    @ObservationIgnored private var connectTimeoutTask: Task<Void, Never>?
    @ObservationIgnored private var wakeTask: Task<Void, Never>?
    @ObservationIgnored private var lanCheckTask: Task<Void, Never>?
    @ObservationIgnored private var adaptive = AdaptiveQuality()
    /// Quality step for this game only. Every new game starts at your own settings; a drop for
    /// a bad connection lasts until you end the game and is never remembered.
    @ObservationIgnored private var sessionStep: AdaptiveQuality.Step = .full
    /// Your quality settings when this game's stream started (to spot changes mid-game).
    @ObservationIgnored private var launchedSignature: StreamSettingsSignature?

    /// The settings the PS5 stream itself is made with. They can only change by starting the
    /// stream again, which `applyStreamSettingsLive` does in a few seconds.
    struct StreamSettingsSignature: Equatable {
        var resolution: StreamResolution
        var fps: Int
        var codec: StreamCodec
        var bitrate: UInt32?
    }

    var currentStreamSignature: StreamSettingsSignature {
        StreamSettingsSignature(resolution: settings.resolution, fps: settings.effectiveFPS,
                                codec: settings.codec, bitrate: settings.requestedBitrate(for: settings.resolution))
    }

    /// Resolution, frame rate, codec or bitrate changed during a game: restart the stream with
    /// them (the game keeps running on the PS5; the picture returns in a few seconds).
    func applyStreamSettingsLive() {
        guard phase == .streaming, let launched = launchedSignature, launched != currentStreamSignature else { return }
        sessionStep = .full
        safeModeAttempt = false
        forceReconnect(reason: "applying new quality settings")
    }
    @ObservationIgnored private var currentNetworkKey = "unknown"
    @ObservationIgnored private var waitingForNetwork = false
    @ObservationIgnored private var resumeConsole: RegisteredConsole?
    @ObservationIgnored private var resumeOverInternet = false
    /// Pending "headset taken off" disconnect; cancelled if the app is back within a few seconds.
    @ObservationIgnored private var backgroundDisconnect: Task<Void, Never>?
    @ObservationIgnored private var userRequestedStop = false
    @ObservationIgnored private let policy = ReconnectPolicy()
    @ObservationIgnored private let teardownQueue = DispatchQueue(label: "VisionPlay.session.teardown")

    init(settings: AppSettings, store: ConsoleStore, discovery: DiscoveryService, controllers: ControllerManager) {
        self.settings = settings
        self.store = store
        self.discovery = discovery
        self.controllers = controllers
        do {
            renderer = try StreamRenderer()
            rendererError = nil
        } catch {
            renderer = nil
            rendererError = error.localizedDescription
            vpLog(.error, "render", "Renderer unavailable: \(error.localizedDescription)")
        }
        controllers.onStateChange = { [weak self] state in
            self?.session?.send(controllerState: state)
        }
        controllers.onCaptureCombo = { [weak self] in self?.saveClip() }
        let capture = self.capture, glow = self.glow
        renderer?.frameObserver = { buffer in
            capture.appendVideo(buffer)
            glow.sample(buffer)
        }
        audio.pcmObserver = { samples in capture.appendAudio(samples) }
        if let renderer { pacer = DisplayPacer(renderer: renderer) }
        network.onChange = { [weak self] change in self?.handleNetworkChange(change) }
        // Follow the core's log to show connection stages live.
        let progress = self.progress
        DiagnosticsLog.shared.lineObserver = { _, category, message in
            guard category == "chiaki" else { return }
            DispatchQueue.main.async { progress.ingest(message) }
        }
    }

    // MARK: Network changes, headset on/off

    private func handleNetworkChange(_ change: NetworkMonitor.Change) {
        switch change {
        case .lost:
            guard isActive else { return }
            waitingForNetwork = true
            connectionNotice = "Network lost. VisionPlay will reconnect as soon as it's back."
        case .restored, .switched:
            guard waitingForNetwork || phase == .streaming || phase == .reconnecting else { return }
            waitingForNetwork = false
            connectionNotice = change == .restored ? "Network back. Reconnecting…" : "Network changed. Reconnecting…"
            forceReconnect(reason: "network changed")
        }
    }

    /// Called when the app moves to the background (e.g. the headset is taken off).
    func appDidEnterBackground() {
        guard settings.resumeAfterHeadsetOff, isActive else { return }
        // visionOS can report "background" for a moment while windows swap (Home closing as
        // the game window opens, Custom Screen opening). Only a real absence — still in the
        // background after 5 s, like taking the headset off — ends the stream.
        backgroundDisconnect?.cancel()
        backgroundDisconnect = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(5))
            guard let self, !Task.isCancelled, self.isActive, let console = self.connectedConsole else { return }
            self.resumeConsole = console
            self.resumeOverInternet = self.routeDescription.hasPrefix("Internet")
            vpLog(.info, "stream", "App in the background for 5 s; will resume \(console.nickname) when you're back")
            self.disconnect()
        }
    }

    /// Called when the app becomes active again (headset back on).
    func appDidBecomeActive() {
        backgroundDisconnect?.cancel()   // back in time: keep playing
        backgroundDisconnect = nil
        guard let console = resumeConsole else { return }
        resumeConsole = nil
        guard !isActive else { return }
        connectionNotice = "Welcome back. Resuming \(console.nickname)…"
        if resumeOverInternet { connectOverInternet(to: console) } else { connectAutomatically(to: console) }
    }

    /// Ends the current session and reconnects straight away on the same route.
    func forceReconnect(reason: String) {
        guard let session, let console = connectedConsole else { return }
        let wasRemote = session.configuration.remote != nil
        vpLog(.info, "stream", "Reconnecting (\(reason))")
        reconnectAttempt = 0
        if phase == .streaming || phase == .connecting { machine.transition(to: .reconnecting) }
        statusDetail = "Reconnecting (\(reason))…"
        reconnectTask?.cancel()
        // The PS5 needs a moment to let go of the old stream. Mark it as our own stop so a
        // "Remote Play is already in use" (VP-104) answer is waited out, not shown as an error.
        lastStoppedConsoleID = console.id
        lastStoppedAt = Date()
        teardown(session: session) { [weak self] in
            self?.scheduleReconnect(console: console, remote: wasRemote, delay: 2.5)
        }
    }

    private func scheduleReconnect(console: RegisteredConsole, remote: Bool, delay: TimeInterval) {
        guard phase == .reconnecting, !userRequestedStop else { return }
        reconnectTask?.cancel()
        reconnectTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            guard let self, !Task.isCancelled, self.phase == .reconnecting, !self.userRequestedStop else { return }
            if remote { self.connectOverInternet(to: console) } else { self.startSession(console: console) }
        }
    }

    // MARK: Connect / disconnect

    func connect(to console: RegisteredConsole) {
        guard !isActive else { return }
        routeDescription = "Home network"
        lanNotFoundMessage = nil
        connectionNotice = nil
        userRequestedStop = false
        everStreamed = false
        safeModeAttempt = false
        sessionStep = .full
        needsRepairing = nil
        DiagnosticsLog.shared.markAttemptStart()
        reconnectAttempt = 0
        reconnectTask?.cancel()
        startSession(console: console)
    }

    private func startSession(console: RegisteredConsole) {
        let credentials: ConsoleCredentials
        do {
            guard let stored = try store.credentials(for: console.id), stored.isValid else {
                fail(.missingCredentials)
                return
            }
            credentials = stored
        } catch {
            fail(.missingCredentials)
            return
        }

        // Prefer the address discovery just saw (DHCP can move the console).
        var host = console.lastKnownAddress
        if let seen = discovery.console(forHostID: console.mac) {
            host = seen.address
            store.updateAddress(consoleID: console.id, address: seen.address)
        }

        if phase == .reconnecting {
            machine.transition(to: .connecting)
        } else if !machine.transition(to: .connecting) {
            vpLog(.warning, "stream", "Ignoring connect while \(phase.rawValue)")
            return
        }
        connectedConsole = console
        statusDetail = "Contacting \(console.nickname) at \(host)…"

        // A console in rest mode is woken first; the session starts once discovery reports it ready.
        if let seen = discovery.console(forHostID: console.mac), seen.state == .standby {
            wake(console: console, host: host, credentials: credentials)
            return
        }
        launchSession(console: console, host: host, credentials: credentials)
    }

    /// Sends wake-up packets and waits (up to 45 s) for the console to answer discovery as ready.
    private func wake(console: RegisteredConsole, host: String, credentials: ConsoleCredentials) {
        let timeout: TimeInterval = 45
        statusDetail = "Waking \(console.nickname)…"
        wakeProgress = 0
        if !discovery.isRunning { discovery.start(extraAddresses: [host]) }
        let key = credentials.registKey
        wakeTask?.cancel()
        wakeTask = Task { @MainActor [weak self] in
            let start = Date()
            var lastWake = Date.distantPast
            while !Task.isCancelled {
                guard let self, self.phase == .connecting || self.phase == .reconnecting else { return }
                let elapsed = Date().timeIntervalSince(start)
                if Date().timeIntervalSince(lastWake) >= 10 {
                    lastWake = Date()
                    DispatchQueue.global(qos: .userInitiated).async {
                        let result = key.withUnsafeBytes { raw in
                            host.withCString { vp_wakeup($0, raw.bindMemory(to: CChar.self).baseAddress, console.isPS5) }
                        }
                        vpLog(.info, "stream", "Wake packet to \(host): \(ChiakiRuntime.describe(result))")
                    }
                }
                self.discovery.probe(address: host)
                if let seen = self.discovery.console(forHostID: console.mac), seen.state == .ready {
                    self.wakeProgress = nil
                    vpLog(.info, "stream", "\(console.nickname) is awake after \(Int(elapsed)) s")
                    // Remote Play needs a moment after the console reports ready.
                    try? await Task.sleep(nanoseconds: 2_000_000_000)
                    guard !Task.isCancelled, self.phase == .connecting else { return }
                    self.launchSession(console: console, host: seen.address, credentials: credentials)
                    return
                }
                if elapsed >= timeout {
                    self.wakeProgress = nil
                    self.fail(.consoleAsleep)
                    return
                }
                self.wakeProgress = elapsed / timeout
                self.statusDetail = "Waking \(console.nickname)… \(Int(timeout - elapsed)) s"
                try? await Task.sleep(nanoseconds: 1_000_000_000)
            }
        }
    }

    /// Smart connect: home network when the console answers there, otherwise the internet.
    ///
    /// 1. If discovery has seen the console on this network, connect locally right away.
    /// 2. Otherwise probe its last known address for up to 3 s (it may have just appeared).
    /// 3. If it still isn't on this network and Internet Play is linked, connect through PSN.
    /// 4. Otherwise report that the console wasn't found on this network.
    func connectAutomatically(to console: RegisteredConsole) {
        guard !isActive else { return }
        if discovery.console(forHostID: console.mac) != nil {
            routeDescription = "Home network"
            connect(to: console)
            return
        }
        statusDetail = "Looking for \(console.nickname) on this network…"
        if !discovery.isRunning { discovery.start(extraAddresses: [console.lastKnownAddress]) }
        lanCheckTask?.cancel()
        lanCheckTask = Task { @MainActor [weak self] in
            for _ in 0..<6 {
                guard let self, !Task.isCancelled, !self.isActive else { return }
                self.discovery.probe(address: console.lastKnownAddress)
                try? await Task.sleep(nanoseconds: 500_000_000)
                if self.discovery.console(forHostID: console.mac) != nil {
                    self.routeDescription = "Home network"
                    self.connect(to: console)
                    return
                }
            }
            guard let self, !Task.isCancelled, !self.isActive else { return }
            if console.psnDeviceID != nil {
                vpLog(.info, "stream", "\(console.nickname) is not on this network; using Internet Play")
                self.routeDescription = "Internet (PSN)"
                self.connectOverInternet(to: console)
            } else {
                self.statusDetail = ""
                self.lanNotFoundMessage = VPErrorCode.notFound.message()
            }
        }
    }

    /// Classifies an address as local-network (private/link-local) or not.
    static func isPrivateIPv4(_ address: String) -> Bool {
        guard let value = IPv4Interface.parse(address) else { return false }
        let a = value >> 24, b = (value >> 16) & 0xFF
        return a == 10 || (a == 172 && (16...31).contains(b)) || (a == 192 && b == 168) || (a == 169 && b == 254)
    }

    /// Internet Remote Play through PSN for a console linked under "Internet Play".
    func connectOverInternet(to console: RegisteredConsole) {
        let reconnecting = phase == .reconnecting
        guard !isActive || reconnecting else { return }
        guard let deviceHex = console.psnDeviceID, let deviceID = Data(hexString: deviceHex), deviceID.count == 32 else {
            fail(.unsupportedStream("this console is not linked to a PSN device yet (Internet Play setup)"))
            return
        }
        let credentials: ConsoleCredentials
        do {
            guard let stored = try store.credentials(for: console.id), stored.isValid else { fail(.missingCredentials); return }
            credentials = stored
        } catch { fail(.missingCredentials); return }
        if !reconnecting {
            // Same fresh start as a home connection: no leftover safe mode, retry state or
            // Pair Again prompt from an earlier attempt.
            userRequestedStop = false
            everStreamed = false
            safeModeAttempt = false
            sessionStep = .full
            needsRepairing = nil
            connectionNotice = nil
            DiagnosticsLog.shared.markAttemptStart()
            reconnectAttempt = 0
            statistics.reconnectAttempts = 0
            reconnectTask?.cancel()
        }
        guard machine.transition(to: .connecting) else { return }
        connectedConsole = console
        routeDescription = "Internet (PSN)"
        lanNotFoundMessage = nil
        statusDetail = "Signing in to PlayStation Network…"
        psnConnectTask?.cancel()
        psnConnectTask = Task { @MainActor [weak self] in
            do {
                let token = try await PSNTokenStore.shared.accessToken()
                guard let self, !Task.isCancelled, self.phase == .connecting else { return }
                self.launchSession(console: console, host: "PSN", credentials: credentials,
                                   remote: .init(deviceID: deviceID, accessToken: token))
            } catch {
                guard !Task.isCancelled else { return }
                self?.fail(.authenticationFailed(error.localizedDescription))
            }
        }
    }

    private func launchSession(console: RegisteredConsole, host: String, credentials: ConsoleCredentials,
                               remote: SessionConfiguration.RemoteTarget? = nil) {
        statusDetail = remote == nil
            ? "Connecting to \(console.nickname) at \(host)…"
            : "Connecting to \(console.nickname) over the internet…"
        // Adaptive quality: start from the step remembered for this network.
        currentNetworkKey = remote == nil ? NetworkMonitor.currentNetworkKey() : "internet"
        // Each game starts at full quality (older versions remembered a lower step forever).
        let step = settings.adaptiveQuality ? sessionStep : .full
        launchedSignature = currentStreamSignature
        adaptive = AdaptiveQuality(step: step)
        adaptive.startNewSession()
        qualityStepLabel = step.label
        var (resolution, bitrate) = AdaptiveQuality.apply(step, resolution: settings.resolution,
                                                          bitrate: settings.requestedBitrate(for: settings.resolution))
        var codec = console.isPS5 ? settings.codec : .h264
        progress.begin()
        if safeModeAttempt {
            // Some PS5/router combinations only accept modest settings at first.
            if resolution.rawValue > StreamResolution.p720.rawValue { resolution = .p720 }
            codec = .h264
            bitrate = min(bitrate ?? 5_000, 5_000)
            progress.note = "Retrying with safe settings: \(resolution.label), H.264, \((bitrate ?? 5_000) / 1000) Mbps"
            vpLog(.info, "stream", progress.note ?? "")
        }
        if step != .full { vpLog(.info, "stream", "Adaptive quality for this network: \(step.label)") }

        if remote != nil {
            vp_set_internet_ports(settings.internetFixedPorts ? UInt16(settings.internetControlPort) : 0,
                                  settings.internetFixedPorts ? UInt16(settings.internetDataPort) : 0)
        }

        let configuration = SessionConfiguration(
            host: host, isPS5: console.isPS5, credentials: credentials,
            resolution: resolution, fps: settings.effectiveFPS,
            codec: codec,
            bitrateKbps: bitrate,
            enableDualSense: console.isPS5,
            remote: remote)

        let codecKind: VideoCodecKind = configuration.codec == .h264 ? .h264 : .hevc
        let decoder = VideoDecoder(codec: codecKind, tenBit: configuration.codec == .hevcHDR)
        let sink = SessionSink(coordinator: self, decoder: decoder)
        decoder.output = sink
        self.decoder = decoder
        self.sink = sink

        renderer?.resetStats()
        lastBitrateSample = nil
        statistics.receivedKbps = 0
        renderer?.compareSplit = compareOn ? 0.5 : 0
        renderer?.setConfiguration(settings.upscalerConfiguration)
        timingLock.lock(); timing = FrameTimingMonitor(expectedFPS: settings.effectiveFPS); timingLock.unlock()
        controllers.motionEnabled = settings.motionControls
        audio.volume = Float(settings.volume)
        applyMotionAndCaptureSettings()

        let session = RemotePlaySession(configuration: configuration)
        session.delegate = sink
        sink.attach(session: session)
        self.session = session

        if remote != nil {
            // The PSN exchange blocks for several seconds: run it off the main thread.
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let failure: ConnectionError?
                do { try session.start(); failure = nil }
                catch let error as ConnectionError { failure = error }
                catch { failure = .network(error.localizedDescription) }
                DispatchQueue.main.async {
                    guard let self, self.session === session else { return }
                    if let failure {
                        self.teardown(session: session)
                        self.fail(failure)
                    } else {
                        self.startStatsTimer()
                        self.armConnectTimeout()
                    }
                }
            }
            return
        }

        do {
            try session.start()
        } catch let error as ConnectionError {
            teardown(session: session)
            fail(error)
            return
        } catch {
            teardown(session: session)
            fail(.network(error.localizedDescription))
            return
        }
        startStatsTimer()
        armConnectTimeout()
    }

    private func armConnectTimeout() {
        connectTimeoutTask?.cancel()
        connectTimeoutTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 45_000_000_000)
            guard let self, !Task.isCancelled, self.phase == .connecting else { return }
            vpLog(.error, "stream", "Connection timed out")
            self.handleQuit(reason: -1, isError: true, message: "")
        }
    }

    func disconnect() {
        loginPINRequest = nil   // a PIN question belongs to this session only
        if let console = connectedConsole {
            lastStoppedConsoleID = console.id
            lastStoppedAt = Date()
        }
        userRequestedStop = true
        psnConnectTask?.cancel()
        reconnectTask?.cancel()
        connectTimeoutTask?.cancel()
        wakeTask?.cancel()
        lanCheckTask?.cancel()
        wakeProgress = nil
        guard phase == .connecting || phase == .streaming || phase == .reconnecting else { return }
        machine.transition(to: .disconnecting)
        statusDetail = "Disconnecting…"
        if let session {
            session.stop()
            teardown(session: session) { [weak self] in
                guard let self else { return }
                self.machine.transition(to: .disconnected)
                self.statusDetail = ""
                self.connectedConsole = nil
            }
        } else {
            machine.transition(to: .disconnected)
            statusDetail = ""
            connectedConsole = nil
        }
    }

    /// Releases session, decoder and media resources. The blocking join happens off the main thread.
    private func teardown(session: RemotePlaySession, completion: (() -> Void)? = nil) {
        stopStatsTimer()
        connectTimeoutTask?.cancel()
        self.session = nil
        let decoder = self.decoder
        self.decoder = nil
        let sink = self.sink
        self.sink = nil
        sink?.detach()
        microphoneOn = false
        audio.stop()
        pacer?.stop()
        capture.invalidate()
        controllers.resetFeedback()
        // Cancel first (non-blocking): ends a stream, or aborts an Internet connect that is
        // still running, so destroy() below isn't left waiting for it.
        session.stop()
        teardownQueue.async { [renderer] in
            session.destroy()
            decoder?.invalidate()
            renderer?.releaseResources()
            DispatchQueue.main.async { completion?() }
        }
    }

    private func fail(_ error: ConnectionError) {
        vpLog(.error, "stream", error.localizedDescription)
        machine.fail(error)
        statusDetail = ""
        connectedConsole = nil
    }

    // MARK: Session events (main thread)

    fileprivate func handleConnected() {
        connectTimeoutTask?.cancel()
        guard machine.transition(to: .streaming) else { return }
        reconnectAttempt = 0
        statistics.reconnectAttempts = 0
        everStreamed = true
        progress.finishedOK()
        if safeModeAttempt {
            connectionNotice = "Connected with safe settings (720p, H.264). Your normal settings were refused at first — try them again later."
        }
        statusDetail = "Streaming from \(connectedConsole?.nickname ?? "console")"
        vpLog(.info, "stream", "Remote Play session established")
    }

    fileprivate func handleQuit(reason: Int32, isError: Bool, message: String) {
        loginPINRequest = nil
        vpLog(isError ? .error : .info, "stream",
              "Session ended: \(message.isEmpty ? "-" : message) (reason \(reason)\(isError ? ", " + VPErrorCode.forQuitReason(reason).code : ""))")
        guard let session else { return }
        let console = connectedConsole
        let wasStreaming = phase == .streaming
        let wasRemote = session.configuration.remote != nil

        let neverStarted = !everStreamed && !wasStreaming
        // VP-102 is a catch-all; use what the PS5 actually said when the log told us.
        let refined: VPErrorCode? = (reason == 2) ? progress.sessionRefusal : nil
        let failureCode = refined ?? VPErrorCode.forQuitReason(reason)
        if neverStarted && isError {
            progress.fail(failureCode.code + (progress.applicationReason.map { " (PS5 reason \($0))" } ?? ""))
        }
        if neverStarted && (reason == 9 || refined == .pairingInvalid || refined == .psnAccountMismatch), let console {
            needsRepairing = console
        }
        let recentOwnSessionBusy = ReconnectPolicy.canWaitForOwnSessionRelease(reason: reason,
            sameConsole: console?.id == lastStoppedConsoleID,
            secondsSinceStop: lastStoppedAt.map { Date().timeIntervalSince($0) }, attempt: reconnectAttempt)
        if recentOwnSessionBusy, !userRequestedStop, let console {
            reconnectAttempt += 1
            machine.transition(to: .reconnecting)
            statusDetail = "Waiting for the PS5 to release your previous session…"
            teardown(session: session) { [weak self] in
                self?.scheduleReconnect(console: console, remote: wasRemote, delay: 5)
            }
            return
        }
        let shouldRetry = !userRequestedStop && settings.reconnection && console != nil
            && ReconnectPolicy.shouldRetry(quitReason: reason, isError: isError)
            && (!neverStarted || reconnectAttempt == 0)
            && refined != .pairingInvalid && refined != .psnAccountMismatch   // retrying can't fix a bad pairing
        if shouldRetry, let console, let delay = policy.delay(forAttempt: reconnectAttempt + 1) {
            reconnectAttempt += 1
            machine.transition(to: .reconnecting)
            if neverStarted {
                safeModeAttempt = true
                // The PS5's address may have changed (router restart): look for it again first.
                discovery.probe(address: console.lastKnownAddress)
                if !discovery.isRunning { discovery.start(extraAddresses: [console.lastKnownAddress]) }
            }
            statusDetail = neverStarted
                ? "Couldn't start the stream — retrying once with safe settings…"
                : "Connection lost — reconnecting in \(Int(delay)) s (attempt \(reconnectAttempt)/\(policy.maxAttempts))"
            statistics.reconnectAttempts = reconnectAttempt
            teardown(session: session) { [weak self] in
                self?.scheduleReconnect(console: console, remote: wasRemote, delay: max(0.5, delay))
            }
            return
        }

        let error: ConnectionError? = {
            guard isError else { return nil }
            if neverStarted {
                // Tell the user exactly which step failed and what to do about it.
                let ps5Said = [progress.applicationReason.map { "reason \($0)" }, message.isEmpty ? nil : message]
                    .compactMap { $0 }.joined(separator: ", ")
                return .network(failureCode.message(detail: ps5Said))
            }
            switch reason {
            case 4: return .consoleBusy
            case 9: return .authenticationFailed(message)
            case 6: return .unsupportedStream(message)
            case 11, 12: return .remoteDisconnected(message)
            default: return wasStreaming ? .remoteDisconnected(message) : .network(message)
            }
        }()
        if phase != .disconnecting { machine.transition(to: .disconnecting, error: error) }
        teardown(session: session) { [weak self] in
            guard let self else { return }
            self.machine.transition(to: .disconnected, error: error)
            self.statusDetail = ""
            self.connectedConsole = nil
        }
    }

    fileprivate func handleLoginPINRequest(previousWasIncorrect: Bool) {
        loginPINRequest = LoginPINRequest(previousWasIncorrect: previousWasIncorrect)
    }

    func submitLoginPIN(_ pin: String) {
        loginPINRequest = nil
        session?.setLoginPIN(pin)
    }

    /// Party chat / game voice: toggles the Vision Pro microphone into the PS5 session.
    func toggleMicrophone() {
        guard phase == .streaming, let session else { return }
        let enable = !microphoneOn
        guard enable else {
            session.setMicrophoneEnabled(false)
            audio.setMicrophone(enabled: false, sink: nil)
            microphoneOn = false
            return
        }
        StreamAudioEngine.requestMicrophonePermission { [weak self] granted in
            guard let self, granted, self.session === session else {
                self?.microphoneError = granted ? nil : "Microphone access is off for VisionPlay (Settings › Privacy & Security › Microphone)."
                return
            }
            guard session.setMicrophoneEnabled(true) else {
                self.microphoneError = "The console did not accept the microphone."
                return
            }
            self.microphoneError = nil
            self.audio.setMicrophone(enabled: true) { [weak session] block in session?.sendMicrophone(block) }
            self.microphoneOn = true
        }
    }

    /// Smooth Motion and Instant Replay can change while streaming.
    func applyMotionAndCaptureSettings() {
        // The Custom Screen is presented by RealityKit at the headset's own rate, so the
        // 120 Hz display link (main-thread work every refresh) is only for a window screen.
        if settings.effectiveSmoothMotion && renderer?.hasTheaterTarget != true { pacer?.start() } else { pacer?.stop() }
        audio.maxLatencyMilliseconds = settings.audioBufferMilliseconds
        // Instant Replay was removed: it kept the hardware encoder recording all game long.
        capture.setEnabled(false)
    }

    func saveScreenshot() {
        let frame = renderer?.latestFrame
        Task { @MainActor [weak self] in
            do {
                try await ClipRecorder.saveScreenshot(frame)
                self?.showCaptureMessage("Screenshot saved to Photos")
            } catch {
                self?.showCaptureMessage(error.localizedDescription)
            }
        }
    }

    /// Saves the last 30 seconds (Instant Replay) to Photos.
    func saveClip() {
        guard !savingClip else { return }
        guard settings.instantReplay else {
            showCaptureMessage("Turn on Instant Replay in Settings to save clips.")
            return
        }
        savingClip = true
        let capture = self.capture
        Task { @MainActor [weak self] in
            do {
                _ = try await capture.saveClip(seconds: 30)
                self?.showCaptureMessage("Last 30 seconds saved to Photos")
            } catch {
                self?.showCaptureMessage(error.localizedDescription)
            }
            self?.savingClip = false
        }
    }

    private func showCaptureMessage(_ text: String) {
        captureMessage = text
        Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(3))
            if self?.captureMessage == text { self?.captureMessage = nil }
        }
    }

    func goHome() { session?.goHome() }
    func putConsoleToSleep() { session?.putConsoleToSleep() }

    func writeDisplayStatus() {
        let r = renderer?.currentStats ?? RenderStats()
        let values: [String: Any] = [
            "mlCapability": LiveNeuralUpscaler.capabilitySummary,
            "mlStatus": r.neuralStatus,
            "outputWidth": r.outputWidth, "outputHeight": r.outputHeight,
            "renderedFrames": r.framesRendered, "scaler": r.technique.rawValue,
            "inputWidth": statistics.streamWidth, "inputHeight": statistics.streamHeight,
            "fps": r.presentedFPS, "gpuMs": r.gpuMillisecondsAverage,
            "distance": settings.viewingDistance, "renderedScreenWidth": settings.renderedScreenWidth,
            "imaxScale": settings.imaxScale, "pinned": settings.pinScreenToRoom,
            "outputSetting": settings.outputTarget.rawValue, "upscaling": settings.upscalingEnabled,
            "lowLatency": settings.lowLatency,
            "rttMs": statistics.rttMilliseconds,
            "decoderMs": statistics.decoder.averageDecodeMilliseconds,
            "presentationLatencyMs": r.pipelineLatencyMilliseconds,
            "receivedKbps": statistics.receivedKbps
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: values, options: [.prettyPrinted, .sortedKeys]),
              let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        try? data.write(to: folder.appendingPathComponent("DisplayStatus.json"), options: .atomic)
    }

    func setPresentationScene(_ scene: UIWindowScene) { pacer?.setWindowScene(scene) }

    func applyUpscalerSettings() {
        renderer?.setConfiguration(settings.upscalerConfiguration)
    }

    func setVolume(_ value: Double) { audio.volume = Float(value) }

    // MARK: Media path (background threads)

    /// Frame timing for statistics (lock-protected; called from the network thread). Decoding
    /// and keyframe requests go through the session's own sink, never through `decoder` or
    /// `session` here, which the main thread clears on teardown.
    fileprivate func recordVideo(bytes: Int, framesLost: Int32) {
        let nowMs = Double(MachTime.nanoseconds(mach_absolute_time())) / 1_000_000
        timingLock.lock()
        timing.record(arrivalMilliseconds: nowMs, framesLostBefore: framesLost)
        videoBytes &+= UInt64(bytes)
        timingLock.unlock()
    }

    // MARK: Statistics

    private func startStatsTimer() {
        stopStatsTimer()
        let timer = Timer(timeInterval: 1.0, repeats: true) { [weak self] _ in self?.sampleStatistics() }
        RunLoop.main.add(timer, forMode: .common)
        statsTimer = timer
    }

    private func stopStatsTimer() {
        statsTimer?.invalidate()
        statsTimer = nil
    }

    private func sampleStatistics() {
        var s = statistics
        timingLock.lock()
        s.networkFPS = timing.measuredFPS
        s.jitterMilliseconds = timing.jitterMilliseconds
        s.framesLost = timing.framesLost
        s.lateFrames = timing.lateFrames
        let bytes = videoBytes
        timingLock.unlock()
        let now = Date()
        if let last = lastBitrateSample, now.timeIntervalSince(last.time) > 0.2 {
            let kbps = Double(bytes &- last.bytes) * 8 / 1000 / now.timeIntervalSince(last.time)
            s.receivedKbps = s.receivedKbps == 0 ? kbps : s.receivedKbps * 0.6 + kbps * 0.4
        }
        lastBitrateSample = (bytes, now)
        if let net = session?.networkStats() {
            s.rttMilliseconds = net.rttMilliseconds
            s.packetLossPercent = net.packetLoss * 100
            s.bitrateKbps = net.bitrateKbps
            s.streamWidth = net.width
            s.streamHeight = net.height
            s.codec = net.codec?.label ?? "—"
        }
        if let decoder { s.decoder = decoder.currentStats }
        if let renderer { s.render = renderer.currentStats }
        s.audio = audio.currentStats
        s.quality = PictureQualityMeter.make(receivedKbps: s.receivedKbps, requestedKbps: Double(s.bitrateKbps),
                                             width: s.streamWidth, height: s.streamHeight, fps: max(s.networkFPS, 1))
        s.lag = LagEstimate.make(rttMs: s.rttMilliseconds, fps: settings.effectiveFPS,
                                 decodeMs: s.decoder.averageDecodeMilliseconds,
                                 decodeToDisplayMs: s.render.pipelineLatencyMilliseconds,
                                 refreshHz: s.render.displayRefreshHz)
        statistics = s
        writeDisplayStatus()
        if phase == .streaming && settings.adaptiveQuality { evaluateAdaptiveQuality(s) }
    }

    private func evaluateAdaptiveQuality(_ s: StreamStatistics) {
        switch adaptive.record(packetLossPercent: s.packetLossPercent, rttMilliseconds: s.rttMilliseconds) {
        case .none:
            break
        case .downgradeNextSession:
            connectionNotice = "Connection is struggling (packet loss). Picture quality may drop."
        case .downgradeNow(let step):
            sessionStep = step
            connectionNotice = "Heavy packet loss: reconnecting at \(step.label) for this game. The next game starts at full quality again."
            forceReconnect(reason: "switching to \(step.label)")
        case .upgradeNextSession:
            break
        }
    }

    /// Clears the remembered quality step for the current network (Settings › Reset Adaptive Quality).
    func resetAdaptiveQuality() {
        AdaptiveQuality.store(.full, network: NetworkMonitor.currentNetworkKey())
        AdaptiveQuality.store(.full, network: "internet")
        qualityStepLabel = AdaptiveQuality.Step.full.label
    }
}

/// Bridges session/decoder callbacks (background threads) to the coordinator.
private final class SessionSink: RemotePlaySessionDelegate, VideoDecoderOutput, @unchecked Sendable {
    private weak var coordinator: StreamCoordinator?
    /// This session's own decoder and session, fixed for the sink's lifetime, so the network
    /// and decoder threads never read the coordinator's properties while teardown clears them.
    private let videoDecoder: VideoDecoder
    private weak var session: RemotePlaySession?
    private var lastKeyframeRequest: UInt64 = 0
    private let lock = NSLock()
    private var detached = false


    init(coordinator: StreamCoordinator, decoder: VideoDecoder) {
        self.coordinator = coordinator
        self.videoDecoder = decoder
    }

    func attach(session: RemotePlaySession) { lock.lock(); self.session = session; lock.unlock() }

    func detach() { lock.lock(); detached = true; lock.unlock() }
    private var isDetached: Bool { lock.lock(); defer { lock.unlock() }; return detached }

    // RemotePlaySessionDelegate
    func sessionDidConnect(_ session: RemotePlaySession) {
        DispatchQueue.main.async { [weak self] in
            guard let self, !self.isDetached else { return }
            self.coordinator?.handleConnected()
        }
    }

    func session(_ session: RemotePlaySession, didQuitWithReason reason: Int32, isError: Bool, message: String) {
        DispatchQueue.main.async { [weak self] in
            guard let self, !self.isDetached else { return }
            self.coordinator?.handleQuit(reason: reason, isError: isError, message: message)
        }
    }

    func sessionRequestsLoginPIN(_ session: RemotePlaySession, previousWasIncorrect: Bool) {
        DispatchQueue.main.async { [weak self] in self?.coordinator?.handleLoginPINRequest(previousWasIncorrect: previousWasIncorrect) }
    }

    func session(_ session: RemotePlaySession, didReceiveVideo data: UnsafeBufferPointer<UInt8>, framesLost: Int32, recovered: Bool) -> Bool {
        guard !isDetached else { return true }
        coordinator?.recordVideo(bytes: data.count, framesLost: framesLost)
        return videoDecoder.decode(accessUnit: data)
    }

    func session(_ session: RemotePlaySession, didReceiveAudioHeader channels: Int, sampleRate: Int, frameSize: Int) {
        guard !isDetached else { return }
        coordinator?.audio.configure(channels: channels, sampleRate: sampleRate, frameSize: frameSize)
    }

    func session(_ session: RemotePlaySession, didReceiveAudioPacket data: UnsafeBufferPointer<UInt8>) {
        guard !isDetached else { return }
        coordinator?.audio.enqueue(packet: data)
    }

    func session(_ session: RemotePlaySession, rumbleLeft left: UInt8, right: UInt8) {
        // Vibration is not used: rumble is ignored.
    }

    func session(_ session: RemotePlaySession, triggerEffectsLeft typeLeft: UInt8, _ left: [UInt8], right typeRight: UInt8, _ right: [UInt8]) {
        DispatchQueue.main.async { [weak self] in
            self?.coordinator?.controllers.applyTriggerEffects(typeLeft: typeLeft, left: left, typeRight: typeRight, right: right)
        }
    }

    func session(_ session: RemotePlaySession, lightBarColor rgb: UInt32) {
        DispatchQueue.main.async { [weak self] in self?.coordinator?.controllers.setLightBar(rgb: rgb) }
    }

    func session(_ session: RemotePlaySession, didReceiveHaptics samples: UnsafeBufferPointer<Int16>) {
        // Vibration is not used: the haptics stream is ignored.
    }

    func session(_ session: RemotePlaySession, decoderFailureAtFrame frame: Int32) {
        vpLog(.debug, "stream", "FEC failure at frame \(frame)")
    }

    // VideoDecoderOutput
    func decoder(_ decoder: VideoDecoder, didDecode pixelBuffer: CVPixelBuffer, frameNumber: UInt64, submittedAt: UInt64) {
        guard !isDetached else { return }
        coordinator?.renderer?.submit(pixelBuffer: pixelBuffer, submittedAt: submittedAt)
    }

    func decoderNeedsKeyframe(_ decoder: VideoDecoder, reason: String) {
        // Rate-limit IDR requests to one every 500 ms.
        let now = mach_absolute_time()
        lock.lock()
        guard !detached, MachTime.milliseconds(from: lastKeyframeRequest, to: now) >= 500 else { lock.unlock(); return }
        lastKeyframeRequest = now
        let session = self.session
        lock.unlock()
        vpLog(.debug, "stream", "Requesting keyframe (\(reason))")
        session?.requestKeyframe()
    }
}
