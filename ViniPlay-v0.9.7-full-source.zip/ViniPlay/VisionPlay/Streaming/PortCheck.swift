import Foundation
import Network

/// Checks that the PS5's Remote Play control port (TCP 9295) accepts a connection.
/// Opens and immediately closes a TCP connection; nothing is sent.
enum PortCheck {
    enum Result: Equatable, Sendable {
        case open
        case refused
        case timedOut
        case failed(String)

        var summary: String {
            switch self {
            case .open: return "Remote Play port (TCP 9295) is open"
            case .refused: return "The PS5 refused TCP 9295 — Remote Play may be off on the PS5 (\(VPErrorCode.sessionRefused.code))"
            case .timedOut: return "No answer on TCP 9295 — something is blocking the connection (\(VPErrorCode.controlConnect.code))"
            case .failed(let why): return "Couldn't test TCP 9295: \(why)"
            }
        }
        var passed: Bool { self == .open }
    }

    static func tcp(host: String, port: UInt16 = 9295, timeout: TimeInterval = 4) async -> Result {
        guard let nwPort = NWEndpoint.Port(rawValue: port) else { return .failed("bad port") }
        let connection = NWConnection(host: NWEndpoint.Host(host), port: nwPort, using: .tcp)
        return await withCheckedContinuation { (continuation: CheckedContinuation<Result, Never>) in
            let lock = NSLock()
            var finished = false
            func finish(_ result: Result) {
                lock.lock(); defer { lock.unlock() }
                guard !finished else { return }
                finished = true
                connection.cancel()
                continuation.resume(returning: result)
            }
            connection.stateUpdateHandler = { state in
                switch state {
                case .ready: finish(.open)
                case .waiting(let error), .failed(let error):
                    if case .posix(let code) = error, code == .ECONNREFUSED { finish(.refused) }
                    else if case .waiting = state { /* keep waiting until timeout */ }
                    else { finish(.failed(error.localizedDescription)) }
                default: break
                }
            }
            connection.start(queue: DispatchQueue(label: "VisionPlay.portcheck"))
            DispatchQueue.global().asyncAfter(deadline: .now() + timeout) { finish(.timedOut) }
        }
    }
}
