import Foundation
import Observation

/// The stages of starting a Remote Play stream, followed live from the session's log and
/// events so the screen can show exactly where a connection stops.
@Observable
final class ConnectionProgress {
    enum Stage: Int, CaseIterable, Identifiable, Sendable {
        case found, accepted, control, networkTest, video
        var id: Int { rawValue }

        var title: String {
            switch self {
            case .found: return "Contacting the PS5"
            case .accepted: return "PS5 accepted the session"
            case .control: return "Control link open"
            case .networkTest: return "Network test"
            case .video: return "Video arriving"
            }
        }

        /// The error code most likely when this is the stage that failed.
        var failureCode: VPErrorCode {
            switch self {
            case .found: return .controlConnect
            case .accepted: return .sessionRefused
            case .control: return .controlConnect
            case .networkTest: return .streamNeverArrived
            case .video: return .streamNeverArrived
            }
        }
    }

    enum Status: Equatable, Sendable { case pending, active, done, failed }

    private(set) var statuses: [Stage: Status] = [:]
    private(set) var detail: [Stage: String] = [:]
    private(set) var isRunning = false
    /// Fallback attempt label, e.g. "Retrying at 720p, H.264".
    var note: String?
    /// What the PS5 said when it refused the session request (refines VP-102).
    private(set) var sessionRefusal: VPErrorCode?
    private(set) var applicationReason: String?

    init() { reset() }

    func status(_ stage: Stage) -> Status { statuses[stage] ?? .pending }

    var furthestDone: Stage? { Stage.allCases.last { status($0) == .done } }
    var failedStage: Stage? { Stage.allCases.first { status($0) == .failed } }

    func reset() {
        for stage in Stage.allCases { statuses[stage] = .pending }
        detail = [:]
        note = nil
        sessionRefusal = nil
        applicationReason = nil
        isRunning = false
    }

    func begin() {
        reset()
        isRunning = true
        statuses[.found] = .active
    }

    func complete(_ stage: Stage, _ info: String? = nil) {
        for s in Stage.allCases where s.rawValue < stage.rawValue && status(s) != .done { statuses[s] = .done }
        statuses[stage] = .done
        if let info { detail[stage] = info }
        if let next = Stage(rawValue: stage.rawValue + 1), status(next) == .pending { statuses[next] = .active }
        if stage == .video { isRunning = false }
    }

    /// Marks the stage that was in progress as failed.
    func fail(_ info: String? = nil) {
        guard isRunning else { return }
        let stage = Stage.allCases.first { status($0) == .active } ?? .found
        statuses[stage] = .failed
        if let info { detail[stage] = info }
        isRunning = false
    }

    func finishedOK() { if isRunning { complete(.video) } }

    /// Maps a chiaki log line to progress. Pure, for tests; returns the stage it completes
    /// (or nil) and whether the line reports a failure.
    static func interpret(_ message: String) -> (stage: Stage?, failed: Bool, info: String?) {
        if message.hasPrefix("Trying to request session from") { return (nil, false, nil) }
        if message.contains("Session request successful") { return (.found, false, nil) }   // reply received
        if message.hasPrefix("Starting ctrl") { return (.accepted, false, nil) }
        if message.contains("Ctrl received Login message: success") || message.hasPrefix("Ctrl received valid Session Id") {
            return (.control, false, nil)
        }
        if message.contains("Senkusha completed successfully") { return (.networkTest, false, nil) }
        if message.hasPrefix("Ctrl got Server Type") { return (nil, false, String(message.dropFirst("Ctrl got ".count))) }
        if message.contains("Downgrading") { return (nil, false, message) }
        // chiaki carries on with safe defaults when the network test fails, so it isn't fatal.
        if message.contains("Senkusha failed") { return (.networkTest, false, "test failed; using safe defaults") }
        if message.contains("Ctrl failed") || message.contains("Failed to connect") { return (nil, true, message) }
        return (nil, false, nil)
    }

    func ingest(_ message: String) {
        guard isRunning else { return }
        if let refusal = VPErrorCode.sessionRefusal(fromLog: message) { sessionRefusal = refusal }
        if let reason = VPErrorCode.applicationReason(fromLog: message) { applicationReason = reason }
        let result = Self.interpret(message)
        if let stage = result.stage { complete(stage, result.info) }
        else if result.failed { fail(result.info) }
        else if let info = result.info, let active = Stage.allCases.first(where: { status($0) == .active }) {
            detail[active] = info
        }
    }
}
