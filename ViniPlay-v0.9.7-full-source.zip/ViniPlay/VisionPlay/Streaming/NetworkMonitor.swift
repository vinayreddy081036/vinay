import Foundation
import Network
import Observation

/// Watches the Vision Pro's own network (Wi-Fi up/down, roaming to another interface or
/// network) so a stream can be re-established immediately instead of waiting for the
/// console to time out.
@Observable
final class NetworkMonitor {
    enum Change: Equatable, Sendable {
        case lost                 // no usable network
        case restored             // back after being lost
        case switched(String)     // different interface or local address
    }

    private(set) var isConnected = true
    private(set) var interfaceName = "—"
    private(set) var localAddress: String?
    private(set) var changeCount = 0

    @ObservationIgnored var onChange: ((Change) -> Void)?
    @ObservationIgnored private let monitor = NWPathMonitor()
    @ObservationIgnored private let queue = DispatchQueue(label: "VisionPlay.network")
    @ObservationIgnored private var lastSignature: String?
    @ObservationIgnored private var wasConnected = true

    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            let connected = path.status == .satisfied
            let interface = path.availableInterfaces.first.map { iface -> String in
                switch iface.type {
                case .wifi: return "Wi-Fi (\(iface.name))"
                case .wiredEthernet: return "Ethernet (\(iface.name))"
                case .cellular: return "Cellular"
                default: return iface.name
                }
            } ?? "None"
            let address = IPv4Interface.current().first?.addressString
            DispatchQueue.main.async { self?.update(connected: connected, interface: interface, address: address) }
        }
        monitor.start(queue: queue)
    }

    deinit { monitor.cancel() }

    private func update(connected: Bool, interface: String, address: String?) {
        let signature = "\(interface)|\(address ?? "-")"
        defer {
            isConnected = connected
            interfaceName = interface
            localAddress = address
            wasConnected = connected
        }
        guard let previous = lastSignature else {
            lastSignature = signature
            return
        }
        if !connected && wasConnected {
            changeCount += 1
            vpLog(.warning, "network", "Network lost")
            onChange?(.lost)
        } else if connected && !wasConnected {
            changeCount += 1
            lastSignature = signature
            vpLog(.info, "network", "Network restored: \(signature)")
            onChange?(.restored)
        } else if connected && signature != previous {
            changeCount += 1
            lastSignature = signature
            vpLog(.info, "network", "Network changed: \(previous) → \(signature)")
            onChange?(.switched(signature))
        }
    }

    /// Identifies the current network for remembering per-network quality (e.g. "192.168.1.0/24").
    static func currentNetworkKey() -> String {
        guard let iface = IPv4Interface.current().first else { return "unknown" }
        let network = iface.address & iface.netmask
        return "\(IPv4Interface.format(network))/\(iface.prefixLength)"
    }
}
