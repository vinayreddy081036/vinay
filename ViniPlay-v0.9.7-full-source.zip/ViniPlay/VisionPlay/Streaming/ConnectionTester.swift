import Foundation

/// Measures the home-network path to a console (round trip, jitter, loss) using the PS5's
/// own discovery replies, then turns the numbers into plain advice and suggested settings.
struct ConnectionTestResult: Equatable, Sendable {
    enum Grade: String, Sendable {
        case excellent = "Excellent"
        case good = "Good"
        case fair = "Fair"
        case poor = "Poor"
        case unreachable = "Not reachable"
    }

    struct SuggestedSettings: Equatable, Sendable {
        var resolution: StreamResolution
        var fps: Int
        var mode: UpscaleMode
        var networkMode: NetworkMode
    }

    var samples: [Double]           // ms, -1 = lost
    var medianMilliseconds: Double
    var jitterMilliseconds: Double
    var lossPercent: Double
    var grade: Grade
    var advice: [String]
    var suggested: SuggestedSettings?

    static func analyze(samples: [Double], interface: String = "") -> ConnectionTestResult {
        let received = samples.filter { $0 >= 0 }
        let loss = samples.isEmpty ? 100 : Double(samples.count - received.count) / Double(samples.count) * 100
        guard !received.isEmpty else {
            return ConnectionTestResult(samples: samples, medianMilliseconds: 0, jitterMilliseconds: 0, lossPercent: 100,
                                        grade: .unreachable,
                                        advice: ["The console didn't answer on this network. Check it's on (or in rest mode) and on the same Wi-Fi/LAN as the Vision Pro, or use Internet Play."],
                                        suggested: nil)
        }
        let sorted = received.sorted()
        let median = sorted.count % 2 == 1 ? sorted[sorted.count / 2] : (sorted[sorted.count / 2 - 1] + sorted[sorted.count / 2]) / 2
        // Jitter as mean absolute difference between consecutive replies (RFC 3550 style).
        var diffs: [Double] = []
        for i in 1..<max(received.count, 1) where i < received.count { diffs.append(abs(received[i] - received[i - 1])) }
        let jitter = diffs.isEmpty ? 0 : diffs.reduce(0, +) / Double(diffs.count)

        let grade: Grade
        let suggested: SuggestedSettings
        switch (median, jitter, loss) {
        case let (m, j, l) where m < 8 && j < 4 && l < 1:
            grade = .excellent
            suggested = .init(resolution: .p1080, fps: 60, mode: .quality, networkMode: .automatic)
        case let (m, j, l) where m < 20 && j < 8 && l < 3:
            grade = .good
            suggested = .init(resolution: .p1080, fps: 60, mode: .balanced, networkMode: .automatic)
        case let (m, _, l) where m < 40 && l < 8:
            grade = .fair
            suggested = .init(resolution: .p720, fps: 60, mode: .balanced, networkMode: .lowLatency)
        default:
            grade = .poor
            suggested = .init(resolution: .p720, fps: 30, mode: .performance, networkMode: .lowLatency)
        }

        var advice: [String] = []
        if loss >= 3 || median >= 20 {
            advice.append("Move closer to the router or use its 5 GHz/6 GHz network; 2.4 GHz Wi-Fi is the most common cause of stutter.")
        }
        if jitter >= 8 {
            advice.append("Timing is uneven (jitter \(Int(jitter.rounded())) ms): other devices streaming or downloading on the same Wi-Fi compete with Remote Play.")
        }
        if median >= 10 || loss >= 1 {
            advice.append("Connect the PS5 to the router with an Ethernet cable; it halves the wireless hops.")
        }
        if interface.lowercased().contains("cellular") {
            advice.append("You're on a cellular/hotspot connection; expect higher latency.")
        }
        advice.append("Tip: reserve a fixed IP address for the PS5 in your router (DHCP reservation) so it's found instantly every time.")
        if grade == .excellent {
            advice.insert("Your network is ready for 1080p60 with Quality upscaling to 4K.", at: 0)
        }
        return ConnectionTestResult(samples: samples, medianMilliseconds: median, jitterMilliseconds: jitter,
                                    lossPercent: loss, grade: grade, advice: advice, suggested: suggested)
    }

    /// Runs `count` probes (≈ count × 0.1–0.35 s) off the main thread.
    static func run(address: String, ps5: Bool, count: Int = 30, interface: String = "") async -> ConnectionTestResult {
        let samples: [Double] = await withCheckedContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                var buffer = [Double](repeating: -1, count: count)
                let err = address.withCString { ip in
                    buffer.withUnsafeMutableBufferPointer { vp_measure_rtt(ip, ps5, Int32(count), 300, $0.baseAddress) }
                }
                if err != CHIAKI_ERR_SUCCESS { buffer = [Double](repeating: -1, count: count) }
                continuation.resume(returning: buffer)
            }
        }
        return analyze(samples: samples, interface: interface)
    }
}
