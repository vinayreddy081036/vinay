import Foundation

/// Steps stream quality down when the connection struggles and back up when it is clean.
///
/// Remote Play can't change resolution mid-session, so a step applies from the next
/// connection. When loss is severe the coordinator reconnects straight away at the lower
/// step (a 2–3 s interruption instead of minutes of stutter). Steps are remembered per
/// network, so a busy hotel Wi-Fi doesn't lower quality at home.
struct AdaptiveQuality: Equatable, Sendable {
    enum Step: Int, CaseIterable, Sendable {
        case full = 0          // the user's own settings
        case reducedBitrate    // same resolution, 10 Mbps
        case p720              // 720p
        case p540              // 540p (last resort)

        var label: String {
            switch self {
            case .full: return "Full quality"
            case .reducedBitrate: return "Reduced bitrate"
            case .p720: return "720p"
            case .p540: return "540p"
            }
        }
    }

    enum Action: Equatable, Sendable {
        case none
        /// Lower quality from the next connection.
        case downgradeNextSession(Step)
        /// Connection is unplayable: reconnect now at this step.
        case downgradeNow(Step)
        /// Clean for a long time: next connection goes one step back up.
        case upgradeNextSession(Step)
    }

    // Thresholds
    static let badLossPercent = 5.0
    static let severeLossPercent = 12.0
    static let badRTT = 80.0
    static let badSecondsNeeded = 6
    static let cleanLossPercent = 1.0
    static let cleanRTT = 30.0
    static let cleanSecondsNeeded = 120

    private(set) var step: Step
    private var badSeconds = 0
    private var severeSeconds = 0
    private var cleanSeconds = 0
    private var actedThisSession = false

    init(step: Step = .full) { self.step = step }

    /// Feed one sample per second while streaming.
    mutating func record(packetLossPercent loss: Double, rttMilliseconds rtt: Double) -> Action {
        let severe = loss >= Self.severeLossPercent
        let bad = loss >= Self.badLossPercent || rtt >= Self.badRTT
        let clean = loss < Self.cleanLossPercent && (rtt <= 0 || rtt < Self.cleanRTT)

        severeSeconds = severe ? severeSeconds + 1 : 0
        badSeconds = bad ? badSeconds + 1 : 0
        cleanSeconds = clean ? cleanSeconds + 1 : 0

        if severeSeconds >= Self.badSecondsNeeded, let lower = Step(rawValue: step.rawValue + 1) {
            step = lower
            severeSeconds = 0; badSeconds = 0; cleanSeconds = 0
            actedThisSession = true
            return .downgradeNow(lower)
        }
        if badSeconds >= Self.badSecondsNeeded, !actedThisSession, let lower = Step(rawValue: step.rawValue + 1) {
            step = lower
            badSeconds = 0
            actedThisSession = true
            return .downgradeNextSession(lower)
        }
        if cleanSeconds >= Self.cleanSecondsNeeded, !actedThisSession, let higher = Step(rawValue: step.rawValue - 1) {
            step = higher
            cleanSeconds = 0
            actedThisSession = true
            return .upgradeNextSession(higher)
        }
        return .none
    }

    mutating func startNewSession() {
        badSeconds = 0; severeSeconds = 0; cleanSeconds = 0
        actedThisSession = false
    }

    /// Applies a step on top of the user's chosen resolution/bitrate (never raises them).
    static func apply(_ step: Step, resolution: StreamResolution, bitrate: UInt32?) -> (StreamResolution, UInt32?) {
        switch step {
        case .full:
            return (resolution, bitrate)
        case .reducedBitrate:
            return (resolution, min(bitrate ?? 10_000, 10_000))
        case .p720:
            return (StreamResolution(rawValue: min(resolution.rawValue, StreamResolution.p720.rawValue)) ?? .p720, nil)
        case .p540:
            return (StreamResolution(rawValue: min(resolution.rawValue, StreamResolution.p540.rawValue)) ?? .p540, nil)
        }
    }

    // MARK: Per-network memory

    private static func key(_ network: String) -> String { "vp.adaptive.\(network)" }

    static func storedStep(network: String, defaults: UserDefaults = .standard) -> Step {
        Step(rawValue: defaults.integer(forKey: key(network))) ?? .full
    }

    static func store(_ step: Step, network: String, defaults: UserDefaults = .standard) {
        defaults.set(step.rawValue, forKey: key(network))
    }
}
