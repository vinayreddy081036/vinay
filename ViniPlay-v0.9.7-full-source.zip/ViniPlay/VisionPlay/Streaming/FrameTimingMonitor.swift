import Foundation

/// Measures arrival cadence of video frames from the network (FPS, jitter, gaps) and
/// counts frames the core reported as lost.
struct FrameTimingMonitor: Sendable {
    private(set) var frames: UInt64 = 0
    private(set) var framesLost: UInt64 = 0
    private(set) var lateFrames: UInt64 = 0
    private(set) var averageIntervalMilliseconds: Double = 0
    private(set) var jitterMilliseconds: Double = 0
    private(set) var longestGapMilliseconds: Double = 0
    private var lastArrival: Double?
    let expectedIntervalMilliseconds: Double

    init(expectedFPS: Int = 60) {
        expectedIntervalMilliseconds = 1000.0 / Double(max(expectedFPS, 1))
    }

    /// Records a frame arriving at `timeMilliseconds` (monotonic clock).
    mutating func record(arrivalMilliseconds time: Double, framesLostBefore lost: Int32 = 0) {
        frames += 1
        if lost > 0 { framesLost += UInt64(lost) }
        if let last = lastArrival {
            let interval = max(0, time - last)
            if averageIntervalMilliseconds == 0 {
                averageIntervalMilliseconds = interval
            } else {
                averageIntervalMilliseconds = averageIntervalMilliseconds * 0.9 + interval * 0.1
            }
            let deviation = abs(interval - expectedIntervalMilliseconds)
            jitterMilliseconds = jitterMilliseconds * 0.9 + deviation * 0.1
            if interval > expectedIntervalMilliseconds * 1.5 { lateFrames += 1 }
            longestGapMilliseconds = max(longestGapMilliseconds, interval)
        }
        lastArrival = time
    }

    var measuredFPS: Double {
        averageIntervalMilliseconds > 0 ? 1000.0 / averageIntervalMilliseconds : 0
    }

    mutating func reset() {
        self = FrameTimingMonitor(expectedFPS: Int((1000.0 / expectedIntervalMilliseconds).rounded()))
    }
}

/// Everything the HUD / diagnostics screen shows, sampled once per second.
struct StreamStatistics: Sendable {
    var networkFPS: Double = 0
    var jitterMilliseconds: Double = 0
    var framesLost: UInt64 = 0
    var lateFrames: UInt64 = 0
    var rttMilliseconds: Double = 0
    var packetLossPercent: Double = 0
    var bitrateKbps: Int = 0
    var streamWidth: Int = 0
    var streamHeight: Int = 0
    var codec: String = "—"
    var decoder = VideoDecoder.Stats()
    var render = RenderStats()
    var audio = StreamAudioEngine.Stats()
    var reconnectAttempts = 0
    /// Video bitrate actually arriving (measured from received access units).
    var receivedKbps: Double = 0
    var quality = PictureQualityMeter.make(receivedKbps: 0, requestedKbps: 0, width: 0, height: 0, fps: 0)
    var lag = LagEstimate.make(rttMs: 0, fps: 60, decodeMs: 0, decodeToDisplayMs: 0, refreshHz: 0)
}
