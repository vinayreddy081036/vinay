import Foundation

/// "Press to picture" lag, built from the parts VisionPlay can measure plus two stated
/// assumptions. Remote Play gives no echo that ties a button press to a frame, so the
/// console's own reaction time can't be timed from here — it is estimated as one frame
/// (game update + encode), which matches published measurements for most 60 FPS games
/// only roughly. Use it to compare settings, not as an absolute number.
struct LagEstimate: Equatable, Sendable {
    /// DualSense Bluetooth report interval + send (assumed).
    var controllerMs: Double
    /// Network round trip (measured by the session).
    var networkMs: Double
    /// Console game update + video encode (assumed: one frame).
    var consoleMs: Double
    /// Hardware decode (measured).
    var decodeMs: Double
    /// Upscale + present + half a display refresh on average (measured + derived).
    var displayMs: Double

    var totalMs: Double { controllerMs + networkMs + consoleMs + decodeMs + displayMs }

    static func make(rttMs: Double, fps: Int, decodeMs: Double, decodeToDisplayMs: Double, refreshHz: Double) -> LagEstimate {
        let refresh = refreshHz > 0 ? refreshHz : 90
        return LagEstimate(controllerMs: 4,
                           networkMs: max(rttMs, 0),
                           consoleMs: 1000 / Double(max(fps, 1)),
                           decodeMs: max(decodeMs, 0),
                           displayMs: max(decodeToDisplayMs, 0) + 500 / refresh)
    }

    var summary: String { String(format: "Lag ≈ %.0f ms", totalMs) }
    var breakdown: String {
        String(format: "pad %.0f · net %.0f · PS5 ~%.0f · decode %.0f · display %.0f ms",
               controllerMs, networkMs, consoleMs, decodeMs, displayMs)
    }
}
