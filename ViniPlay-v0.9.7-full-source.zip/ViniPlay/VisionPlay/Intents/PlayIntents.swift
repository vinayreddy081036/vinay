import AppIntents
import Foundation

/// A registered console as a Shortcuts parameter ("Play PS5 · Vinay").
struct ConsoleEntity: AppEntity {
    static var typeDisplayRepresentation = TypeDisplayRepresentation(name: "PlayStation")
    static var defaultQuery = ConsoleQuery()

    var id: String
    var name: String

    var displayRepresentation: DisplayRepresentation { DisplayRepresentation(title: "\(name)") }
}

struct ConsoleQuery: EntityQuery {
    func entities(for identifiers: [String]) async throws -> [ConsoleEntity] {
        try await suggestedEntities().filter { identifiers.contains($0.id) }
    }

    func suggestedEntities() async throws -> [ConsoleEntity] {
        ConsoleStore.loadSaved().map { ConsoleEntity(id: $0.id, name: $0.displayName) }
    }
}

/// Request handed from an intent to the running app (intents run in the app process because
/// `openAppWhenRun` is true; the home window picks this up and opens the right scenes).
struct LaunchRequest: Equatable {
    var consoleID: String?
    var openTheater: Bool
}

@MainActor
enum LaunchCoordinator {
    static var pending: LaunchRequest? {
        didSet { if pending != nil { NotificationCenter.default.post(name: .visionPlayLaunchRequest, object: nil) } }
    }
}

extension Notification.Name {
    static let visionPlayLaunchRequest = Notification.Name("VisionPlay.launchRequest")
}

/// "Hey Siri, play PS5 in VisionPlay": wakes the console if needed, connects (home network
/// or Internet), and optionally opens Theater.
struct PlayPS5Intent: AppIntent {
    static var title: LocalizedStringResource = "Play PlayStation"
    static var description = IntentDescription("Wakes your PlayStation and starts Remote Play in VisionPlay.")
    static var openAppWhenRun = true

    @Parameter(title: "Console")
    var console: ConsoleEntity?

    static var parameterSummary: some ParameterSummary {
        Summary("Play \(\.$console)")
    }

    @MainActor
    func perform() async throws -> some IntentResult {
        LaunchCoordinator.pending = LaunchRequest(consoleID: console?.id, openTheater: false)
        return .result()
    }
}

struct DisconnectIntent: AppIntent {
    static var title: LocalizedStringResource = "Stop Remote Play"
    static var openAppWhenRun = true

    @MainActor
    func perform() async throws -> some IntentResult {
        NotificationCenter.default.post(name: .visionPlayStopRequest, object: nil)
        return .result()
    }
}

extension Notification.Name {
    static let visionPlayStopRequest = Notification.Name("VisionPlay.stopRequest")
}

struct VisionPlayShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: PlayPS5Intent(),
                    phrases: ["Play PS5 in \(.applicationName)",
                              "Start \(.applicationName)",
                              "Play PlayStation with \(.applicationName)"],
                    shortTitle: "Play PS5", systemImageName: "gamecontroller")
        AppShortcut(intent: DisconnectIntent(),
                    phrases: ["Stop \(.applicationName)"],
                    shortTitle: "Stop Remote Play", systemImageName: "stop.circle")
    }
}
