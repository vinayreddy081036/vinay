import Foundation

enum UpscaleMode: String, CaseIterable, Identifiable, Codable, Sendable {
    case performance = "Performance"
    case balanced = "Balanced"
    case quality = "Quality"
    var id: String { rawValue }

    var summary: String {
        switch self {
        case .performance:
            return "Single pass: colour conversion and bilinear scaling straight to the output. Lowest latency."
        case .balanced:
            return "Bicubic (Catmull-Rom) GPU scaling with light sharpening. Steady frame pacing."
        case .quality:
            return "MetalFX Spatial Scaling to the output target (Lanczos-3 fallback) plus contrast-adaptive sharpening."
        }
    }
}

enum OutputTarget: String, CaseIterable, Identifiable, Codable, Sendable {
    case source = "Source"
    case qhd1440 = "2560 × 1440"
    case uhd4K = "3840 × 2160"
    var id: String { rawValue }

    /// Output size for a 16:9 target, or nil for "same as the decoded source".
    var size: (width: Int, height: Int)? {
        switch self {
        case .source: return nil
        case .qhd1440: return (2560, 1440)
        case .uhd4K: return (3840, 2160)
        }
    }
}

/// The algorithm the renderer actually ended up using (reported in Diagnostics).
enum ScalingTechnique: String, Sendable {
    case none = "No scaling (1:1)"
    case bilinear = "Bilinear (single pass)"
    case bicubic = "Bicubic Catmull-Rom (compute)"
    case metalFXSpatial = "MetalFX Spatial Scaler"
    case lanczosFallback = "Lanczos-3 (compute fallback, MetalFX unavailable)"
}

/// Value-type snapshot of the upscaling settings handed to the render thread.
struct UpscalerConfiguration: Equatable, Sendable {
    var neuralEnabled = true
    /// 120 fps frame generation (an in-between picture for every pair of 60 fps frames).
    var frameGeneration = false
    var enabled: Bool
    var mode: UpscaleMode
    var outputTarget: OutputTarget
    /// User-facing sharpening amount in 0…1 (35 % = 0.35).
    var sharpening: Float
    /// HDR only: peak output brightness relative to SDR reference white (EDR headroom).
    var hdrHeadroom: Float = 2.0
    /// Compression clean-up before upscaling, 0 (off) … 1. Quality/Balanced only.
    var deblockStrength: Float = 0
    var picture = PictureAdjustments()
    /// Extra sharpening for menus, maps and subtitles, 0…1.
    var textClarity: Float = 0
    /// Edge-aware sharpening (less on flat areas).
    var smartSharpening = true
    var blackBars: BlackBarsMode = .darken

    static let `default` = UpscalerConfiguration(enabled: true, mode: .quality, outputTarget: .uhd4K, sharpening: 0.35)

    /// Output size for a given decoded source size, preserving the source aspect ratio
    /// inside the target (the remainder is letterboxed by the renderer).
    func outputSize(sourceWidth: Int, sourceHeight: Int, maxDimension: Int = 4096) -> (width: Int, height: Int) {
        guard enabled, let target = outputTarget.size else { return (sourceWidth, sourceHeight) }
        let w = min(target.width, maxDimension)
        let h = min(target.height, maxDimension)
        return (max(w, 1), max(h, 1))
    }

    /// Effective sharpening strength after the per-mode policy:
    /// Performance never sharpens; Balanced uses half of the user's amount.
    var effectiveSharpening: Float {
        guard enabled else { return 0 }
        let s = min(max(sharpening, 0), 1)
        switch mode {
        case .performance: return 0
        case .balanced: return s * 0.5
        case .quality: return s
        }
    }

    /// Maps the user-facing 0…1 amount to the contrast-adaptive sharpening (CAS)
    /// shader parameter.
    ///
    /// CAS computes a negative lobe weight `w = -1 / mix(maxPeak, minPeak, amount)`.
    /// AMD's reference uses `peak = -1 / mix(8, 5, sharpness)`, i.e. denominators from
    /// 8 (gentle) to 5 (strong). VisionPlay maps 0 % → 8.0 and 100 % → 4.5 so the
    /// default 35 % lands at ≈ 6.78: visibly crisper than unsharpened 1080p scaled to
    /// 4K, without halos on UI text or amplifying macro-blocking from the H.264/HEVC
    /// stream. The CAS weight is additionally limited by local contrast, which keeps
    /// already-sharp edges from ringing.
    static func casPeakDenominator(forAmount amount: Float) -> Float {
        let a = min(max(amount, 0), 1)
        return 8.0 + (4.5 - 8.0) * a
    }
}
