import Foundation
import simd

/// Colour/brightness adjustments applied in the final compose pass (all GPU, one pass).
struct PictureAdjustments: Codable, Equatable, Sendable {
    /// −0.2 … 0.2 (added to the display value)
    var brightness: Double = 0
    /// 0.7 … 1.4
    var contrast: Double = 1
    /// 0 … 2 (1 = unchanged)
    var saturation: Double = 1
    /// −1 (cool / blue) … 1 (warm / amber)
    var temperature: Double = 0
    /// 0 … 1: brightens shadows, leaves mid-tones and highlights alone.
    var shadowLift: Double = 0

    static let brightnessRange = -0.2...0.2
    static let contrastRange = 0.7...1.4
    static let saturationRange = 0.0...2.0
    static let temperatureRange = -1.0...1.0
    static let shadowLiftRange = 0.0...1.0

    var isNeutral: Bool { self == PictureAdjustments() }

    func clamped() -> PictureAdjustments {
        func c(_ v: Double, _ r: ClosedRange<Double>) -> Double { min(max(v, r.lowerBound), r.upperBound) }
        return PictureAdjustments(brightness: c(brightness, Self.brightnessRange),
                                  contrast: c(contrast, Self.contrastRange),
                                  saturation: c(saturation, Self.saturationRange),
                                  temperature: c(temperature, Self.temperatureRange),
                                  shadowLift: c(shadowLift, Self.shadowLiftRange))
    }

    /// CPU reference of the shader's adjustment on a display-referred (gamma) value, for tests.
    func apply(_ rgb: SIMD3<Float>) -> SIMD3<Float> {
        var c = rgb
        let luma = (c * SIMD3<Float>(0.2126, 0.7152, 0.0722)).sum()
        if shadowLift > 0, luma > 0 {
            let gamma = 1 / (1 + 0.7 * Float(shadowLift))
            let lifted = pow(luma, gamma)
            let t = Self.smoothstep(0.25, 0.75, luma)
            let target = lifted + (luma - lifted) * t
            c *= target / luma
        }
        c += Float(brightness)
        c = (c - 0.5) * Float(contrast) + 0.5
        let l2 = (c * SIMD3<Float>(0.2126, 0.7152, 0.0722)).sum()
        c = SIMD3(repeating: l2) + (c - SIMD3(repeating: l2)) * Float(saturation)
        let warm = Float(temperature) * 0.08
        c *= SIMD3<Float>(1 + warm, 1, 1 - warm)
        return simd_clamp(c, SIMD3(repeating: 0), SIMD3(repeating: 1))
    }

    static func smoothstep(_ a: Float, _ b: Float, _ x: Float) -> Float {
        let t = min(max((x - a) / (b - a), 0), 1)
        return t * t * (3 - 2 * t)
    }
}

/// One-tap presets. Changing any slider switches to Custom.
enum PictureMode: String, CaseIterable, Identifiable, Codable, Sendable {
    case standard = "Standard"
    case vivid = "Vivid"
    case cinema = "Cinema"
    case game = "Game"
    case darkRoom = "Dark Room"
    case custom = "Custom"

    var id: String { rawValue }

    /// nil for Custom (keeps whatever the sliders say).
    var adjustments: PictureAdjustments? {
        switch self {
        case .standard: return PictureAdjustments()
        case .vivid: return PictureAdjustments(brightness: 0.02, contrast: 1.1, saturation: 1.25, temperature: 0.05, shadowLift: 0)
        case .cinema: return PictureAdjustments(brightness: -0.02, contrast: 1.04, saturation: 0.95, temperature: 0.3, shadowLift: 0.05)
        case .game: return PictureAdjustments(brightness: 0.01, contrast: 1.05, saturation: 1.1, temperature: 0, shadowLift: 0.3)
        case .darkRoom: return PictureAdjustments(brightness: -0.05, contrast: 1.0, saturation: 1.0, temperature: 0.2, shadowLift: 0.15)
        case .custom: return nil
        }
    }

    var detail: String {
        switch self {
        case .standard: return "Accurate — what the PS5 sends"
        case .vivid: return "Punchier colour and contrast"
        case .cinema: return "Warmer, film-like"
        case .game: return "Clearer shadows, a little extra colour"
        case .darkRoom: return "Dimmer and warmer for long sessions"
        case .custom: return "Your own slider settings"
        }
    }
}

/// Letterboxed cutscenes: leave the bars, force them pure black, or zoom to fill.
enum BlackBarsMode: String, CaseIterable, Identifiable, Codable, Sendable {
    case off = "Leave"
    case darken = "Pure Black"
    case crop = "Zoom to Fill"
    var id: String { rawValue }
    var shaderValue: UInt32 {
        switch self { case .off: return 0; case .darken: return 1; case .crop: return 2 }
    }
}

/// How hard the PS5's encoder is squeezing the picture, from received bits per pixel.
struct PictureQualityMeter: Equatable, Sendable {
    enum Grade: String, Sendable {
        case excellent = "Excellent"
        case good = "Good"
        case fair = "Fair"
        case heavy = "Heavily compressed"
        case unknown = "—"
    }

    var receivedKbps: Double
    var requestedKbps: Double
    var bitsPerPixel: Double
    var grade: Grade

    static func make(receivedKbps: Double, requestedKbps: Double, width: Int, height: Int, fps: Double) -> PictureQualityMeter {
        guard receivedKbps > 0, width > 0, height > 0, fps > 1 else {
            return PictureQualityMeter(receivedKbps: receivedKbps, requestedKbps: requestedKbps, bitsPerPixel: 0, grade: .unknown)
        }
        let bpp = receivedKbps * 1000 / (Double(width * height) * fps)
        let grade: Grade
        switch bpp {
        case 0.09...: grade = .excellent
        case 0.055..<0.09: grade = .good
        case 0.03..<0.055: grade = .fair
        default: grade = .heavy
        }
        return PictureQualityMeter(receivedKbps: receivedKbps, requestedKbps: requestedKbps, bitsPerPixel: bpp, grade: grade)
    }

    /// Plain-language cause, so blur can be blamed on the right thing.
    var advice: String {
        switch grade {
        case .unknown: return ""
        case .excellent, .good:
            return "The stream is detailed; any softness is from upscaling — try Quality mode or more sharpening."
        case .fair, .heavy:
            if requestedKbps > 0 && receivedKbps < requestedKbps * 0.7 {
                return "The PS5 is sending less than you asked for — usually Wi-Fi. Wire the PS5, use 5/6 GHz for the headset."
            }
            return "Busy scenes are being compressed hard. Raise the bitrate in Settings if your network allows."
        }
    }

    var summary: String {
        guard grade != .unknown else { return "Picture: —" }
        return String(format: "Picture: %@ (%.3f bpp, %.1f Mbps)", grade.rawValue, bitsPerPixel, receivedKbps / 1000)
    }
}
