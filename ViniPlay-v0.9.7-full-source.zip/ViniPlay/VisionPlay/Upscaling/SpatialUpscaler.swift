import Foundation
import Metal
import CoreVideo
#if canImport(MetalFX)
import MetalFX
#endif

/// Wraps MetalFX Spatial Scaling with a compute fallback (separable Lanczos-3), and the
/// Catmull-Rom scaler used by Balanced mode.
final class SpatialUpscaler {
    private let device: MTLDevice
    private let resamplePipeline: MTLComputePipelineState

    #if canImport(MetalFX)
    private var scaler: MTLFXSpatialScaler?
    #endif
    private var scalerKey: String = ""
    private var intermediate: MTLTexture?

    /// True when the device supports MetalFX Spatial Scaling (checked once).
    let metalFXAvailable: Bool

    init(device: MTLDevice, library: MTLLibrary) throws {
        self.device = device
        guard let function = library.makeFunction(name: "resample_separable") else {
            throw RendererError.missingFunction("resample_separable")
        }
        resamplePipeline = try device.makeComputePipelineState(function: function)
        #if canImport(MetalFX)
        metalFXAvailable = MTLFXSpatialScalerDescriptor.supportsDevice(device)
        #else
        metalFXAvailable = false
        #endif
    }

    /// Texture usage the MetalFX scaler needs on its output, if MetalFX is in use.
    var requiredOutputUsage: MTLTextureUsage {
        #if canImport(MetalFX)
        if let scaler { return scaler.outputTextureUsage }
        #endif
        return [.shaderRead, .shaderWrite]
    }

    /// Encodes an upscale from `input` (RGBA16F, source resolution) into `output`.
    /// Returns the technique actually used.
    func encode(commandBuffer: MTLCommandBuffer, input: MTLTexture, output: MTLTexture,
                mode: UpscaleMode) -> ScalingTechnique {
        if input.width == output.width && input.height == output.height {
            if let blit = commandBuffer.makeBlitCommandEncoder() {
                blit.copy(from: input, to: output)
                blit.endEncoding()
            }
            return .none
        }
        switch mode {
        case .performance:
            // Performance mode does not use this path (single-pass compose), but stay safe.
            encodeSeparable(commandBuffer: commandBuffer, input: input, output: output, filter: 0, support: 2)
            return .bicubic
        case .balanced:
            encodeSeparable(commandBuffer: commandBuffer, input: input, output: output, filter: 0, support: 2)
            return .bicubic
        case .quality:
            #if canImport(MetalFX)
            if metalFXAvailable, let scaler = prepareScaler(input: input, output: output) {
                scaler.colorTexture = input
                scaler.outputTexture = output
                scaler.inputContentWidth = input.width
                scaler.inputContentHeight = input.height
                scaler.encode(commandBuffer: commandBuffer)
                return .metalFXSpatial
            }
            #endif
            encodeSeparable(commandBuffer: commandBuffer, input: input, output: output, filter: 1, support: 3)
            return .lanczosFallback
        }
    }

    /// Whether `encode` will use MetalFX for this input/output combination (so the caller
    /// can allocate the output texture with MetalFX's required usage/storage).
    func willUseMetalFX(mode: UpscaleMode, inputSize: (Int, Int), outputSize: (Int, Int)) -> Bool {
        mode == .quality && metalFXAvailable && inputSize != outputSize
    }

    #if canImport(MetalFX)
    private func prepareScaler(input: MTLTexture, output: MTLTexture) -> MTLFXSpatialScaler? {
        let key = "\(input.width)x\(input.height)->\(output.width)x\(output.height):\(input.pixelFormat.rawValue)/\(output.pixelFormat.rawValue)"
        if key == scalerKey, let scaler { return scaler }
        let descriptor = MTLFXSpatialScalerDescriptor()
        descriptor.inputWidth = input.width
        descriptor.inputHeight = input.height
        descriptor.outputWidth = output.width
        descriptor.outputHeight = output.height
        descriptor.colorTextureFormat = input.pixelFormat
        descriptor.outputTextureFormat = output.pixelFormat
        // Input is gamma-encoded video (not linear light), so use perceptual processing.
        descriptor.colorProcessingMode = .perceptual
        guard let made = descriptor.makeSpatialScaler(device: device) else {
            vpLog(.warning, "upscale", "MetalFX scaler creation failed for \(key); using Lanczos fallback")
            scaler = nil
            scalerKey = ""
            return nil
        }
        scaler = made
        scalerKey = key
        vpLog(.info, "upscale", "MetalFX Spatial Scaler ready (\(key))")
        return made
    }
    #endif

    private func encodeSeparable(commandBuffer: MTLCommandBuffer, input: MTLTexture, output: MTLTexture,
                                 filter: UInt32, support: Float) {
        // Horizontal pass into an intermediate (outputWidth × inputHeight), then vertical.
        if intermediate == nil || intermediate!.width != output.width || intermediate!.height != input.height {
            let descriptor = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float,
                                                                      width: output.width, height: input.height,
                                                                      mipmapped: false)
            descriptor.usage = [.shaderRead, .shaderWrite]
            descriptor.storageMode = .private
            intermediate = device.makeTexture(descriptor: descriptor)
            intermediate?.label = "VisionPlay.resample.intermediate"
        }
        guard let intermediate, let encoder = commandBuffer.makeComputeCommandEncoder() else { return }
        encoder.label = filter == 0 ? "Catmull-Rom" : "Lanczos-3"
        encoder.setComputePipelineState(resamplePipeline)

        var horizontal = ScaleUniforms(sourceSize: SIMD2(Float(input.width), Float(input.height)),
                                       destSize: SIMD2(Float(output.width), Float(input.height)),
                                       support: support, filter: filter, horizontal: 1)
        encoder.setTexture(input, index: 0)
        encoder.setTexture(intermediate, index: 1)
        encoder.setBytes(&horizontal, length: MemoryLayout<ScaleUniforms>.stride, index: 0)
        dispatch(encoder, width: intermediate.width, height: intermediate.height)

        var vertical = ScaleUniforms(sourceSize: SIMD2(Float(output.width), Float(input.height)),
                                     destSize: SIMD2(Float(output.width), Float(output.height)),
                                     support: support, filter: filter, horizontal: 0)
        encoder.setTexture(intermediate, index: 0)
        encoder.setTexture(output, index: 1)
        encoder.setBytes(&vertical, length: MemoryLayout<ScaleUniforms>.stride, index: 0)
        dispatch(encoder, width: output.width, height: output.height)
        encoder.endEncoding()
    }

    private func dispatch(_ encoder: MTLComputeCommandEncoder, width: Int, height: Int) {
        let w = resamplePipeline.threadExecutionWidth
        let h = max(1, resamplePipeline.maxTotalThreadsPerThreadgroup / w)
        let threadsPerGroup = MTLSize(width: w, height: h, depth: 1)
        let groups = MTLSize(width: (width + w - 1) / w, height: (height + h - 1) / h, depth: 1)
        encoder.dispatchThreadgroups(groups, threadsPerThreadgroup: threadsPerGroup)
    }

    func releaseResources() {
        intermediate = nil
        #if canImport(MetalFX)
        scaler = nil
        #endif
        scalerKey = ""
    }
}

enum RendererError: Error, LocalizedError {
    case noDevice
    case missingFunction(String)
    case textureCache(CVReturn)

    var errorDescription: String? {
        switch self {
        case .noDevice: return "Metal is not available on this device."
        case .missingFunction(let name): return "Shader function \(name) is missing from the Metal library."
        case .textureCache(let code): return "CVMetalTextureCache error \(code)."
        }
    }
}

// VideoToolbox ML is unavailable in the simulator; spatial scaling remains the fallback.
import QuartzCore
import VideoToolbox
import CoreMedia

final class LiveNeuralUpscaler: @unchecked Sendable {
    private let queue = DispatchQueue(label: "ViniPlay.neural", qos: .userInteractive)
    private let lock = NSLock()
    private var busy = false
    private var latest: (CVPixelBuffer, (CVPixelBuffer, String) -> Void)?
    #if !targetEnvironment(simulator)
    private var processor: AnyObject?
    private var pool: CVPixelBufferPool?
    private var attemptedKey = ""
    private var disabled = false
    private var processedFrames = 0
    private var slowFrames = 0
    #endif

    static let supports1080p2x: Bool = {
        #if !targetEnvironment(simulator)
        if #available(visionOS 26.0, *), VTLowLatencySuperResolutionScalerConfiguration.isSupported {
            return VTLowLatencySuperResolutionScalerConfiguration.__supportedScaleFactors(forFrameWidth: 1920, frameHeight: 1080).contains { abs($0.floatValue - 2) < 0.001 }
        }
        #endif
        return false
    }()

    static var capabilitySummary: String {
        #if !targetEnvironment(simulator)
        if #available(visionOS 26.0, *) {
            let supported = VTLowLatencySuperResolutionScalerConfiguration.isSupported
            let factors = supported ? VTLowLatencySuperResolutionScalerConfiguration.__supportedScaleFactors(forFrameWidth: 1920, frameHeight: 1080).map { $0.floatValue } : []
            return "Apple ML hardware supported: \(supported); 1080p scale factors: \(factors)"
        }
        #endif
        return "Apple ML unavailable on this OS or simulator"
    }

    func submit(_ input: CVPixelBuffer, completion: @escaping (CVPixelBuffer, String) -> Void) {
        lock.lock()
        if busy { latest = (input, completion); lock.unlock(); return }
        busy = true
        lock.unlock()
        queue.async { self.process(input, completion: completion) }
    }

    private func finish(_ input: CVPixelBuffer, label: String, completion: @escaping (CVPixelBuffer, String) -> Void) {
        completion(input, label)
        lock.lock()
        let next = latest
        latest = nil
        if next == nil { busy = false }
        lock.unlock()
        if let next { queue.async { self.process(next.0, completion: next.1) } }
    }

    private func process(_ input: CVPixelBuffer, completion: @escaping (CVPixelBuffer, String) -> Void) {
        #if !targetEnvironment(simulator)
        if #available(visionOS 26.0, *) {
            processML(input, completion: completion)
            return
        }
        #endif
        finish(input, label: "ML unavailable · spatial fallback", completion: completion)
    }

    #if !targetEnvironment(simulator)
    @available(visionOS 26.0, *)
    private func processML(_ input: CVPixelBuffer, completion: @escaping (CVPixelBuffer, String) -> Void) {
        let width = CVPixelBufferGetWidth(input), height = CVPixelBufferGetHeight(input)
        guard width == 1920, height == 1080, !disabled,
              VTLowLatencySuperResolutionScalerConfiguration.isSupported else {
            finish(input, label: "ML unsupported · spatial fallback", completion: completion); return
        }
        let key = "\(width)x\(height):\(CVPixelBufferGetPixelFormatType(input))"
        if attemptedKey != key {
            attemptedKey = key
            (processor as? VTFrameProcessor)?.endSession()
            processor = nil
            pool = nil
            let factors = VTLowLatencySuperResolutionScalerConfiguration.__supportedScaleFactors(forFrameWidth: width, frameHeight: height)
            guard factors.contains(where: { abs($0.floatValue - 2) < 0.001 }) else {
                finish(input, label: "ML 2× unsupported · spatial fallback", completion: completion); return
            }
            let config = VTLowLatencySuperResolutionScalerConfiguration(frameWidth: width, frameHeight: height, scaleFactor: 2)
            guard config.__frameSupportedPixelFormats.contains(where: { $0.uint32Value == CVPixelBufferGetPixelFormatType(input) }) else {
                finish(input, label: "ML pixel format unsupported · spatial fallback", completion: completion); return
            }
            var attributes = config.destinationPixelBufferAttributes
            attributes[kCVPixelBufferWidthKey as String] = width * 2
            attributes[kCVPixelBufferHeightKey as String] = height * 2
            attributes[kCVPixelBufferIOSurfacePropertiesKey as String] = [:] as [String: Any]
            attributes[kCVPixelBufferMetalCompatibilityKey as String] = true
            let engine = VTFrameProcessor()
            do {
                try engine.startSession(configuration: config)
                guard CVPixelBufferPoolCreate(nil, nil, attributes as CFDictionary, &pool) == kCVReturnSuccess else {
                    engine.endSession(); throw NSError(domain: "ViniPlay.ML", code: 1)
                }
                processor = engine
                vpLog(.info, "upscale", "Apple low-latency ML 1080p → 4K ready")
            } catch {
                vpLog(.warning, "upscale", "ML unavailable: \(error.localizedDescription); spatial fallback")
            }
        }
        guard let engine = processor as? VTFrameProcessor, let pool else {
            finish(input, label: "ML unavailable · spatial fallback", completion: completion); return
        }
        var output: CVPixelBuffer?
        guard CVPixelBufferPoolCreatePixelBuffer(nil, pool, &output) == kCVReturnSuccess, let output,
              let source = VTFrameProcessorFrame(buffer: input, presentationTimeStamp: .zero),
              let destination = VTFrameProcessorFrame(buffer: output, presentationTimeStamp: .zero) else {
            finish(input, label: "ML buffer unavailable · spatial fallback", completion: completion); return
        }
        CVBufferPropagateAttachments(input, output)
        let parameters = VTLowLatencySuperResolutionScalerParameters(sourceFrame: source, destinationFrame: destination)
        let start = CACurrentMediaTime()
        engine.process(parameters: parameters) { _, error in
            self.queue.async {
                let elapsed = (CACurrentMediaTime() - start) * 1000
                if let error {
                    self.disabled = true
                    vpLog(.warning, "upscale", "ML processing failed: \(error.localizedDescription)")
                    self.finish(input, label: "ML failed · spatial fallback", completion: completion)
                } else if CVPixelBufferGetPlaneCount(output) != 2 || CVPixelBufferGetWidth(output) != 3840 || CVPixelBufferGetHeight(output) != 2160 {
                    self.disabled = true
                    self.finish(input, label: "ML output incompatible · spatial 4K fallback", completion: completion)
                } else {
                    // Avoid accumulating delay if the device cannot sustain live gameplay.
                    self.processedFrames += 1
                    if self.processedFrames > 10 {
                        self.slowFrames = elapsed > 20 ? self.slowFrames + 1 : 0
                        if self.slowFrames >= 6 { self.disabled = true }
                    }
                    self.finish(output, label: String(format: "Apple ML 2× · %.1f ms%@", elapsed, self.disabled ? " · spatial fallback next frame" : ""), completion: completion)
                }
            }
        }
    }
    #endif
}
