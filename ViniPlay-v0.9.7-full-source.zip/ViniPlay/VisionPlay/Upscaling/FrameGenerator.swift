import Foundation
import CoreVideo
import CoreMedia
import QuartzCore
import VideoToolbox

/// 120 fps frame generation: Apple's low-latency frame interpolation (VideoToolbox, visionOS 26)
/// makes one in-between picture for every pair of 60 fps frames from the PS5.
///
/// For each new frame it returns the in-between frame (halfway from the previous frame) and the
/// new frame; the renderer shows the in-between first and the new frame half a frame later.
/// That costs about half a frame (~8 ms) of extra delay, so it's a setting, off by default.
/// If the device can't keep up (processing slower than 8 ms, several times) or the processor
/// fails, it switches itself off for the session and frames pass straight through.
final class FrameGenerator: @unchecked Sendable {
    private let queue = DispatchQueue(label: "ViniPlay.framegen", qos: .userInteractive)
    private let lock = NSLock()
    private var busy = false
    private var latest: (CVPixelBuffer, (CVPixelBuffer?, CVPixelBuffer, String) -> Void)?

    // Queue-only state.
    #if !targetEnvironment(simulator)
    private var processor: AnyObject?
    private var pool: CVPixelBufferPool?
    private var attemptedKey = ""
    #endif
    private var previous: CVPixelBuffer?
    private var frameIndex: Int64 = 0
    private var disabled = false
    private var disabledReason = "Frame generation off"
    private var slowFrames = 0
    /// Bumped by reset(): a result from before the reset is passed through but not trusted.
    private var generation = 0

    /// True when this device and OS offer low-latency frame interpolation.
    static let isAvailable: Bool = {
        #if !targetEnvironment(simulator)
        if #available(visionOS 26.0, *) { return VTLowLatencyFrameInterpolationConfiguration.isSupported }
        #endif
        return false
    }()

    /// Hands a decoded frame in. `completion(inBetween, current, status)` — `inBetween` is nil when
    /// none could be made (first frame, unsupported, too slow). Drops to the newest frame if busy.
    func submit(_ input: CVPixelBuffer, completion: @escaping (CVPixelBuffer?, CVPixelBuffer, String) -> Void) {
        lock.lock()
        if busy { latest = (input, completion); lock.unlock(); return }
        busy = true
        lock.unlock()
        queue.async { self.process(input, completion: completion) }
    }

    /// Starts again (new stream or stream size): forget the previous frame and any failure.
    func reset() {
        queue.async {
            self.generation += 1
            self.previous = nil
            self.disabled = false
            self.slowFrames = 0
            #if !targetEnvironment(simulator)
            if #available(visionOS 26.0, *) { (self.processor as? VTFrameProcessor)?.endSession() }
            self.processor = nil
            self.pool = nil
            self.attemptedKey = ""
            #endif
        }
    }

    private func finish(_ mid: CVPixelBuffer?, _ current: CVPixelBuffer, _ status: String,
                        stale: Bool = false,
                        _ completion: @escaping (CVPixelBuffer?, CVPixelBuffer, String) -> Void) {
        // A frame from before a reset belongs to the old stream: show it, don't keep it.
        if !stale { previous = current }
        completion(stale ? nil : mid, current, status)
        lock.lock()
        let next = latest
        latest = nil
        if next == nil { busy = false }
        lock.unlock()
        if let next { queue.async { self.process(next.0, completion: next.1) } }
    }

    private func process(_ input: CVPixelBuffer, completion: @escaping (CVPixelBuffer?, CVPixelBuffer, String) -> Void) {
        frameIndex += 1
        #if !targetEnvironment(simulator)
        if #available(visionOS 26.0, *), !disabled {
            interpolate(input, completion: completion)
            return
        }
        #endif
        finish(nil, input, disabled ? disabledReason : "Frame generation unavailable", completion)
    }

    #if !targetEnvironment(simulator)
    @available(visionOS 26.0, *)
    private func interpolate(_ input: CVPixelBuffer, completion: @escaping (CVPixelBuffer?, CVPixelBuffer, String) -> Void) {
        let width = CVPixelBufferGetWidth(input), height = CVPixelBufferGetHeight(input)
        let key = "\(width)x\(height):\(CVPixelBufferGetPixelFormatType(input))"
        if attemptedKey != key {
            // New size or format: start a fresh session; the old previous frame no longer matches.
            attemptedKey = key
            (processor as? VTFrameProcessor)?.endSession()
            processor = nil
            pool = nil
            previous = nil
            // Typed as Optional so this compiles whether the initializer is failable or not.
            let made: VTLowLatencyFrameInterpolationConfiguration? = VTLowLatencyFrameInterpolationConfiguration.isSupported
                ? VTLowLatencyFrameInterpolationConfiguration(frameWidth: width, frameHeight: height, numberOfInterpolatedFrames: 1)
                : nil
            guard let config = made else {
                disabled = true
                disabledReason = "Frame generation not supported here"
                finish(nil, input, "Frame generation not supported here", completion); return
            }
            var attributes = config.destinationPixelBufferAttributes
            attributes[kCVPixelBufferWidthKey as String] = width
            attributes[kCVPixelBufferHeightKey as String] = height
            attributes[kCVPixelBufferIOSurfacePropertiesKey as String] = [:] as [String: Any]
            attributes[kCVPixelBufferMetalCompatibilityKey as String] = true
            let engine = VTFrameProcessor()
            do {
                try engine.startSession(configuration: config)
                guard CVPixelBufferPoolCreate(nil, nil, attributes as CFDictionary, &pool) == kCVReturnSuccess else {
                    engine.endSession(); throw NSError(domain: "ViniPlay.FrameGen", code: 1)
                }
                processor = engine
                vpLog(.info, "framegen", "Low-latency frame interpolation ready (\(width)×\(height), 60 → 120 fps)")
            } catch {
                disabled = true
                disabledReason = "Frame generation unavailable"
                vpLog(.warning, "framegen", "Frame generation unavailable: \(error.localizedDescription)")
                finish(nil, input, "Frame generation unavailable", completion); return
            }
        }
        // The first frame has nothing to interpolate from.
        guard let previous, let engine = processor as? VTFrameProcessor, let pool else {
            finish(nil, input, "Frame generation starting", completion); return
        }
        // Timestamps on a 60 fps clock: previous at n-1, current at n.
        let currentPTS = CMTime(value: frameIndex, timescale: 60)
        let previousPTS = CMTime(value: frameIndex - 1, timescale: 60)
        var output: CVPixelBuffer?
        guard CVPixelBufferPoolCreatePixelBuffer(nil, pool, &output) == kCVReturnSuccess, let output,
              let source = VTFrameProcessorFrame(buffer: input, presentationTimeStamp: currentPTS),
              let before = VTFrameProcessorFrame(buffer: previous, presentationTimeStamp: previousPTS),
              let middle = VTFrameProcessorFrame(buffer: output, presentationTimeStamp: CMTime(value: frameIndex * 2 - 1, timescale: 120)),
              let parameters = VTLowLatencyFrameInterpolationParameters(sourceFrame: source, previousFrame: before,
                                                                         interpolationPhase: [0.5], destinationFrames: [middle]) else {
            finish(nil, input, "Frame generation skipped a frame", completion); return
        }
        CVBufferPropagateAttachments(input, output)
        let start = CACurrentMediaTime()
        let started = generation
        engine.process(parameters: parameters) { _, error in
            self.queue.async {
                let elapsed = (CACurrentMediaTime() - start) * 1000
                // Reset while this frame was processing (new stream): pass it through only.
                if started != self.generation {
                    self.finish(nil, input, "Frame generation restarting", stale: true, completion)
                    return
                }
                if let error {
                    self.disabled = true
                    self.disabledReason = "Frame generation failed · off for this game"
                    vpLog(.warning, "framegen", "Frame generation failed: \(error.localizedDescription); off for this session")
                    self.finish(nil, input, "Frame generation failed · off", completion)
                    return
                }
                // More than half a 60 fps frame repeatedly would add delay instead of smoothness.
                self.slowFrames = elapsed > 8 ? self.slowFrames + 1 : 0
                if self.slowFrames >= 10 {
                    self.disabled = true
                    self.disabledReason = "Frame generation off (device too slow)"
                    vpLog(.warning, "framegen", "Frame generation too slow (\(String(format: "%.1f", elapsed)) ms); off for this session")
                }
                self.finish(output, input, String(format: "Frame generation 120 fps · %.1f ms", elapsed), completion)
            }
        }
    }
    #endif
}
