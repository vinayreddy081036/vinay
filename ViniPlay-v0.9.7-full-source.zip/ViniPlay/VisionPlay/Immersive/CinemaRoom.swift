import Foundation
import RealityKit
import UIKit
import simd

/// A procedural cinema auditorium around the Theater screen: floor, walls, ceiling, a
/// stage under the screen and rows of seats, all lit by the picture's average colour.
///
/// Everything is built from boxes merged into three meshes (shell, seats, stage), so the
/// whole room is three draw calls, and "lighting" is a material tint refreshed ~8× a second
/// from `ScreenGlowSampler` — no real-time lights or shadows, so it costs next to nothing.
@MainActor
final class CinemaRoom {
    let root = Entity()
    private let shell = ModelEntity()
    private let seats = ModelEntity()
    private let stage = ModelEntity()
    private var builtKey = ""

    init() {
        root.name = "CinemaRoom"
        root.addChild(shell)
        root.addChild(seats)
        root.addChild(stage)
        applyGlow(SIMD3(0.05, 0.05, 0.06))
    }

    struct Dimensions: Equatable {
        var width: Float, height: Float, front: Float, back: Float
    }

    /// Room size for a screen: wider than the screen, ceiling above it, front wall just
    /// behind it, and a few rows of space behind the viewer (who sits at the origin).
    nonisolated static func dimensions(screenWidth: Float, screenCenterY: Float, distance: Float) -> Dimensions {
        let screenHeight = screenWidth * 9 / 16
        return Dimensions(width: max(screenWidth * 1.35, 8),
                          height: max(screenCenterY + screenHeight / 2 + 1.5, 4),
                          front: distance + 0.6,
                          back: 4)
    }

    /// Seat rows (z positions): three behind the viewer, and rows in front that stop 3 m
    /// short of the screen. Seat backs are 0.95 m tall, below a seated eye line of ~1.15 m.
    nonisolated static func seatRows(distance: Float) -> [Float] {
        var rows: [Float] = [0.45, 1.5, 2.55]
        var z: Float = -0.65
        while z > -(distance - 3) && rows.count < 40 {
            rows.append(z)
            z -= 1.05
        }
        return rows
    }

    nonisolated static func floorLevel(screenWidth: Float, screenCenterY: Float) -> Float {
        min(0, screenCenterY - screenWidth * 9 / 32 - 0.3)
    }

    func build(screenWidth: Float, screenCenterY: Float, distance: Float) {
        let key = "\(screenWidth)-\(screenCenterY)-\(distance)"
        guard key != builtKey else { return }
        builtKey = key
        let d = Self.dimensions(screenWidth: screenWidth, screenCenterY: screenCenterY, distance: distance)

        var room = BoxMesh()
        let t: Float = 0.1
        // A giant eye-centered screen extends below the viewer's floor. Put the
        // auditorium pit below its bottom edge so geometry cannot cover the picture.
        let floorY = Self.floorLevel(screenWidth: screenWidth, screenCenterY: screenCenterY)
        let wallHeight = d.height - floorY
        let wallCenter = (d.height + floorY) / 2
        room.box(center: [0, floorY - t / 2, (d.back - d.front) / 2], size: [d.width, t, d.front + d.back])            // floor
        room.box(center: [0, d.height + t / 2, (d.back - d.front) / 2], size: [d.width, t, d.front + d.back])  // ceiling
        room.box(center: [-d.width / 2 - t / 2, wallCenter, (d.back - d.front) / 2], size: [t, wallHeight, d.front + d.back])
        room.box(center: [d.width / 2 + t / 2, wallCenter, (d.back - d.front) / 2], size: [t, wallHeight, d.front + d.back])
        room.box(center: [0, wallCenter, -d.front - t / 2], size: [d.width, wallHeight, t])                    // behind the screen
        room.box(center: [0, wallCenter, d.back + t / 2], size: [d.width, wallHeight, t])                      // back wall
        shell.model = room.model(color: .black)

        var chairs = BoxMesh()
        let seatPitch: Float = 0.62, aisle: Float = 1.2
        let usable = d.width - 2 * aisle
        let perRow = min(max(Int(usable / seatPitch), 4), 32)
        for z in Self.seatRows(distance: distance) where floorY == 0 || z > 0 {
            for i in 0..<perRow {
                let x = -Float(perRow) * seatPitch / 2 + seatPitch * (Float(i) + 0.5)
                if abs(x) < seatPitch * 0.6 && abs(z) < 0.6 { continue } // leave the viewer's own seat open
                chairs.box(center: [x, 0.23, z], size: [0.52, 0.46, 0.5])               // cushion
                chairs.box(center: [x, 0.62, z + 0.27], size: [0.52, 0.66, 0.1])        // back
                chairs.box(center: [x - 0.29, 0.33, z], size: [0.06, 0.2, 0.5])         // armrest
            }
        }
        seats.model = chairs.model(color: .black)

        var platform = BoxMesh()
        let screenBottom = screenCenterY - screenWidth * 9 / 32
        let stageHeight = max(min(screenBottom - 0.1, 0.8), 0.2)
        platform.box(center: [0, floorY + stageHeight / 2, -d.front + 0.8], size: [d.width - 0.4, stageHeight, 1.4])
        stage.model = platform.model(color: .black)
        lastGlow = nil
    }

    private var lastGlow: SIMD3<Float>?

    /// Tints surfaces by the screen colour: the front of the room gets more light than the back.
    func applyGlow(_ rgb: SIMD3<Float>) {
        if let last = lastGlow, simd_distance(last, rgb) < 0.01 { return }
        lastGlow = rgb
        let ambient = SIMD3<Float>(repeating: 0.018)
        func tint(_ amount: Float, _ base: SIMD3<Float>) -> UIColor {
            let c = simd_clamp(base + rgb * amount, SIMD3(repeating: 0), SIMD3(repeating: 1))
            return UIColor(red: CGFloat(c.x), green: CGFloat(c.y), blue: CGFloat(c.z), alpha: 1)
        }
        setColor(shell, tint(0.16, ambient))
        setColor(seats, tint(0.12, SIMD3(0.045, 0.012, 0.015)))   // deep red seats
        setColor(stage, tint(0.22, ambient))
    }

    private func setColor(_ entity: ModelEntity, _ color: UIColor) {
        guard var model = entity.model else { return }
        var material = UnlitMaterial(color: color)
        material.faceCulling = .none
        model.materials = [material]
        entity.model = model
    }
}

/// Accumulates axis-aligned boxes into one mesh.
struct BoxMesh {
    private(set) var positions: [SIMD3<Float>] = []
    private(set) var normals: [SIMD3<Float>] = []
    private(set) var indices: [UInt32] = []

    var boxCount: Int { positions.count / 24 }

    mutating func box(center c: SIMD3<Float>, size s: SIMD3<Float>) {
        let h = s / 2
        let faces: [(SIMD3<Float>, SIMD3<Float>, SIMD3<Float>)] = [
            ([1, 0, 0], [0, 1, 0], [0, 0, 1]), ([-1, 0, 0], [0, 1, 0], [0, 0, -1]),
            ([0, 1, 0], [0, 0, 1], [1, 0, 0]), ([0, -1, 0], [0, 0, -1], [1, 0, 0]),
            ([0, 0, 1], [1, 0, 0], [0, 1, 0]), ([0, 0, -1], [-1, 0, 0], [0, 1, 0]),
        ]
        for (n, u, v) in faces {
            let base = UInt32(positions.count)
            let centre = c + n * h
            let du = u * h, dv = v * h
            for (a, b) in [(-1, -1), (1, -1), (1, 1), (-1, 1)] as [(Float, Float)] {
                positions.append(centre + du * a + dv * b)
                normals.append(n)
            }
            indices += [base, base + 1, base + 2, base, base + 2, base + 3]
        }
    }

    func model(color: UIColor) -> ModelComponent? {
        guard !positions.isEmpty else { return nil }
        var descriptor = MeshDescriptor(name: "boxes")
        descriptor.positions = MeshBuffers.Positions(positions)
        descriptor.normals = MeshBuffers.Normals(normals)
        descriptor.primitives = .triangles(indices)
        guard let mesh = try? MeshResource.generate(from: [descriptor]) else { return nil }
        var material = UnlitMaterial(color: color)
        material.faceCulling = .none
        return ModelComponent(mesh: mesh, materials: [material])
    }
}
