// Games play on the Custom Screen (CustomScreenImmersiveView).
