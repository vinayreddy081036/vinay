import QuartzCore
import ARKit
import Foundation
import simd

/// Pins the Theater screen to a spot in your room with an ARKit world anchor, so it comes
/// back in the same place next time — including after a restart — instead of in front of
/// wherever you happen to be standing. visionOS persists world anchors per location.
///
/// Immersive-space coordinates share ARKit's world origin, so the screen entity's transform
/// (the screen is a direct child of a root at the origin) can be stored directly.
@MainActor
final class RoomAnchor {
    private let session = ARKitSession()
    private let provider = WorldTrackingProvider()
    private var running = false
    private let defaultsKey = "vp.display.roomAnchorID"
    private let defaults: UserDefaults

    /// Called with the saved screen transform whenever the anchor is found or re-localised.
    var onPlacement: ((simd_float4x4) -> Void)?
    private(set) var placement: simd_float4x4?
    private(set) var status = "Not pinned"

    init(defaults: UserDefaults = .standard) { self.defaults = defaults }

    var savedID: UUID? {
        get { defaults.string(forKey: defaultsKey).flatMap(UUID.init(uuidString:)) }
        set { defaults.set(newValue?.uuidString, forKey: defaultsKey) }
    }

    static var isSupported: Bool { WorldTrackingProvider.isSupported }

    func start() async {
        guard !running, Self.isSupported else {
            if !Self.isSupported { status = "Room pinning isn't available here (simulator)" }
            return
        }
        do {
            try await session.run([provider])
            running = true
            status = savedID == nil ? "Not pinned" : "Looking for your saved spot…"
        } catch {
            status = "Room pinning unavailable: \(error.localizedDescription)"
            vpLog(.error, "theater", status)
            return
        }
        for await update in provider.anchorUpdates {
            guard update.anchor.id == savedID else { continue }
            switch update.event {
            case .added, .updated:
                guard update.anchor.isTracked else { continue }
                placement = update.anchor.originFromAnchorTransform
                status = "Pinned to your room"
                onPlacement?(update.anchor.originFromAnchorTransform)
            case .removed:
                placement = nil
                status = "Not pinned"
            }
        }
    }

    var viewerTransform: simd_float4x4? {
        guard running, let device = provider.queryDeviceAnchor(atTimestamp: CACurrentMediaTime()), device.isTracked else { return nil }
        return device.originFromAnchorTransform
    }

    func stop() {
        session.stop()
        running = false
    }

    /// Replaces the saved spot with the screen's current transform.
    func pin(_ transform: simd_float4x4) async {
        guard running else { return }
        if let old = savedID { try? await provider.removeAnchor(forID: old) }
        let anchor = WorldAnchor(originFromAnchorTransform: transform)
        do {
            try await provider.addAnchor(anchor)
            savedID = anchor.id
            placement = transform
            status = "Pinned to your room"
            vpLog(.info, "theater", "Screen pinned to room (anchor \(anchor.id.uuidString.prefix(8)))")
        } catch {
            status = "Couldn't pin: \(error.localizedDescription)"
        }
    }

    func unpin() async {
        if let old = savedID, running { try? await provider.removeAnchor(forID: old) }
        savedID = nil
        placement = nil
        status = "Not pinned"
    }
}
