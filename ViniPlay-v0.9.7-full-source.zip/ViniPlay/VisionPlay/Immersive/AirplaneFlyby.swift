import RealityKit
import UIKit

/// "Airplane": a 10-second fly-by that shows how big the Cinema screen really is.
///
/// Real-size airliners (about 70 m long, 65 m wingspan) take off from behind the screen, climb
/// over its top edge and fly over your head, then disappear. Nothing exists before you press
/// the button or after the 10 seconds, so it costs nothing while you play.
enum AirplaneFlyby {
    static let duration: TimeInterval = 10
    static let length: Float = 70
    static let wingspan: Float = 65

    /// Start a fly-by around a screen at `screen` (its transform: scale = width in metres).
    /// Returns the planes' parent so the caller can add it to the scene; it removes itself.
    @MainActor
    static func make(screen: Transform, eyeHeight: Float) -> Entity {
        let root = Entity()
        root.name = "AirplaneFlyby"
        let width = screen.scale.x
        let height = width * 9 / 16
        // How many fit side by side across the screen (a few, never a crowd).
        let count = max(1, min(5, Int(width / (wingspan * 3))))
        let rotation = screen.rotation
        let center = screen.translation
        let forward = rotation.act(SIMD3<Float>(0, 0, 1))      // from the screen towards you

        for i in 0..<count {
            let plane = makePlane()
            // Spread across the screen, slight height and timing differences.
            let lane = count == 1 ? 0 : (Float(i) / Float(count - 1) - 0.5) * width * 0.7
            let side = rotation.act(SIMD3<Float>(lane, 0, 0))
            // Behind the screen, below its top edge (hidden), then up over the top edge...
            let start = center + side + rotation.act(SIMD3<Float>(0, height * 0.1, -max(300, width * 0.4)))
            let overTop = center + side + rotation.act(SIMD3<Float>(0, height * 0.5 + wingspan, 0))
            // ...and on over your head, out behind you.
            let end = SIMD3<Float>(side.x * 0.4, eyeHeight + max(80, height * 0.35), 0)
                + forward * max(600, width * 0.6)
            let heading = simd_normalize(end - start)
            plane.position = start
            plane.orientation = simd_quatf(from: SIMD3<Float>(0, 0, -1), to: heading)
            root.addChild(plane)

            let delay = Double(i) * 0.6
            let firstLeg = duration * 0.45
            Task { @MainActor in
                try? await Task.sleep(for: .seconds(delay))
                var mid = Transform(matrix: plane.transformMatrix(relativeTo: nil))
                mid.translation = overTop
                plane.move(to: mid, relativeTo: nil, duration: firstLeg, timingFunction: .easeIn)
                try? await Task.sleep(for: .seconds(firstLeg))
                var last = mid
                last.translation = end
                plane.move(to: last, relativeTo: nil, duration: duration - firstLeg - delay, timingFunction: .linear)
            }
        }
        // Gone after 10 seconds.
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(duration + 0.5))
            root.removeFromParent()
        }
        return root
    }

    /// A simple airliner shape (original, built from boxes), nose pointing along -Z.
    @MainActor
    private static func makePlane() -> Entity {
        let body = SimpleMaterial(color: UIColor(white: 0.92, alpha: 1), roughness: 0.4, isMetallic: true)
        let accent = SimpleMaterial(color: UIColor(red: 0.15, green: 0.35, blue: 0.85, alpha: 1), roughness: 0.4, isMetallic: false)
        let light = UnlitMaterial(color: UIColor(red: 1, green: 0.2, blue: 0.2, alpha: 1))
        let plane = Entity()
        func part(_ mesh: MeshResource, _ material: some Material, _ position: SIMD3<Float>) {
            let entity = ModelEntity(mesh: mesh, materials: [material])
            entity.position = position
            plane.addChild(entity)
        }
        // Fuselage, nose, wings, engines, tail.
        part(.generateBox(width: 6, height: 6, depth: length, cornerRadius: 2.8), body, [0, 0, 0])
        part(.generateBox(width: 6.2, height: 1.2, depth: length * 0.9), accent, [0, -0.5, 0])
        part(.generateBox(width: wingspan, height: 0.8, depth: 11, cornerRadius: 0.3), body, [0, -1.5, 2])
        part(.generateBox(width: 3.2, height: 3.2, depth: 7, cornerRadius: 1.5), body, [-13, -3.5, -2])
        part(.generateBox(width: 3.2, height: 3.2, depth: 7, cornerRadius: 1.5), body, [13, -3.5, -2])
        part(.generateBox(width: 22, height: 0.6, depth: 6, cornerRadius: 0.2), body, [0, 1, length / 2 - 4])
        part(.generateBox(width: 0.8, height: 12, depth: 8, cornerRadius: 0.2), accent, [0, 7, length / 2 - 5])
        // Wing-tip lights so they read even against a bright picture.
        part(.generateSphere(radius: 1.2), light, [-wingspan / 2, -1.5, 2])
        part(.generateSphere(radius: 1.2), UnlitMaterial(color: .green), [wingspan / 2, -1.5, 2])
        return plane
    }
}
