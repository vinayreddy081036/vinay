import Foundation
import RealityKit
import simd

/// Geometry for the virtual screen: flat when `curvature` is 0, otherwise a section of
/// a cylinder centred on the viewer.
enum CurvedScreenMesh {
    /// Arc angle (radians) for a curvature setting in 0…1 (max 100°).
    static func arcAngle(forCurvature curvature: Float) -> Float {
        min(max(curvature, 0), 1) * (100 * .pi / 180)
    }

    /// Vertex positions/uvs for a screen of `width` × `height` metres, centred at the origin,
    /// facing +Z. Exposed separately for unit tests.
    static func vertices(width: Float, height: Float, curvature: Float, segments: Int = 64)
        -> (positions: [SIMD3<Float>], normals: [SIMD3<Float>], uvs: [SIMD2<Float>], indices: [UInt32]) {
        let columns = max(1, curvature <= 0.001 ? 1 : segments)
        let angle = arcAngle(forCurvature: curvature)
        let radius = angle > 0.0001 ? width / angle : 0
        var positions: [SIMD3<Float>] = []
        var normals: [SIMD3<Float>] = []
        var uvs: [SIMD2<Float>] = []
        positions.reserveCapacity((columns + 1) * 2)
        for column in 0...columns {
            let u = Float(column) / Float(columns)
            let x: Float
            let z: Float
            let normal: SIMD3<Float>
            if radius > 0 {
                let theta = (u - 0.5) * angle
                x = radius * sin(theta)
                // Edges bend toward the viewer; the centre stays at z = 0.
                z = radius * (1 - cos(theta))
                normal = simd_normalize(SIMD3<Float>(-sin(theta), 0, cos(theta)))
            } else {
                x = (u - 0.5) * width
                z = 0
                normal = SIMD3<Float>(0, 0, 1)
            }
            for row in 0...1 {
                let v = Float(row)
                positions.append(SIMD3<Float>(x, (0.5 - v) * height, z))
                normals.append(normal)
                uvs.append(SIMD2<Float>(u, 1 - v))
            }
        }
        var indices: [UInt32] = []
        indices.reserveCapacity(columns * 6)
        for column in 0..<columns {
            let topLeft = UInt32(column * 2)
            let bottomLeft = topLeft + 1
            let topRight = topLeft + 2
            let bottomRight = topLeft + 3
            indices += [topLeft, bottomLeft, topRight, topRight, bottomLeft, bottomRight]
        }
        return (positions, normals, uvs, indices)
    }

    static func makeMesh(width: Float, height: Float, curvature: Float) throws -> MeshResource {
        let data = vertices(width: width, height: height, curvature: curvature)
        var descriptor = MeshDescriptor(name: "VisionPlayScreen")
        descriptor.positions = MeshBuffers.Positions(data.positions)
        descriptor.normals = MeshBuffers.Normals(data.normals)
        descriptor.textureCoordinates = MeshBuffers.TextureCoordinates(data.uvs)
        descriptor.primitives = .triangles(data.indices)
        return try MeshResource.generate(from: [descriptor])
    }
}

/// Changes depth along the existing viewer-to-screen ray, rather than world Z.
enum ScreenPlacement {
    static func center(atDistance distance: Float, from viewer: SIMD3<Float>, through center: SIMD3<Float>) -> SIMD3<Float> {
        let delta = center - viewer
        let direction = simd_length_squared(delta) > 0.000001 ? simd_normalize(delta) : SIMD3<Float>(0, 0, -1)
        return viewer + direction * max(distance, 0.01)
    }
}
