import SwiftUI
import RealityKit
import UIKit

/// App-owned display with exact Size and Distance.
///
/// - **Size** is the screen's real width in metres. It stays exactly as you set it.
/// - **Distance** moves that same screen nearer or farther (2 m – 10 km). Farther away it
///   looks smaller, like the back row of a cinema. A big screen is never allowed closer
///   than where it fills 140° of your view, so it can't end up in your face.
///
/// Settings sit on your left side (55° left, facing you), always visible and out of the way
/// of the picture. Hands and the controller can both use them (End Game asks first, so a stray
/// controller press can't end a game). Immersive spaces don't show window ornaments,
/// which is why the panel is a RealityView attachment.
struct CustomScreenImmersiveView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(\.openWindow) private var openWindow
    @State private var target: RealityScreenTarget?
    @State private var screen = ModelEntity()
    /// Glowing frame that previews a Size/Distance drag before the picture moves.
    @State private var outline = ModelEntity()
    @State private var meshKey = ""
    @State private var placedOnce = false
    /// The settings panel and its grab bar: pinch the bar and drag to put the panel anywhere.
    @State private var panelHolder = Entity()
    @State private var grabBar = ModelEntity()
    @State private var controlsEntity: Entity?
    @State private var dragStart: (holder: SIMD3<Float>, finger: SIMD3<Float>)?
    /// True only while the pinch on the grab bar is held. @GestureState resets itself when
    /// visionOS cancels or loses the pinch, so the panel can never stay "grabbed".
    @GestureState private var grabbing = false
    /// The drag has passed the dead zone (moved on purpose), so the panel may follow.
    @State private var panelMoving = false
    /// Hand movement needed before the panel starts to follow (metres).
    private let grabDeadZone: Float = 0.02
    /// A game has played on this screen; when it ends, the screen closes and Home returns.
    @State private var hadGame = false
    /// Moving the screen itself: pinch it and drag to put it anywhere around you.
    @GestureState private var screenGrabbing = false
    @State private var screenDragStart: (angles: SIMD2<Float>, finger: SIMD3<Float>)?
    @State private var screenMoving = false
    /// Live angles while dragging (nil = use the saved ones).
    @State private var draggedAngles: SIMD2<Float>?
    /// The bar under the screen: pinch it and drag to move the screen (like a window's bar).
    @State private var screenBar = ModelEntity()

    /// Eye height the screen and panel are placed around (metres above the floor).
    private let eyeHeight: Float = 1.4

    var body: some View {
        RealityView { content, attachments in
            screen.name = "CustomScreen"
            content.add(screen)
            Self.configureGrabBar(screenBar)
            screenBar.name = "ScreenGrabBar"
            content.add(screenBar)
            outline.name = "CustomScreenOutline"
            outline.model = Self.makeOutlineModel()
            outline.isEnabled = false
            content.add(outline)
            // Settings panel: on your left by default, or wherever you last moved it. It never
            // moves with the screen. A grab bar above it moves it, like a window's bar.
            panelHolder.name = "SettingsPanel"
            panelHolder.transform = panelTransform()
            if let controls = attachments.entity(for: "controls") {
                controls.transform = Transform()
                panelHolder.addChild(controls)
                controlsEntity = controls
            }
            Self.configureGrabBar(grabBar)
            grabBar.position = [0, 0.3, 0]
            panelHolder.addChild(grabBar)
            content.add(panelHolder)
            // "Connecting…" card, in front of the screen until the picture arrives.
            if let status = attachments.entity(for: "status") {
                status.position = [0, eyeHeight, -1.6]
                status.name = "StatusCard"
                content.add(status)
            }
            let renderTarget = RealityScreenTarget(screen: screen)
            // Tone-mapped to correct BT.709 colours. Raw HDR into RealityKit's texture would be
            // BT.2020 without a colour label and look washed out, so it stays off here.
            renderTarget.allowHDR = false
            target = renderTarget
            model.stream.renderer?.attachTheater(target: renderTarget)
            model.stream.applyMotionAndCaptureSettings()   // stops the window-only 120 Hz pacer
            model.settings.normalizeCustomScreen()
            layout()
            Task { try? await Task.sleep(for: .milliseconds(300)); placeGrabBar() }
        } update: { content, _ in
            target?.allowHDR = false
            // Show the status card only while a game is connecting / reconnecting.
            let phase = model.stream.phase
            let connecting = phase == .connecting || phase == .reconnecting
            content.entities.first(where: { $0.name == "StatusCard" })?.isEnabled = connecting
        } attachments: {
            Attachment(id: "controls") {
                CustomScreenLiveControls(onExit: {
                    // End Game / Close: stop the stream, close the screen; Home comes back.
                    if model.stream.isActive { model.stream.disconnect() }
                    Task { await dismissImmersiveSpace() }
                })
                .environment(model)
            }
            Attachment(id: "status") {
                ConnectingCard().environment(model)
            }
        }
        // Pinch the grab bar and drag: the panel follows your hand and turns to face you.
        .gesture(DragGesture(minimumDistance: 12)
            .targetedToEntity(grabBar)
            .updating($grabbing) { _, state, _ in state = true }
            .onChanged { value in
                let finger = value.convert(value.location3D, from: .local, to: .scene)
                if dragStart == nil { dragStart = (panelHolder.position(relativeTo: nil), finger) }
                guard let start = dragStart else { return }
                let moved = finger - start.finger
                // Small hand tremor or a pinch that drifts doesn't move the panel: only a
                // deliberate drag past the dead zone does, and then it follows exactly.
                if !panelMoving {
                    guard simd_length(moved) > grabDeadZone else { return }
                    panelMoving = true
                }
                let position = start.holder + moved
                panelHolder.setPosition(position, relativeTo: nil)
                panelHolder.setOrientation(Self.facingYou(from: position, eyeHeight: eyeHeight), relativeTo: nil)
            })
        // Pinch the screen and drag: it swings around you (left/right, up/down), staying at the
        // same distance and always facing you. Hand movement is scaled, so even a giant, far
        // screen goes where you point.
        .gesture(DragGesture(minimumDistance: 12)
            .targetedToEntity(screenBar)
            .updating($screenGrabbing) { _, state, _ in state = true }
            .onChanged { value in
                moveScreen(to: value.convert(value.location3D, from: .local, to: .scene))
            })
        .onChange(of: screenGrabbing) { _, isGrabbing in
            guard !isGrabbing else { return }
            if screenMoving, let angles = draggedAngles {
                model.settings.cinemaScreenAngles = [Double(angles.x), Double(angles.y)]
            }
            screenDragStart = nil
            screenMoving = false
            draggedAngles = nil
        }
        // Airplane: a 10-second fly-by from behind the screen (only when you press it).
        .onChange(of: model.airplaneRequest) {
            let flyby = AirplaneFlyby.make(screen: screenTransform(angles: currentAngles()), eyeHeight: eyeHeight)
            screen.parent?.addChild(flyby)
        }
        // Long-press the Digital Crown to recenter: the big screen comes back in front of you.
        .onWorldRecenter { _ in
            model.settings.cinemaScreenAngles = nil
            layout()
        }
        .onChange(of: model.settings.cinemaScreenAngles) {
            if screenDragStart == nil { layout() }   // "Center Screen" puts it back ahead
        }
        // Ends the drag however it finishes — let go, or the pinch lost/cancelled by visionOS.
        .onChange(of: grabbing) { _, isGrabbing in
            guard !isGrabbing else { return }
            let didMove = panelMoving
            dragStart = nil
            panelMoving = false
            if didMove {
                let p = panelHolder.position(relativeTo: nil)
                model.settings.screenPanelPosition = [Double(p.x), Double(p.y), Double(p.z)]
            }
        }
        .controllerPlaysTheGame()
        .onChange(of: model.settings.screenPanelPosition) {
            // "Put Back" (nil) returns the panel to your left; a drag already placed it.
            if model.settings.screenPanelPosition == nil, dragStart == nil {
                panelHolder.move(to: panelTransform(), relativeTo: panelHolder.parent, duration: 0.35, timingFunction: .easeInOut)
            }
        }
        .onChange(of: model.screenPanelCollapsed) {
            // The panel changes size when folded: keep the bar just above it.
            Task { try? await Task.sleep(for: .milliseconds(350)); placeGrabBar() }
        }
        .onChange(of: model.settings.screenWidthMeters) { layout() }
        .onChange(of: model.settings.viewingDistance) { layout() }
        .onChange(of: model.settings.displayShape) { layout() }
        .onChange(of: model.settings.curvature) { layout() }
        .onChange(of: model.screenEditor.isDragging) { updateOutline() }
        .onChange(of: model.screenEditor.draftWidth) { updateOutline() }
        .onChange(of: model.screenEditor.draftDistance) { updateOutline() }
        .onAppear {
            // Every time the Cinema opens, the screen starts straight ahead. (A spot saved from
            // last time could be out of view, so you saw only the settings panel.)
            model.settings.cinemaScreenAngles = nil
            model.customScreenOpen = true
            model.theaterOpen = true
            hadGame = model.stream.isActive
            if model.stream.phase == .streaming { model.startGameDetection() }
        }
        .onChange(of: model.stream.phase) { _, phase in
            if model.stream.isActive { hadGame = true }
            if phase == .streaming { model.startGameDetection() }
            // The game ended (you quit, the PS5 ended it, or it failed): back to Home, where
            // any error is shown.
            if hadGame && !model.stream.isActive {
                Task { await dismissImmersiveSpace() }
            }
        }
        .onChange(of: model.stream.loginPINRequest != nil) { _, asking in
            if asking { model.screenPanelCollapsed = false }
        }
        // "Play PS5" from Siri / Shortcuts while this screen is open (Home is closed then).
        .onReceive(NotificationCenter.default.publisher(for: .visionPlayLaunchRequest)) { _ in
            guard let request = LaunchCoordinator.pending, !model.stream.isActive else { return }
            LaunchCoordinator.pending = nil
            let all = model.consoles.consoles
            if let console = request.consoleID.flatMap({ id in all.first { $0.id == id } }) ?? all.first {
                model.stream.connectAutomatically(to: console)
            }
        }
        .onDisappear {
            if let target { model.stream.renderer?.detachTheater(target: target) }
            model.theaterOpen = false
            model.customScreenOpen = false
            // Leaving the Cinema while a game is on: it carries on in the game window.
            if [.connecting, .streaming, .reconnecting].contains(model.stream.phase) {
                openWindow(id: SceneID.playback)
                return
            }
            model.stopGameDetection()
            if model.stream.isActive { model.stream.disconnect() }
            openWindow(id: SceneID.main)
        }
    }

    /// The mesh is built once at 1 m wide (rebuilt only when the shape changes) and scaled to
    /// the chosen width, so size and distance changes can glide smoothly instead of jumping.
    private func layout() {
        let settings = model.settings
        let curvature = settings.displayShape == .curved ? Float(settings.curvature) : 0
        let key = "\(settings.displayShape)-\(curvature)"
        if key != meshKey,
           let mesh = try? CurvedScreenMesh.makeMesh(width: 1, height: 9.0 / 16.0, curvature: curvature) {
            let materials = screen.model?.materials ?? [UnlitMaterial(color: .black)]
            screen.model = ModelComponent(mesh: mesh, materials: materials)
            meshKey = key
        }
        let destination = screenTransform(angles: currentAngles())
        placeScreenBar(for: destination)
        if placedOnce {
            // Glide to the new size or distance (a real screen sliding back, not a jump).
            screen.move(to: destination, relativeTo: screen.parent, duration: 0.45, timingFunction: .easeInOut)
        } else {
            screen.transform = destination
            placedOnce = true
        }
        // Sound comes from the edges of this screen at its real size and distance.
        model.refreshAudioLayout()
    }



    /// The settings' fixed place: 55° to your left (outside where you look at the game),
    /// 1.2 m away, at about eye level, turned to face you, scaled up 30% so it's easy to read
    /// and to hit with a pinch.
    /// Saved spot (facing you) or the default place on your left.
    private func panelTransform() -> Transform {
        guard let p = model.settings.screenPanelPosition, p.count == 3 else {
            return Self.leftSidePanelTransform(eyeHeight: eyeHeight)
        }
        let position = SIMD3<Float>(Float(p[0]), Float(p[1]), Float(p[2]))
        return Transform(scale: SIMD3<Float>(repeating: 1.3),
                         rotation: Self.facingYou(from: position, eyeHeight: eyeHeight),
                         translation: position)
    }

    /// Turns a panel at `position` to face you (you are at the origin, eyes at `eyeHeight`).
    static func facingYou(from position: SIMD3<Float>, eyeHeight: Float) -> simd_quatf {
        let toYou = SIMD3<Float>(0, eyeHeight, 0) - position
        return simd_quatf(angle: atan2(toYou.x, toYou.z), axis: [0, 1, 0])
    }

    /// A window-style bar: pinch and drag it to move the panel. Larger invisible hit area.
    static func configureGrabBar(_ bar: ModelEntity) {
        bar.model = ModelComponent(mesh: .generateBox(width: 0.14, height: 0.012, depth: 0.006, cornerRadius: 0.006),
                                   materials: [UnlitMaterial(color: UIColor(white: 1, alpha: 0.75))])
        bar.name = "SettingsGrabBar"
        bar.components.set(InputTargetComponent())
        bar.components.set(CollisionComponent(shapes: [.generateBox(width: 0.26, height: 0.06, depth: 0.04)]))
        bar.components.set(HoverEffectComponent())
    }

    /// Puts the grab bar centred just above the panel's top edge.
    private func placeGrabBar() {
        guard let controls = controlsEntity else { return }
        let bounds = controls.visualBounds(relativeTo: panelHolder)
        guard bounds.extents.y > 0.01 else { return }
        grabBar.position = [bounds.center.x, bounds.max.y + 0.025, 0]
    }

    static func leftSidePanelTransform(eyeHeight: Float) -> Transform {
        let yaw: Float = 55 * .pi / 180
        let distance: Float = 1.2
        let position = SIMD3<Float>(-sin(yaw) * distance, eyeHeight - 0.1, -cos(yaw) * distance)
        let face = simd_quatf(angle: yaw, axis: [0, 1, 0])
        return Transform(scale: SIMD3<Float>(repeating: 1.3), rotation: face, translation: position)
    }

    /// Shows the outline at the size/distance being dragged; hides it on release.
    /// Follow the hand while the screen (or its bar) is pinched: the screen swings around you,
    /// keeping its size and distance and facing you. About 90° for half a metre of hand movement,
    /// so a giant far screen still goes where you point.
    private func moveScreen(to finger: SIMD3<Float>) {
        if screenDragStart == nil { screenDragStart = (currentAngles(), finger) }
        guard let start = screenDragStart else { return }
        let moved = finger - start.finger
        if !screenMoving {
            guard simd_length(moved) > grabDeadZone else { return }
            screenMoving = true
        }
        // Gentle gain (about 45° for half a metre of hand movement) and smoothing, so hand
        // jitter can't fling the screen around. Never further than 100° to either side.
        let targetYaw = min(max(start.angles.x - moved.x * 1.6, -1.75), 1.75)
        let targetPitch = min(max(start.angles.y + moved.y * 1.6, -0.9), 0.9)
        let previous = draggedAngles ?? start.angles
        let smoothed = previous + (SIMD2(targetYaw, targetPitch) - previous) * 0.35
        draggedAngles = smoothed
        let transform = screenTransform(angles: smoothed)
        screen.transform = transform
        placeScreenBar(for: transform)
    }

    /// The bar sits centred just under the screen's bottom edge, facing you, and grows with
    /// distance so it is always easy to see and pinch.
    private func placeScreenBar(for transform: Transform) {
        let width = transform.scale.x
        let distance = Float(model.settings.viewingDistance)
        let barScale = max(1, distance / 1.5)
        let below = transform.rotation.act(SIMD3<Float>(0, -width * 9 / 32 - 0.04 * barScale, 0.01))
        screenBar.transform = Transform(scale: SIMD3<Float>(repeating: barScale),
                                        rotation: transform.rotation,
                                        translation: transform.translation + below)
    }

    /// Saved screen direction around you: (turn, tilt) in radians.
    private func currentAngles() -> SIMD2<Float> {
        if let draggedAngles { return draggedAngles }
        guard let a = model.settings.cinemaScreenAngles, a.count == 2 else { return .zero }
        return SIMD2(Float(a[0]), Float(a[1]))
    }

    /// The screen at its size and distance, turned `angles` around you and facing you.
    private func screenTransform(angles: SIMD2<Float>, width: Float? = nil, distance: Float? = nil) -> Transform {
        let settings = model.settings
        let w = width ?? Float(settings.screenWidthMeters)
        let d = distance ?? Float(settings.viewingDistance)
        let rotation = simd_quatf(angle: angles.x, axis: [0, 1, 0]) * simd_quatf(angle: angles.y, axis: [1, 0, 0])
        let offset = rotation.act(SIMD3<Float>(0, 0, -d))
        return Transform(scale: SIMD3<Float>(repeating: w), rotation: rotation,
                         translation: SIMD3<Float>(0, eyeHeight, 0) + offset)
    }

    private func updateOutline() {
        let editor = model.screenEditor
        guard editor.isDragging else {
            outline.isEnabled = false
            return
        }
        let settings = model.settings
        let width = Float(editor.width(settings))
        outline.transform = screenTransform(angles: currentAngles(), width: width,
                                            distance: Float(editor.distance(settings)) - 0.01)
        outline.isEnabled = true
    }

    /// A 1 m wide, 16:9 glowing frame (four thin bars), scaled like the screen.
    private static func makeOutlineModel() -> ModelComponent? {
        let w: Float = 1, h: Float = 9.0 / 16.0, t: Float = 0.008
        var positions: [SIMD3<Float>] = []
        var indices: [UInt32] = []
        func bar(_ cx: Float, _ cy: Float, _ bw: Float, _ bh: Float) {
            let base = UInt32(positions.count)
            positions += [[cx - bw / 2, cy - bh / 2, 0], [cx + bw / 2, cy - bh / 2, 0],
                          [cx + bw / 2, cy + bh / 2, 0], [cx - bw / 2, cy + bh / 2, 0]]
            indices += [base, base + 1, base + 2, base, base + 2, base + 3]
        }
        bar(0, h / 2, w + t, t)
        bar(0, -h / 2, w + t, t)
        bar(-w / 2, 0, t, h)
        bar(w / 2, 0, t, h)
        var descriptor = MeshDescriptor(name: "outline")
        descriptor.positions = MeshBuffers.Positions(positions)
        descriptor.primitives = .triangles(indices)
        guard let mesh = try? MeshResource.generate(from: [descriptor]) else { return nil }
        var material = UnlitMaterial(color: UIColor(red: 0.3, green: 0.9, blue: 1, alpha: 1))
        material.faceCulling = .none
        return ModelComponent(mesh: mesh, materials: [material])
    }
}

/// The game screen's panel: Size, Distance, screenshots, all settings and End Game.
private struct CustomScreenLiveControls: View {
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(AppModel.self) private var model
    let onExit: () -> Void
    /// Shows every ViniPlay setting inside this panel (no separate window).
    @State private var showAllSettings = false
    /// "End the game?" — the controller can press panel buttons too, so ending needs a second press.
    @State private var confirmEnd = false

    /// Done folds the panel into a small pill; tap the pill to bring it back.
    private var collapsed: Bool {
        get { model.screenPanelCollapsed }
        nonmutating set { model.screenPanelCollapsed = newValue }
    }

    var body: some View {
        Group {
            if collapsed {
                Button { withAnimation(.easeInOut(duration: 0.25)) { collapsed = false } } label: {
                    Label("Settings", systemImage: "slider.horizontal.3")
                }
                .padding(10)
            } else if showAllSettings {
                SettingsView(inPlayback: true, onDone: { showAllSettings = false })
                    .environment(model)
                    .frame(width: 640, height: 720)
            } else {
                VStack(alignment: .leading, spacing: 10) {
                    PINPrompt().environment(model)
                    HStack {
                        Image(systemName: "rectangle.on.rectangle")
                        Text("Screen").font(.headline)
                        ControllerBattery().environment(model)
                        Spacer()
                        Button { model.settings.screenPanelPosition = nil } label: {
                            Label("Put Back", systemImage: "arrow.uturn.backward")
                        }
                        .help("Move this panel back to your left")
                        Button(model.stream.isActive ? "End Game" : "Close", role: .destructive) {
                            if model.stream.isActive { confirmEnd = true } else { onExit() }
                        }
                        Button("Done") { withAnimation(.easeInOut(duration: 0.25)) { collapsed = true } }
                            .buttonStyle(.borderedProminent)
                    }

                    if confirmEnd {
                        HStack {
                            Text("End the game?").font(.headline)
                            Spacer()
                            Button("Keep Playing") { confirmEnd = false }
                            Button("End Game", role: .destructive) { confirmEnd = false; onExit() }
                                .buttonStyle(.borderedProminent)
                        }
                        .padding(10)
                        .background(.red.opacity(0.15), in: RoundedRectangle(cornerRadius: 12))
                    }
                    ScreenBarsView(showPreview: true, quickDistances: [10, 100, 1000, 3000, 10000])
                        .environment(model)
                    HStack {
                        CaptureButtons(stream: model.stream, instantReplay: false)
                        Button { Task { await dismissImmersiveSpace() } } label: {
                            Label("Back to Window", systemImage: "rectangle.on.rectangle")
                        }
                        Button { model.settings.cinemaScreenAngles = nil } label: {
                            Label("Center Screen", systemImage: "scope")
                        }
                        .disabled(model.settings.cinemaScreenAngles == nil)
                        // 10 seconds of real-size airliners flying out from behind the screen.
                        Button { model.airplaneRequest += 1 } label: {
                            Label("Airplane", systemImage: "airplane")
                        }
                        .disabled(model.stream.phase != .streaming)
                        Spacer()
                        Button { showAllSettings = true } label: { Label("All Settings", systemImage: "gearshape") }
                    }
                    .buttonStyle(.bordered)
                    if model.settings.showStats { StatsOverlay(stats: model.stream.statistics) }
                    Text("Pinch and drag to see a glowing outline; the picture glides there when you let go. Done shrinks this to a small button. Pinch the bar above this panel and drag to put it anywhere; Put Back returns it to your left. Use your hands or the controller here.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                .padding(16)
                .frame(width: 600)
            }
        }
        .glassBackgroundEffect()
        // The PS5 asks for its PIN: show the main panel (where the PIN box is) straight away.
        .onChange(of: model.stream.loginPINRequest != nil) { _, asking in
            if asking { showAllSettings = false; collapsed = false }
        }
    }

}

/// "Connecting…" shown in front of you until the picture arrives.
struct ConnectingCard: View {
    @Environment(AppModel.self) private var model
    var body: some View {
        let stream = model.stream
        VStack(spacing: 12) {
            ProgressView()
            Text(stream.statusDetail.isEmpty ? stream.phase.rawValue : stream.statusDetail)
                .multilineTextAlignment(.center)
        }
        .padding(24)
        .frame(maxWidth: 520)
        .glassBackgroundEffect()
    }
}

/// The PS5's Remote Play PIN, asked inside the panel when the console wants it.
struct PINPrompt: View {
    @Environment(AppModel.self) private var model
    @State private var pin = ""
    var body: some View {
        let stream = model.stream
        if stream.loginPINRequest != nil {
            VStack(alignment: .leading, spacing: 8) {
                Text("Console PIN").font(.headline)
                Text("Enter the Remote Play PIN set on the PS5.").font(.caption).foregroundStyle(.secondary)
                HStack {
                    SecureField("4-digit PIN", text: $pin).keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                    Button("Send") { stream.submitLoginPIN(pin); pin = "" }
                        .buttonStyle(.borderedProminent)
                    Button("Cancel", role: .cancel) { stream.disconnect() }
                }
            }
            .padding(12)
            .background(.orange.opacity(0.15), in: RoundedRectangle(cornerRadius: 12))
        }
    }
}

/// The controller's battery level, refreshed every 30 seconds.
private struct ControllerBattery: View {
    @Environment(AppModel.self) private var model
    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { _ in
            if let battery = model.controllers.batteryStatus {
                let percent = Int((battery.level * 100).rounded())
                Label("\(percent)%\(battery.charging ? " ⚡︎" : "")", systemImage: Self.symbol(battery.level))
                    .font(.caption)
                    .foregroundStyle(percent <= 15 && !battery.charging ? .red : .secondary)
                    .help("Controller battery")
            }
        }
    }

    private static func symbol(_ level: Float) -> String {
        switch level {
        case ..<0.13: return "battery.0percent"
        case ..<0.38: return "battery.25percent"
        case ..<0.63: return "battery.50percent"
        case ..<0.88: return "battery.75percent"
        default: return "battery.100percent"
        }
    }
}
