import Foundation
import Metal
import RealityKit
import UIKit

/// Renders the stream into a RealityKit `LowLevelTexture` shown on the virtual screen
/// entity. Metal writes straight into RealityKit's texture — no CPU copy.
@MainActor
final class RealityScreenTarget: RenderTarget {
    nonisolated var pixelFormat: MTLPixelFormat { .rgba16Float }
    /// Float textures are sampled as linear light by RealityKit.
    nonisolated var expectsLinear: Bool { true }
    nonisolated var requiresMainThread: Bool { true }
    /// Experimental: pass HDR highlights (values above SDR white) into the float texture
    /// instead of tone-mapping them. Whether RealityKit shows them brighter than SDR white
    /// in an immersive space is unverified, so it is opt-in (Settings › Display).
    nonisolated(unsafe) var allowHDR = false
    nonisolated var supportsEDR: Bool { allowHDR }

    private(set) var texture: LowLevelTexture?
    private(set) var textureResource: TextureResource?
    private weak var screen: ModelEntity?
    private var size = (width: 0, height: 0)
    private(set) var lastError: String?

    init(screen: ModelEntity) {
        self.screen = screen
    }

    func setScreen(_ entity: ModelEntity) {
        screen = entity
        applyMaterial()
    }

    nonisolated func prepare(width: Int, height: Int) -> (width: Int, height: Int) {
        MainActor.assumeIsolated { prepareOnMain(width: width, height: height) }
    }

    nonisolated func encode(commandBuffer: MTLCommandBuffer, draw: (MTLTexture) -> Void) -> Bool {
        MainActor.assumeIsolated {
            guard let texture else { return false }
            let destination = texture.replace(using: commandBuffer)
            draw(destination)
            return true
        }
    }

    private func prepareOnMain(width: Int, height: Int) -> (width: Int, height: Int) {
        // Up to 4K (3840 × 2160). The heavy work is done off the main thread (see
        // MainThreadTargetBridge); here we only hold RealityKit's texture.
        let fit = min(1, min(3840 / Double(max(width, 1)), 2160 / Double(max(height, 1))))
        let w = min(max(Int((Double(width) * fit).rounded()), 16), 3840)
        let h = min(max(Int((Double(height) * fit).rounded()), 16), 2160)
        if texture != nil, size.width == w, size.height == h { return size }
        do {
            var descriptor = LowLevelTexture.Descriptor()
            descriptor.textureType = .type2D
            descriptor.pixelFormat = .rgba16Float
            descriptor.width = w
            descriptor.height = h
            descriptor.depth = 1
            descriptor.mipmapLevelCount = 1
            descriptor.textureUsage = [.shaderRead, .shaderWrite, .renderTarget]
            let created = try LowLevelTexture(descriptor: descriptor)
            texture = created
            textureResource = try TextureResource(from: created)
            size = (w, h)
            lastError = nil
            applyMaterial()
            vpLog(.info, "immersive", "Screen texture \(w)×\(h) (rgba16Float)")
        } catch {
            lastError = error.localizedDescription
            vpLog(.error, "immersive", "LowLevelTexture creation failed: \(error.localizedDescription)")
        }
        return size
    }

    private func applyMaterial() {
        guard let screen, let textureResource else { return }
        // No RealityKit tone curve on top: the picture is already graded by our shaders.
        var material = UnlitMaterial(applyPostProcessToneMap: false)
        material.color = .init(tint: .white, texture: .init(textureResource))
        screen.model?.materials = [material]
    }
}
