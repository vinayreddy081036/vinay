import Foundation

/// Short error codes ("VP-110") shown with every connection error, so a problem can be
/// reported in one word. One catalog feeds the error messages, Diagnostics › Error Codes
/// and the README table.
struct VPErrorCode: Identifiable, Equatable, Sendable {
    let code: String
    let title: String
    let fix: String
    var id: String { code }

    /// "VP-110 · Video stream never arrived"
    var label: String { "\(code) · \(title)" }
    /// What the user sees.
    func message(detail: String = "") -> String {
        let extra = detail.isEmpty ? "" : " (PS5 said: \(detail))"
        return "Error \(code): \(title). \(fix)\(extra)"
    }

    // MARK: Session start / stream (chiaki quit reasons 2–13 → VP-102…113)
    static let sessionUnknown = VPErrorCode(code: "VP-102", title: "The PS5 turned the session down",
        fix: "Restart the PS5 (hold the power button until it beeps twice) and try again.")
    static let sessionRefused = VPErrorCode(code: "VP-103", title: "The PS5 refused the connection",
        fix: "On the PS5 turn on Settings › System › Remote Play › Enable Remote Play, and make sure no one else is using Remote Play.")
    static let inUse = VPErrorCode(code: "VP-104", title: "Remote Play is already in use",
        fix: "Close the PlayStation Portal or the other Remote Play app, then try again.")
    static let rpCrash = VPErrorCode(code: "VP-105", title: "Remote Play crashed on the PS5",
        fix: "Restart the PS5 and try again.")
    static let versionMismatch = VPErrorCode(code: "VP-106", title: "The PS5 didn't accept this Remote Play version",
        fix: "Update the PS5's system software, then remove the console in VisionPlay and pair it again.")
    static let controlUnknown = VPErrorCode(code: "VP-107", title: "The control connection failed",
        fix: "Try again; if it repeats, restart the PS5 and the router.")
    static let controlConnect = VPErrorCode(code: "VP-108", title: "Couldn't reach the PS5 on TCP port 9295",
        fix: "Put the headset and PS5 on the same network, turn off any VPN or iCloud Private Relay, and check Local Network access for VisionPlay is on.")
    static let badKeys = VPErrorCode(code: "VP-109", title: "The PS5 rejected the saved pairing",
        fix: "Remove the console in VisionPlay and pair it again (PS5: Settings › System › Remote Play › Pair Device).")
    static let streamNeverArrived = VPErrorCode(code: "VP-110", title: "The video stream never arrived",
        fix: "The router is probably blocking traffic between devices (UDP 9296–9297): turn off AP/client isolation and guest network, or connect the PS5 by Ethernet.")
    static let remoteClosed = VPErrorCode(code: "VP-111", title: "The PS5 closed the stream",
        fix: "Reconnect. If it keeps happening, check the PS5 isn't running out of bandwidth (wire it, or lower the resolution).")
    static let remoteShutdown = VPErrorCode(code: "VP-112", title: "The PS5 shut down or went into rest mode",
        fix: "Wake the PS5 and connect again.")
    static let psnRegistFailed = VPErrorCode(code: "VP-113", title: "PSN registration for Internet play failed",
        fix: "Sign in to PSN again in Internet Play.")
    // VP-102 split by what the PS5 actually said (from the core's log).
    static let pairingInvalid = VPErrorCode(code: "VP-114", title: "The PS5 says this pairing isn't valid any more",
        fix: "Remove the console in VisionPlay, then on the PS5 open Settings › System › Remote Play › Pair Device and pair again. Also check the PS5 user you play as is the one you paired with.")
    static let psnAccountMismatch = VPErrorCode(code: "VP-115", title: "The PS5 doesn't recognise the PSN account",
        fix: "Pair again using the PSN account ID of the user signed in on the PS5 (sign in to PSN in VisionPlay to fill it in automatically).")
    static let sessionNoReply = VPErrorCode(code: "VP-116", title: "The PS5 didn't reply to the session request",
        fix: "The PS5 was found but closed the connection. Turn on Settings › System › Power Saving › Features Available in Rest Mode › Stay Connected to the Internet and Enable Turning On PS5 from Network, restart the PS5, and try again.")
    static let badReply = VPErrorCode(code: "VP-117", title: "The PS5's reply couldn't be read",
        fix: "Update the PS5's system software and pair again. If it repeats, send the Copy Log text.")

    static let sessionOther = VPErrorCode(code: "VP-199", title: "The session ended unexpectedly",
        fix: "Try again. If it repeats, share a problem report from Diagnostics.")

    // MARK: Before the session
    static let network = VPErrorCode(code: "VP-100", title: "Network problem",
        fix: "Check the headset's Wi-Fi and that the PS5 is on and connected.")
    static let discovery = VPErrorCode(code: "VP-201", title: "Couldn't search the local network",
        fix: "Allow Local Network access for VisionPlay in Settings › Privacy & Security › Local Network.")
    static let registration = VPErrorCode(code: "VP-202", title: "Pairing failed",
        fix: "Keep the code on the PS5 screen, and use the PSN account that is signed in on the console.")
    static let wrongPIN = VPErrorCode(code: "VP-203", title: "The PS5 rejected the pairing code",
        fix: "Get a new code on the PS5 and enter it straight away.")
    static let asleep = VPErrorCode(code: "VP-204", title: "The PS5 is in rest mode",
        fix: "Waking it can take up to 30 seconds; VisionPlay keeps trying.")
    static let noCredentials = VPErrorCode(code: "VP-205", title: "No saved pairing for this console",
        fix: "Pair the console again.")
    static let unsupported = VPErrorCode(code: "VP-206", title: "Unsupported stream settings",
        fix: "Set Codec to H.264 and Resolution to 1080p or lower in Settings.")
    static let notFound = VPErrorCode(code: "VP-207", title: "The PS5 wasn't found on this network",
        fix: "Make sure the PS5 is on (or in rest mode with 'Stay connected to the internet' on) and on the same Wi-Fi, or use Internet Play.")
    static let timeout = VPErrorCode(code: "VP-208", title: "The PS5 didn't answer in time",
        fix: "Try again; if it repeats, restart the PS5 and router.")

    // MARK: Playback
    static let decoder = VPErrorCode(code: "VP-301", title: "The video couldn't be decoded",
        fix: "Switch Codec to H.264 in Settings and reconnect.")

    static let all: [VPErrorCode] = [network, sessionUnknown, sessionRefused, inUse, rpCrash, versionMismatch,
                                     controlUnknown, controlConnect, badKeys, streamNeverArrived, remoteClosed,
                                     remoteShutdown, psnRegistFailed, pairingInvalid, psnAccountMismatch, sessionNoReply,
                                     badReply, sessionOther, discovery, registration,
                                     wrongPIN, asleep, noCredentials, unsupported, notFound, timeout, decoder]

    /// Refines VP-102 from a core log line, or nil if the line says nothing about it.
    static func sessionRefusal(fromLog message: String) -> VPErrorCode? {
        if message.hasPrefix("Reported Application Reason:") {
            let lower = message.lowercased()
            if lower.contains("0x80108b09") { return pairingInvalid }
            if lower.contains("0x80108b02") { return psnAccountMismatch }
            return nil
        }
        if message.contains("Session request connect failed") || message.contains("Failed to receive session request response")
            || message.contains("Failed to send session request") { return sessionNoReply }
        if message.contains("Failed to parse session request response") || message.contains("Nonce invalid") { return badReply }
        return nil
    }

    /// The PS5's raw reason number from the log line, for the message ("0x80108b09").
    static func applicationReason(fromLog message: String) -> String? {
        guard message.hasPrefix("Reported Application Reason:"),
              let range = message.range(of: "0x[0-9a-fA-F]+", options: .regularExpression) else { return nil }
        return String(message[range])
    }

    /// chiaki quit reason → code.
    static func forQuitReason(_ reason: Int32) -> VPErrorCode {
        switch reason {
        case -1: return timeout   // VisionPlay's own 45 s connect timeout
        case 2: return sessionUnknown
        case 3: return sessionRefused
        case 4: return inUse
        case 5: return rpCrash
        case 6: return versionMismatch
        case 7: return controlUnknown
        case 8: return controlConnect
        case 9: return badKeys
        case 10: return streamNeverArrived
        case 11: return remoteClosed
        case 12: return remoteShutdown
        case 13: return psnRegistFailed
        default: return sessionOther
        }
    }

    static func lookup(_ code: String) -> VPErrorCode? {
        let wanted = code.uppercased().replacingOccurrences(of: " ", with: "")
        return all.first { $0.code == wanted || $0.code == "VP-" + wanted }
    }
}
