import Foundation

/// A console found on the local network by the discovery service.
struct DiscoveredConsole: Identifiable, Equatable, Hashable, Sendable {
    enum PowerState: String, Sendable {
        case ready = "Ready"
        case standby = "Standby"
        case unknown = "Unknown"
    }

    /// Console MAC address as uppercase hex (Sony's `host-id`), used as a stable identifier.
    var hostID: String
    var hostName: String
    var address: String
    var isPS5: Bool
    var state: PowerState
    var systemVersion: String?
    var runningAppName: String?
    var runningAppTitleID: String?
    var lastSeen: Date

    var id: String { hostID.isEmpty ? address : hostID }
}

/// A console that has been paired with VisionPlay. Secrets live in the Keychain
/// (`ConsoleCredentials`); this type is safe to persist in ordinary storage.
struct RegisteredConsole: Identifiable, Codable, Equatable, Hashable, Sendable {
    /// Console MAC as uppercase hex without separators.
    var id: String
    var nickname: String
    var lastKnownAddress: String
    var isPS5: Bool
    var target: Int32
    var registeredAt: Date
    /// PSN device id (hex) of this console, set up via Internet Play. nil = LAN only.
    var psnDeviceID: String? = nil
    /// Who this registration belongs to ("Vinay", "Guest"…). A console can be registered
    /// once per PSN account; the extra registrations get a suffixed id.
    var accountName: String? = nil

    /// The console's MAC (the id without any per-account suffix) — used to match discovery.
    var mac: String { String(id.prefix(12)) }

    /// "PS5 · Vinay" when an account name is set.
    var displayName: String {
        guard let accountName, !accountName.isEmpty else { return nickname }
        return "\(nickname) · \(accountName)"
    }

    /// Registration id for a console MAC and account: the plain MAC for the first account,
    /// MAC + "-" + 6 hex digits of the account id for any other account on the same console.
    static func registrationID(mac: String, accountID: Data, existing: [RegisteredConsole],
                               existingAccountID: (String) -> Data?) -> String {
        guard let first = existing.first(where: { $0.id == mac }),
              let firstAccount = existingAccountID(first.id), firstAccount != accountID else { return mac }
        return mac + "-" + accountID.prefix(3).map { String(format: "%02X", $0) }.joined()
    }

    var displayMAC: String {
        stride(from: 0, to: mac.count, by: 2).map { offset -> String in
            let start = mac.index(mac.startIndex, offsetBy: offset)
            let end = mac.index(start, offsetBy: min(2, mac.distance(from: start, to: mac.endIndex)))
            return String(mac[start..<end])
        }.joined(separator: ":")
    }
}

/// Secrets produced by Remote Play registration. Stored only in the Keychain.
struct ConsoleCredentials: Codable, Equatable, Sendable {
    /// `rp_regist_key`, 16 bytes (ASCII hex digits padded with zeros).
    var registKey: Data
    /// `rp_key` ("morning"), 16 bytes.
    var rpKey: Data
    var rpKeyType: UInt32
    /// The 8-byte PSN account id used for registration.
    var psnAccountID: Data

    var isValid: Bool {
        registKey.count == 16 && rpKey.count == 16 && psnAccountID.count == 8
    }
}

extension Data {
    var hexString: String { map { String(format: "%02X", $0) }.joined() }

    init?(hexString: String) {
        let clean = hexString.filter { !$0.isWhitespace && $0 != ":" }
        guard clean.count % 2 == 0 else { return nil }
        var bytes = [UInt8]()
        bytes.reserveCapacity(clean.count / 2)
        var index = clean.startIndex
        while index < clean.endIndex {
            let next = clean.index(index, offsetBy: 2)
            guard let byte = UInt8(clean[index..<next], radix: 16) else { return nil }
            bytes.append(byte)
            index = next
        }
        self.init(bytes)
    }
}
