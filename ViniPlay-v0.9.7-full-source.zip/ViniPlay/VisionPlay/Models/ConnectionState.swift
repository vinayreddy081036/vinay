import Foundation

/// The user-visible Remote Play connection lifecycle:
/// Disconnected → Discovering → Registering → Connecting → Streaming → Disconnecting.
///
/// `ConnectionStateMachine` only allows the transitions listed in `canTransition`,
/// so the UI can never show "Streaming" unless the session reported CONNECTED.
enum ConnectionPhase: String, Codable, Sendable, CaseIterable {
    case disconnected = "Disconnected"
    case discovering = "Discovering"
    case registering = "Registering"
    case connecting = "Connecting"
    case streaming = "Streaming"
    case reconnecting = "Reconnecting"
    case disconnecting = "Disconnecting"
}

enum ConnectionError: Error, Equatable, Sendable, LocalizedError {
    case discoveryFailed(String)
    case registrationFailed(String)
    case incorrectPIN
    case authenticationFailed(String)
    case network(String)
    case consoleBusy
    case consoleAsleep
    case unsupportedStream(String)
    case missingCredentials
    case decoder(String)
    case remoteDisconnected(String)

    /// Short code for this error ("VP-110").
    var code: VPErrorCode {
        switch self {
        case .discoveryFailed: return .discovery
        case .registrationFailed: return .registration
        case .incorrectPIN: return .wrongPIN
        case .authenticationFailed: return .badKeys
        case .network(let detail):
            // Session-start failures carry their own code at the front of the message.
            if detail.hasPrefix("Error VP-"), let code = VPErrorCode.lookup(String(detail.dropFirst(6).prefix(6))) { return code }
            return .network
        case .consoleBusy: return .inUse
        case .consoleAsleep: return .asleep
        case .unsupportedStream: return .unsupported
        case .missingCredentials: return .noCredentials
        case .decoder: return .decoder
        case .remoteDisconnected: return .remoteClosed
        }
    }

    var errorDescription: String? {
        switch self {
        case .network(let detail) where detail.hasPrefix("Error VP-"):
            return detail
        case .network(let detail), .discoveryFailed(let detail), .registrationFailed(let detail),
             .authenticationFailed(let detail), .unsupportedStream(let detail), .decoder(let detail),
             .remoteDisconnected(let detail):
            return code.message(detail: detail)
        case .incorrectPIN, .consoleBusy, .consoleAsleep, .missingCredentials:
            return code.message()
        }
    }
}

struct ConnectionStateMachine: Sendable {
    private(set) var phase: ConnectionPhase = .disconnected
    private(set) var lastError: ConnectionError?
    private(set) var history: [ConnectionPhase] = [.disconnected]

    static func canTransition(from: ConnectionPhase, to: ConnectionPhase) -> Bool {
        if from == to { return false }
        switch (from, to) {
        case (.disconnected, .discovering),
             (.disconnected, .registering),
             (.disconnected, .connecting),
             (.discovering, .disconnected),
             (.discovering, .registering),
             (.discovering, .connecting),
             (.registering, .disconnected),
             (.registering, .connecting),
             (.connecting, .streaming),
             (.connecting, .disconnecting),
             (.connecting, .disconnected),
             (.connecting, .reconnecting),
             (.streaming, .disconnecting),
             (.streaming, .reconnecting),
             (.streaming, .disconnected),
             (.reconnecting, .connecting),
             (.reconnecting, .disconnecting),
             (.reconnecting, .disconnected),
             (.disconnecting, .disconnected):
            return true
        default:
            return false
        }
    }

    /// Applies a transition. Returns false (and leaves the state unchanged) if it is not allowed.
    @discardableResult
    mutating func transition(to next: ConnectionPhase, error: ConnectionError? = nil) -> Bool {
        guard Self.canTransition(from: phase, to: next) else { return false }
        phase = next
        if let error { lastError = error }
        else if next == .connecting || next == .streaming || next == .discovering || next == .registering {
            lastError = nil
        }
        history.append(next)
        if history.count > 64 { history.removeFirst(history.count - 64) }
        return true
    }

    mutating func fail(_ error: ConnectionError) {
        lastError = error
        if phase != .disconnected {
            if phase == .streaming || phase == .connecting || phase == .reconnecting {
                transition(to: .disconnecting)
            }
            transition(to: .disconnected)
        }
    }
}

/// Exponential back-off for automatic reconnection.
struct ReconnectPolicy: Sendable, Equatable {
    var maxAttempts: Int = 6
    var baseDelay: TimeInterval = 1.0
    var maxDelay: TimeInterval = 15.0

    static func canWaitForOwnSessionRelease(reason: Int32, sameConsole: Bool, secondsSinceStop: TimeInterval?, attempt: Int) -> Bool {
        reason == 4 && sameConsole && (secondsSinceStop.map { $0 >= 0 && $0 < 45 } ?? false) && attempt < 6
    }

    /// Delay before attempt number `attempt` (1-based), or nil when attempts are exhausted.
    /// The first retry is immediate (most drops are a single Wi-Fi hiccup); later ones back off.
    func delay(forAttempt attempt: Int) -> TimeInterval? {
        guard attempt >= 1, attempt <= maxAttempts else { return nil }
        if attempt == 1 { return 0 }
        let raw = baseDelay * pow(2.0, Double(attempt - 2))
        return min(raw, maxDelay)
    }

    /// Quit reasons that are worth retrying automatically. Authentication/version
    /// failures and user-requested stops are not.
    /// Plain-language cause and fix (with error code) for a chiaki quit reason.
    static func explain(quitReason: Int32, detail: String = "") -> String {
        VPErrorCode.forQuitReason(quitReason).message(detail: detail)
    }

    static func shouldRetry(quitReason: Int32, isError: Bool) -> Bool {
        guard isError else { return false }
        switch quitReason {
        case 4,  // SESSION_REQUEST_RP_IN_USE
             5,  // SESSION_REQUEST_RP_CRASH
             6,  // SESSION_REQUEST_RP_VERSION_MISMATCH
             9,  // CTRL_CONNECTION_REFUSED (bad keys)
             13: // PSN_REGIST_FAILED
            return false
        default:
            return true
        }
    }
}
