import Foundation

/// A framework-independent snapshot of a gamepad, so the mapping to the Remote Play
/// controller format can be unit-tested without hardware.
struct GamepadSnapshot: Equatable, Sendable {
    var leftStick = SIMD2<Float>(0, 0)    // x right +, y up +   (GameController convention)
    var rightStick = SIMD2<Float>(0, 0)
    var leftTrigger: Float = 0            // 0…1
    var rightTrigger: Float = 0
    var cross = false, circle = false, square = false, triangle = false
    var dpadUp = false, dpadDown = false, dpadLeft = false, dpadRight = false
    var l1 = false, r1 = false, l3 = false, r3 = false
    var options = false, create = false, ps = false, touchpadButton = false
    /// Touchpad fingers in normalized coordinates (0…1, origin top-left), nil when lifted.
    var touch0: SIMD2<Float>?
    var touch1: SIMD2<Float>?

    /// Combines a physical controller with the on-screen hand controls: buttons are OR'd,
    /// triggers take the larger value, sticks use whichever is pushed further, and the
    /// on-screen touchpad is used only when the physical one is idle.
    static func merge(physical p: GamepadSnapshot, virtual v: GamepadSnapshot) -> GamepadSnapshot {
        var m = p
        func stick(_ a: SIMD2<Float>, _ b: SIMD2<Float>) -> SIMD2<Float> {
            (a.x * a.x + a.y * a.y) >= (b.x * b.x + b.y * b.y) ? a : b
        }
        m.leftStick = stick(p.leftStick, v.leftStick)
        m.rightStick = stick(p.rightStick, v.rightStick)
        m.leftTrigger = max(p.leftTrigger, v.leftTrigger)
        m.rightTrigger = max(p.rightTrigger, v.rightTrigger)
        m.cross = p.cross || v.cross; m.circle = p.circle || v.circle
        m.square = p.square || v.square; m.triangle = p.triangle || v.triangle
        m.dpadUp = p.dpadUp || v.dpadUp; m.dpadDown = p.dpadDown || v.dpadDown
        m.dpadLeft = p.dpadLeft || v.dpadLeft; m.dpadRight = p.dpadRight || v.dpadRight
        m.l1 = p.l1 || v.l1; m.r1 = p.r1 || v.r1; m.l3 = p.l3 || v.l3; m.r3 = p.r3 || v.r3
        m.options = p.options || v.options; m.create = p.create || v.create
        m.ps = p.ps || v.ps; m.touchpadButton = p.touchpadButton || v.touchpadButton
        if p.touch0 == nil && p.touch1 == nil {
            m.touch0 = v.touch0
            m.touch1 = v.touch1
        }
        return m
    }

    var pressedButtonNames: [String] {
        var names: [String] = []
        if cross { names.append("Cross") }
        if circle { names.append("Circle") }
        if square { names.append("Square") }
        if triangle { names.append("Triangle") }
        if dpadUp { names.append("D-pad Up") }
        if dpadDown { names.append("D-pad Down") }
        if dpadLeft { names.append("D-pad Left") }
        if dpadRight { names.append("D-pad Right") }
        if l1 { names.append("L1") }
        if r1 { names.append("R1") }
        if l3 { names.append("L3") }
        if r3 { names.append("R3") }
        if options { names.append("Options") }
        if create { names.append("Create") }
        if ps { names.append("PS") }
        if touchpadButton { names.append("Touchpad click") }
        return names
    }
}

enum ControllerMapping {
    /// DualSense touchpad resolution used by Remote Play (matches chiaki-ng).
    static let ps5TouchpadSize = SIMD2<Float>(1919, 1079)
    static let ps4TouchpadSize = SIMD2<Float>(1920, 942)
    /// Radial dead zone applied to sticks before conversion.
    static let stickDeadZone: Float = 0.06

    static func axis(_ value: Float) -> Int16 {
        let clamped = min(max(value, -1), 1)
        return Int16((clamped * 32767).rounded())
    }

    static func trigger(_ value: Float) -> UInt8 {
        UInt8((min(max(value, 0), 1) * 255).rounded())
    }

    static func applyDeadZone(_ stick: SIMD2<Float>, deadZone: Float = stickDeadZone) -> SIMD2<Float> {
        let magnitude = (stick.x * stick.x + stick.y * stick.y).squareRoot()
        guard magnitude > deadZone else { return .zero }
        let scaled = min((magnitude - deadZone) / (1 - deadZone), 1)
        return stick / magnitude * scaled
    }

    /// Builds the Chiaki controller state (buttons, analog values). Touches are applied
    /// separately by `TouchTracker` because they need persistent finger ids.
    static func buttonsAndAxes(from pad: GamepadSnapshot) -> (buttons: UInt32, l2: UInt8, r2: UInt8,
                                                              lx: Int16, ly: Int16, rx: Int16, ry: Int16) {
        var buttons: UInt32 = 0
        func set(_ flag: Bool, _ bit: UInt32) { if flag { buttons |= bit } }
        set(pad.cross, CHIAKI_CONTROLLER_BUTTON_CROSS.rawValue)
        set(pad.circle, CHIAKI_CONTROLLER_BUTTON_MOON.rawValue)
        set(pad.square, CHIAKI_CONTROLLER_BUTTON_BOX.rawValue)
        set(pad.triangle, CHIAKI_CONTROLLER_BUTTON_PYRAMID.rawValue)
        set(pad.dpadLeft, CHIAKI_CONTROLLER_BUTTON_DPAD_LEFT.rawValue)
        set(pad.dpadRight, CHIAKI_CONTROLLER_BUTTON_DPAD_RIGHT.rawValue)
        set(pad.dpadUp, CHIAKI_CONTROLLER_BUTTON_DPAD_UP.rawValue)
        set(pad.dpadDown, CHIAKI_CONTROLLER_BUTTON_DPAD_DOWN.rawValue)
        set(pad.l1, CHIAKI_CONTROLLER_BUTTON_L1.rawValue)
        set(pad.r1, CHIAKI_CONTROLLER_BUTTON_R1.rawValue)
        set(pad.l3, CHIAKI_CONTROLLER_BUTTON_L3.rawValue)
        set(pad.r3, CHIAKI_CONTROLLER_BUTTON_R3.rawValue)
        set(pad.options, CHIAKI_CONTROLLER_BUTTON_OPTIONS.rawValue)
        set(pad.create, CHIAKI_CONTROLLER_BUTTON_SHARE.rawValue)
        set(pad.touchpadButton, CHIAKI_CONTROLLER_BUTTON_TOUCHPAD.rawValue)
        set(pad.ps, CHIAKI_CONTROLLER_BUTTON_PS.rawValue)
        let l2 = trigger(pad.leftTrigger)
        let r2 = trigger(pad.rightTrigger)
        if l2 > 0 { buttons |= CHIAKI_CONTROLLER_ANALOG_BUTTON_L2.rawValue }
        if r2 > 0 { buttons |= CHIAKI_CONTROLLER_ANALOG_BUTTON_R2.rawValue }
        let left = applyDeadZone(pad.leftStick)
        let right = applyDeadZone(pad.rightStick)
        // Remote Play (like SDL) uses y-down for sticks: pushing up is negative.
        return (buttons, l2, r2, axis(left.x), axis(-left.y), axis(right.x), axis(-right.y))
    }

    static func makeState(from pad: GamepadSnapshot, touches: TouchTracker? = nil,
                          touchpadSize: SIMD2<Float> = ps5TouchpadSize) -> ChiakiControllerState {
        var state = ChiakiControllerState()
        chiaki_controller_state_set_idle(&state)
        let mapped = buttonsAndAxes(from: pad)
        state.buttons = mapped.buttons
        state.l2_state = mapped.l2
        state.r2_state = mapped.r2
        state.left_x = mapped.lx
        state.left_y = mapped.ly
        state.right_x = mapped.rx
        state.right_y = mapped.ry
        touches?.apply(pad: pad, to: &state, touchpadSize: touchpadSize)
        return state
    }
}

/// Keeps stable Remote Play touch ids across frames for up to two fingers.
final class TouchTracker {
    private var ids: [Int8?] = [nil, nil]
    private var lastPositions: [SIMD2<UInt16>?] = [nil, nil]
    private var nextID: UInt8 = 0

    func apply(pad: GamepadSnapshot, to state: inout ChiakiControllerState, touchpadSize: SIMD2<Float>) {
        state.touch_id_next = nextID
        let fingers = [pad.touch0, pad.touch1]
        withUnsafeMutableBytes(of: &state.touches) { raw in
            let touches = raw.bindMemory(to: ChiakiControllerTouch.self)
            for index in 0..<2 {
                if let point = fingers[index] {
                    let x = UInt16(min(max(point.x, 0), 1) * touchpadSize.x)
                    let y = UInt16(min(max(point.y, 0), 1) * touchpadSize.y)
                    if ids[index] == nil {
                        ids[index] = Int8(bitPattern: nextID & 0x7F)
                        nextID = (nextID + 1) & 0x7F
                    }
                    touches[index].id = ids[index]!
                    touches[index].x = x
                    touches[index].y = y
                    lastPositions[index] = SIMD2(x, y)
                } else {
                    ids[index] = nil
                    lastPositions[index] = nil
                    touches[index].id = -1
                }
            }
        }
        state.touch_id_next = nextID
    }

    func reset() {
        ids = [nil, nil]
        lastPositions = [nil, nil]
    }
}
