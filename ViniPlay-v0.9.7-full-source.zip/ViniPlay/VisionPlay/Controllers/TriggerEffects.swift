import Foundation

/// DualSense adaptive-trigger effects sent by the PS5 (raw 10-byte effect blocks),
/// decoded into the subset Apple's `GCDualSenseAdaptiveTrigger` can express.
///
/// Byte layouts follow the community documentation of the DualSense output report
/// (Nielk1's TriggerEffectGenerator): 0x05 off, 0x21 feedback, 0x25 weapon, 0x26 vibration.
enum TriggerEffect: Equatable, Sendable {
    case off
    /// Resistance from `start` (0…1 of travel) with `strength` (0…1).
    case feedback(start: Float, strength: Float)
    /// Resistance between `start` and `end` that "breaks" like a trigger.
    case weapon(start: Float, end: Float, strength: Float)
    /// Vibration from `start` with `amplitude` (0…1) and `frequency` (0…1 of 255 Hz).
    case vibration(start: Float, amplitude: Float, frequency: Float)
    /// An effect type we recognised but cannot reproduce through GameController.
    case unsupported(UInt8)

    static func decode(type: UInt8, data: [UInt8]) -> TriggerEffect {
        guard data.count >= 10 else { return .unsupported(type) }
        func u16(_ i: Int) -> UInt16 { UInt16(data[i]) | (UInt16(data[i + 1]) << 8) }
        func u32(_ i: Int) -> UInt32 {
            UInt32(data[i]) | (UInt32(data[i + 1]) << 8) | (UInt32(data[i + 2]) << 16) | (UInt32(data[i + 3]) << 24)
        }
        switch type {
        case 0x00, 0x05:
            return .off
        case 0x21: // Feedback: 10 zones, 3-bit strength per active zone
            let active = u16(0)
            let forces = u32(2)
            guard active != 0, let first = (0..<10).first(where: { active & (1 << $0) != 0 }) else { return .off }
            var total: Float = 0
            var count: Float = 0
            for zone in 0..<10 where active & (1 << zone) != 0 {
                total += Float(((forces >> (zone * 3)) & 0x7) + 1) / 8
                count += 1
            }
            return .feedback(start: Float(first) / 9, strength: count > 0 ? total / count : 0)
        case 0x25: // Weapon: start/stop zone bits, 3-bit strength
            let zones = u16(0)
            let set = (0..<10).filter { zones & (1 << $0) != 0 }
            guard let start = set.first, let end = set.last, end > start else { return .off }
            let strength = Float((data[2] & 0x7) + 1) / 8
            return .weapon(start: Float(start) / 9, end: Float(end) / 9, strength: strength)
        case 0x26: // Vibration: active zones, 3-bit amplitude per zone, frequency in Hz
            let active = u16(0)
            let amplitudes = u32(2)
            guard active != 0, let first = (0..<10).first(where: { active & (1 << $0) != 0 }) else { return .off }
            var total: Float = 0
            var count: Float = 0
            for zone in 0..<10 where active & (1 << zone) != 0 {
                total += Float(((amplitudes >> (zone * 3)) & 0x7) + 1) / 8
                count += 1
            }
            let frequency = Float(data[8]) / 255
            return .vibration(start: Float(first) / 9, amplitude: count > 0 ? total / count : 0, frequency: frequency)
        default:
            return .unsupported(type)
        }
    }
}
