import Foundation
import GameController
import Observation

/// Tracks connected game controllers (DualSense first), converts their input into the
/// Remote Play controller format, and applies console feedback (light bar,
/// adaptive triggers) where visionOS exposes it.
@Observable
final class ControllerManager {
    struct ControllerInfo: Identifiable, Equatable {
        let id: ObjectIdentifier
        let name: String
        let isDualSense: Bool
        let batteryLevel: Float?
        let hasHaptics: Bool
        let hasMotion: Bool
        let hasLight: Bool
    }

    private(set) var controllers: [ControllerInfo] = []
    private(set) var activeName: String?
    /// Latest input snapshot, refreshed at most ~30×/s — only while the controller test
    /// screen is open, so normal play sends nothing to the main thread for it.
    private(set) var snapshot = GamepadSnapshot()
    /// Set by the controller test screen while it is visible.
    @ObservationIgnored var publishSnapshot = false
    private(set) var lastTriggerEffect: String = "None"

    /// Called on the GameController handler queue with every new state.
    @ObservationIgnored var onStateChange: ((ChiakiControllerState) -> Void)?
    @ObservationIgnored var motionEnabled = false { didSet { configureMotion() } }
    /// Fired (main thread) when Create + Options are pressed together: save the last 30 s.
    @ObservationIgnored var onCaptureCombo: (() -> Void)?
    @ObservationIgnored private var physical = GamepadSnapshot()
    @ObservationIgnored private var virtual = GamepadSnapshot()
    @ObservationIgnored private var comboLatched = false

    @ObservationIgnored private weak var active: GCController?
    @ObservationIgnored private let touchTracker = TouchTracker()
    @ObservationIgnored private var orientationTracker = ChiakiOrientationTracker()
    @ObservationIgnored private var accelZero = ChiakiAccelNewZero()
    @ObservationIgnored private var lastMotion = (gyro: SIMD3<Float>(0, 0, 0), accel: SIMD3<Float>(0, 0, -1))
    @ObservationIgnored private let handlerQueue = DispatchQueue(label: "VisionPlay.controller", qos: .userInteractive)
    @ObservationIgnored private var lastUIUpdate = Date.distantPast
    @ObservationIgnored private var observers: [NSObjectProtocol] = []

    /// The active controller's battery, read live: (0…1, charging) or nil if unknown.
    var batteryStatus: (level: Float, charging: Bool)? {
        guard let battery = active?.battery, battery.batteryState != .unknown else { return nil }
        return (battery.batteryLevel, battery.batteryState == .charging)
    }
    @ObservationIgnored private let startTime = Date()

    init() {
        chiaki_orientation_tracker_init(&orientationTracker)
        chiaki_accel_new_zero_set_inactive(&accelZero, false)
        let center = NotificationCenter.default
        observers.append(center.addObserver(forName: .GCControllerDidConnect, object: nil, queue: .main) { [weak self] _ in
            self?.refresh()
        })
        observers.append(center.addObserver(forName: .GCControllerDidDisconnect, object: nil, queue: .main) { [weak self] _ in
            self?.refresh()
        })
        GCController.startWirelessControllerDiscovery(completionHandler: nil)
        refresh()
    }

    deinit {
        for observer in observers { NotificationCenter.default.removeObserver(observer) }
        GCController.stopWirelessControllerDiscovery()
    }

    func refresh() {
        let all = GCController.controllers()
        controllers = all.map { controller in
            ControllerInfo(id: ObjectIdentifier(controller),
                           name: controller.vendorName ?? controller.productCategory,
                           isDualSense: controller.extendedGamepad is GCDualSenseGamepad,
                           batteryLevel: controller.battery.map { $0.batteryLevel },
                           hasHaptics: controller.haptics != nil,
                           hasMotion: controller.motion != nil,
                           hasLight: controller.light != nil)
        }
        let preferred = all.first { $0.extendedGamepad is GCDualSenseGamepad } ?? all.first { $0.extendedGamepad != nil }
        if preferred !== active { activate(preferred) }
    }

    private func activate(_ controller: GCController?) {
        if let old = active {
            old.extendedGamepad?.valueChangedHandler = nil
            old.motion?.valueChangedHandler = nil
        }
        touchTracker.reset()
        active = controller
        activeName = controller.map { $0.vendorName ?? $0.productCategory }
        guard let controller, let gamepad = controller.extendedGamepad else { return }
        vpLog(.info, "controller", "Using controller: \(activeName ?? "?")")
        controller.handlerQueue = handlerQueue

        // Let the app receive Home/Options/Create instead of the system handling them.
        gamepad.buttonHome?.preferredSystemGestureState = .disabled
        gamepad.buttonOptions?.preferredSystemGestureState = .disabled
        gamepad.buttonMenu.preferredSystemGestureState = .disabled

        gamepad.valueChangedHandler = { [weak self] pad, _ in
            self?.handleInput(pad)
        }
        configureMotion()
    }

    private func configureMotion() {
        guard let controller = active, let motion = controller.motion else { return }
        if motionEnabled {
            if motion.sensorsRequireManualActivation { motion.sensorsActive = true }
            motion.valueChangedHandler = { [weak self] motion in
                self?.handleMotion(motion)
            }
        } else {
            motion.valueChangedHandler = nil
            if motion.sensorsRequireManualActivation { motion.sensorsActive = false }
        }
    }

    private func handleMotion(_ motion: GCMotion) {
        // GameController: rotation in rad/s; acceleration in g. Axis conventions for
        // DualSense on visionOS are not documented; this mapping is experimental.
        let gyro = SIMD3<Float>(Float(motion.rotationRate.x), Float(motion.rotationRate.y), Float(motion.rotationRate.z))
        let accel: SIMD3<Float>
        if motion.hasGravityAndUserAcceleration {
            accel = SIMD3<Float>(Float(motion.gravity.x + motion.userAcceleration.x),
                                 Float(motion.gravity.y + motion.userAcceleration.y),
                                 Float(motion.gravity.z + motion.userAcceleration.z))
        } else {
            accel = SIMD3<Float>(Float(motion.acceleration.x), Float(motion.acceleration.y), Float(motion.acceleration.z))
        }
        lastMotion = (gyro, accel)
        let timestamp = UInt32(truncatingIfNeeded: UInt64(Date().timeIntervalSince(startTime) * 1_000_000))
        chiaki_orientation_tracker_update(&orientationTracker, gyro.x, gyro.y, gyro.z, accel.x, accel.y, accel.z,
                                          &accelZero, false, timestamp)
        if let pad = active?.extendedGamepad { handleInput(pad) }
    }

    private func handleInput(_ pad: GCExtendedGamepad) {
        var s = GamepadSnapshot()
        s.leftStick = SIMD2(pad.leftThumbstick.xAxis.value, pad.leftThumbstick.yAxis.value)
        s.rightStick = SIMD2(pad.rightThumbstick.xAxis.value, pad.rightThumbstick.yAxis.value)
        s.leftTrigger = pad.leftTrigger.value
        s.rightTrigger = pad.rightTrigger.value
        s.cross = pad.buttonA.isPressed
        s.circle = pad.buttonB.isPressed
        s.square = pad.buttonX.isPressed
        s.triangle = pad.buttonY.isPressed
        s.dpadUp = pad.dpad.up.isPressed
        s.dpadDown = pad.dpad.down.isPressed
        s.dpadLeft = pad.dpad.left.isPressed
        s.dpadRight = pad.dpad.right.isPressed
        s.l1 = pad.leftShoulder.isPressed
        s.r1 = pad.rightShoulder.isPressed
        s.l3 = pad.leftThumbstickButton?.isPressed ?? false
        s.r3 = pad.rightThumbstickButton?.isPressed ?? false
        s.options = pad.buttonMenu.isPressed
        s.create = pad.buttonOptions?.isPressed ?? false
        s.ps = pad.buttonHome?.isPressed ?? false

        if let dualSense = pad as? GCDualSenseGamepad {
            s.touchpadButton = dualSense.touchpadButton.isPressed
            s.touch0 = Self.touchPoint(dualSense.touchpadPrimary)
            s.touch1 = Self.touchPoint(dualSense.touchpadSecondary)
        } else if let dualShock = pad as? GCDualShockGamepad {
            s.touchpadButton = dualShock.touchpadButton.isPressed
            s.touch0 = Self.touchPoint(dualShock.touchpadPrimary)
            s.touch1 = Self.touchPoint(dualShock.touchpadSecondary)
        }

        // Capture shortcut: hold Create, press Options. Neither button reaches the PS5 while latched.
        if s.create && s.options {
            if !comboLatched {
                comboLatched = true
                DispatchQueue.main.async { self.onCaptureCombo?() }
            }
        }
        if comboLatched {
            if !s.create && !s.options { comboLatched = false }
            s.create = false
            s.options = false
        }
        physical = s
        emitMergedState()

        let now = Date()
        if publishSnapshot, now.timeIntervalSince(lastUIUpdate) > 1.0 / 30.0 {
            lastUIUpdate = now
            DispatchQueue.main.async { self.snapshot = s }
        }
    }

    /// Hand controls (on-screen pad) — merged with any physical controller. Main thread.
    func setVirtualInput(_ pad: GamepadSnapshot) {
        handlerQueue.async {
            self.virtual = pad
            self.emitMergedState()
        }
    }

    /// Must run on `handlerQueue`.
    private func emitMergedState() {
        let merged = GamepadSnapshot.merge(physical: physical, virtual: virtual)
        var state = ControllerMapping.makeState(from: merged, touches: touchTracker)
        if motionEnabled && active != nil {
            chiaki_orientation_tracker_apply_to_controller_state(&orientationTracker, &state)
        }
        onStateChange?(state)
    }

    /// The touchpad reports (0, 0) when no finger is down.
    private static func touchPoint(_ pad: GCControllerDirectionPad) -> SIMD2<Float>? {
        let x = pad.xAxis.value, y = pad.yAxis.value
        if x == 0 && y == 0 { return nil }
        return SIMD2((x + 1) / 2, (1 - y) / 2)
    }

    // MARK: Feedback from the console (light bar and adaptive triggers; no vibration)

    func setLightBar(rgb: UInt32) {
        guard let light = active?.light else { return }
        let r = Float((rgb >> 16) & 0xFF) / 255, g = Float((rgb >> 8) & 0xFF) / 255, b = Float(rgb & 0xFF) / 255
        light.color = GCColor(red: r, green: g, blue: b)
    }

    func applyTriggerEffects(typeLeft: UInt8, left: [UInt8], typeRight: UInt8, right: [UInt8]) {
        guard let dualSense = active?.extendedGamepad as? GCDualSenseGamepad else { return }
        let leftEffect = TriggerEffect.decode(type: typeLeft, data: left)
        let rightEffect = TriggerEffect.decode(type: typeRight, data: right)
        Self.apply(leftEffect, to: dualSense.leftTrigger)
        Self.apply(rightEffect, to: dualSense.rightTrigger)
        let description = "L: \(leftEffect)  R: \(rightEffect)"
        DispatchQueue.main.async { self.lastTriggerEffect = description }
    }

    private static func apply(_ effect: TriggerEffect, to trigger: GCDualSenseAdaptiveTrigger) {
        switch effect {
        case .off, .unsupported:
            trigger.setModeOff()
        case .feedback(let start, let strength):
            trigger.setModeFeedbackWithStartPosition(start, resistiveStrength: strength)
        case .weapon(let start, let end, let strength):
            trigger.setModeWeaponWithStartPosition(start, endPosition: end, resistiveStrength: strength)
        case .vibration(let start, let amplitude, let frequency):
            trigger.setModeVibrationWithStartPosition(start, amplitude: amplitude, frequency: frequency)
        }
    }

    func testTriggerFeedback() {
        guard let dualSense = active?.extendedGamepad as? GCDualSenseGamepad else { return }
        Self.apply(.feedback(start: 0.3, strength: 0.5), to: dualSense.leftTrigger)
        Self.apply(.feedback(start: 0.3, strength: 0.5), to: dualSense.rightTrigger)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in self?.resetFeedback() }
    }

    func resetFeedback() {
        if let dualSense = active?.extendedGamepad as? GCDualSenseGamepad {
            dualSense.leftTrigger.setModeOff()
            dualSense.rightTrigger.setModeOff()
        }
    }
}
