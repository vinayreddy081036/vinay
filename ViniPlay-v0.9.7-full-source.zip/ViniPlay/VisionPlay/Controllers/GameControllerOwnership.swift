import SwiftUI
import GameController

/// Tells visionOS that this view's game controller input belongs to the app (the PS5 game),
/// not to the system. Without it, visionOS 26 uses the DualSense to navigate the interface
/// (X = tap, sticks = scroll, PS = Home) and the game — including vibration — doesn't get it.
/// Earlier visionOS versions don't have the modifier and deliver input as before.
struct GameControllerOwnership: ViewModifier {
    func body(content: Content) -> some View {
        if #available(visionOS 26.0, *) {
            // Events go to the GameController framework (our controller handler, which sends
            // them to the PS5), not to SwiftUI views — same form NVIDIA's CloudXR client uses.
            // No limit: the game gets every controller event (GameController framework) and
            // the app's own screens can be used with the controller as well as with your hands.
            content.handlesGameControllerEvents(matching: [.gamepad], withOptions: .receivesEventsInView(true))
        } else {
            content
        }
    }
}

extension View {
    /// The DualSense plays the game here; it never drives the app's own UI.
    func controllerPlaysTheGame() -> some View { modifier(GameControllerOwnership()) }
}

extension View {
    /// A sheet whose content can't be driven by the controller either (sheets are separate
    /// presentations, so the lock on the window behind them doesn't reach them).
    func lockedSheet<Content: View>(isPresented: Binding<Bool>, @ViewBuilder content: @escaping () -> Content) -> some View {
        sheet(isPresented: isPresented) { content().controllerPlaysTheGame() }
    }

    func lockedSheet<Item: Identifiable, Content: View>(item: Binding<Item?>, @ViewBuilder content: @escaping (Item) -> Content) -> some View {
        sheet(item: item) { content($0).controllerPlaysTheGame() }
    }
}
