import SwiftUI

/// Game profiles: save the current screen/sound/picture settings under a game's name,
/// apply one by hand, or let VisionPlay switch when PSN reports that game is running.
struct ProfilesView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @State private var newName = ""

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack {
                        TextField("Game name, e.g. Gran Turismo 7", text: $newName)
                        Button("Save Current Settings") {
                            let name = newName.trimmingCharacters(in: .whitespacesAndNewlines)
                            guard !name.isEmpty else { return }
                            let profile = model.settings.makeProfile(named: name)
                            model.profiles.save(profile)
                            model.profiles.activeID = profile.id
                            newName = ""
                        }
                        .disabled(newName.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                    if let title = model.currentGameTitle {
                        Button("Use “\(title)” (playing now)") { newName = title }
                    }
                } header: {
                    Text("New Profile")
                } footer: {
                    Text("Saves screen size, distance, shape, sound options, upscaling, clean-up, Low-Latency Mode and Cinema Room.")
                }

                Section("Profiles") {
                    if model.profiles.profiles.isEmpty {
                        Text("No profiles yet.").foregroundStyle(.secondary)
                    }
                    ForEach(model.profiles.profiles) { profile in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(profile.name).font(.headline)
                                Text(summary(profile)).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if model.profiles.activeID == profile.id {
                                Label("Active", systemImage: "checkmark.circle.fill").foregroundStyle(.green)
                            } else {
                                Button("Apply") { model.applyProfile(profile) }
                            }
                            Button("Update") {
                                var updated = model.settings.makeProfile(named: profile.name)
                                updated.id = profile.id
                                model.profiles.save(updated)
                            }
                            Button(role: .destructive) { model.profiles.delete(profile.id) } label: {
                                Image(systemName: "trash")
                            }
                        }
                    }
                }

                Section {
                    LabeledContent("Playing now", value: model.currentGameTitle ?? "Unknown")
                } header: {
                    Text("Automatic Switching")
                } footer: {
                    Text("When you're signed in to PlayStation Network (Internet Play › Sign In), VisionPlay asks PSN once a minute which game you're playing and applies the profile with that name. Sony may not allow this for Remote Play sign-ins; if \"Playing now\" stays Unknown, apply profiles by hand.")
                }
            }
            .navigationTitle("Game Profiles")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
        .frame(minWidth: 700, minHeight: 600)
    }

    private func summary(_ p: GameProfile) -> String {
        let size = ScreenSize.diagonalInches(forWidthMeters: p.screenWidthMeters)
        var parts = [String(format: "%.0f″ at %.1f m", size, p.viewingDistance), p.displayShape.rawValue, p.upscaleMode.rawValue]
        if p.cinemaRoom { parts.append("Cinema") }
        return parts.joined(separator: " · ")
    }
}
