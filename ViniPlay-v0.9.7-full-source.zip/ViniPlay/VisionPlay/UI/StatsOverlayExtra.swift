import SwiftUI

extension StatsOverlay {
    /// Second HUD line block: colour, HDR handling, audio extras.
    static func extraLines(_ stats: StreamStatistics) -> [String] {
        var lines = [stats.quality.summary,
                     "\(stats.lag.summary) (\(stats.lag.breakdown))",
                     "\(stats.render.colorDescription) · \(stats.render.dynamicRange)"]
        lines.append(stats.render.displayRefreshHz > 0
                     ? String(format: "Smooth Motion · display %.0f Hz", stats.render.displayRefreshHz)
                     : "Present on decode")
        lines.append("Sound: \(stats.audio.spatialDescription)")
        if stats.audio.microphoneActive { lines.append("Mic on · \(stats.audio.microphonePacketsSent) packets sent") }
        return lines
    }
}
