import SwiftUI

struct HomeView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismissWindow) private var dismissWindow
    @Environment(\.openWindow) private var openWindow
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace

    @State private var registerTarget: RegisterTarget?
    @State private var showManualAdd = false
    @State private var showSettings = false
    @State private var showControllerTest = false
    @State private var showDiagnostics = false
    @State private var consolePendingRemoval: RegisteredConsole?
    @State private var playbackOpening = false
    @State private var playbackError: String?
    @State private var showProfiles = false

    /// Siri / Shortcuts: "Play PS5" → wake + connect (home or Internet), optionally Theater.
    private func handleLaunchRequest() {
        guard let request = LaunchCoordinator.pending else { return }
        LaunchCoordinator.pending = nil
        if !model.discovery.isRunning {
            model.discovery.start(extraAddresses: model.consoles.consoles.map(\.lastKnownAddress))
        }
        let all = model.consoles.consoles
        guard let console = request.consoleID.flatMap({ id in all.first { $0.id == id } }) ?? all.first else { return }
        model.stream.connectAutomatically(to: console)
    }

    struct RegisterTarget: Identifiable {
        let id = UUID()
        var host: String
        var isPS5: Bool
        var name: String?
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ConnectionBanner()
                }

                Section("Registered Consoles") {
                    if model.consoles.consoles.isEmpty {
                        Text("No consoles registered yet. Use Find PS5 or Manual IP, then Register PS5 with the code from Settings › System › Remote Play › Pair Device on your console.")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(model.consoles.consoles) { console in
                        RegisteredConsoleRow(console: console,
                                             onRemove: { consolePendingRemoval = console })
                    }
                }

                Section {
                    if model.discovery.isRunning && model.unregisteredDiscoveries.isEmpty {
                        HStack(spacing: 12) {
                            ProgressView()
                            Text("Searching \(model.discovery.interfaceDescription)…")
                                .foregroundStyle(.secondary)
                        }
                    }
                    ForEach(model.unregisteredDiscoveries) { found in
                        HStack {
                            Image(systemName: "playstation.logo")
                                .font(.title2)
                            VStack(alignment: .leading) {
                                Text(found.hostName).font(.headline)
                                Text("\(found.isPS5 ? "PS5" : "PS4") · \(found.address) · \(found.state.rawValue)")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button("Register") {
                                registerTarget = RegisterTarget(host: found.address, isPS5: found.isPS5, name: found.hostName)
                            }
                        }
                    }
                    if let error = model.discovery.lastError {
                        Label(error.localizedDescription, systemImage: "exclamationmark.triangle")
                            .foregroundStyle(.orange)
                    }
                } header: {
                    HStack {
                        Text("On This Network")
                        Spacer()
                        if model.discovery.isRunning {
                            Text("\(model.discovery.probesSent) probes").font(.caption2).foregroundStyle(.tertiary)
                        }
                    }
                }

                Section("Status") {
                    HStack {
                        Label("Controller", systemImage: "gamecontroller")
                        Spacer()
                        Text(model.controllers.activeName ?? "Not connected")
                            .foregroundStyle(model.controllers.activeName == nil ? .secondary : .primary)
                    }
                    HStack {
                        Label("Streaming Quality", systemImage: "dial.medium")
                        Spacer()
                        Text("\(model.settings.resolution.label) · \(model.settings.fps) FPS · \(model.settings.codec.label)")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Label("Upscaling", systemImage: "arrow.up.left.and.arrow.down.right")
                        Spacer()
                        Text(model.settings.upscalingEnabled
                             ? "\(model.settings.upscaleMode.rawValue) → \(model.settings.outputTarget.rawValue) · sharpen \(Int((model.settings.sharpening * 100).rounded()))%"
                             : "Off")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("ViniPlay")
            .toolbar {
                ToolbarItemGroup(placement: .bottomOrnament) {
                    Button {
                        model.discovery.isRunning ? model.discovery.stop()
                            : model.discovery.start(extraAddresses: model.consoles.consoles.map(\.lastKnownAddress))
                    } label: {
                        Label(model.discovery.isRunning ? "Stop Search" : "Find PS5",
                              systemImage: model.discovery.isRunning ? "stop.circle" : "dot.radiowaves.left.and.right")
                    }
                    Button { showManualAdd = true } label: { Label("Manual IP Address", systemImage: "network") }
                    Button {
                        registerTarget = RegisterTarget(host: "", isPS5: true, name: nil)
                    } label: { Label("Register PS5", systemImage: "key") }
                    Button { showControllerTest = true } label: { Label("Controller", systemImage: "gamecontroller") }
                    Button { showDiagnostics = true } label: { Label("Diagnostics", systemImage: "waveform.path.ecg") }
                    Button { showProfiles = true } label: { Label("Game Profiles", systemImage: "person.crop.rectangle.stack") }
                    Button { showSettings = true } label: { Label("Settings", systemImage: "gearshape") }
                }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .visionPlayPairAgain)) { _ in
            guard let console = model.stream.needsRepairing else { return }
            model.stream.needsRepairing = nil
            registerTarget = RegisterTarget(host: console.lastKnownAddress, isPS5: console.isPS5, name: console.nickname)
        }
        .lockedSheet(item: $registerTarget) { target in
            RegisterConsoleView(initialHost: target.host, isPS5: target.isPS5, consoleName: target.name)
        }
        .lockedSheet(isPresented: $showManualAdd) {
            ManualAddView { host, isPS5, name in
                showManualAdd = false
                registerTarget = RegisterTarget(host: host, isPS5: isPS5, name: name)
            }
        }
        .alert("Playback Screen", isPresented: Binding(get: { playbackError != nil }, set: { if !$0 { playbackError = nil } })) {
            Button("OK") { playbackError = nil }
        } message: { Text(playbackError ?? "") }
        .lockedSheet(isPresented: $showSettings) { SettingsView() }
        .lockedSheet(isPresented: $showControllerTest) { ControllerTestView() }
        .lockedSheet(isPresented: $showDiagnostics) { DiagnosticsView() }
        .lockedSheet(isPresented: $showProfiles) { ProfilesView() }
        .alert("Remove console?", isPresented: Binding(get: { consolePendingRemoval != nil },
                                                     set: { if !$0 { consolePendingRemoval = nil } })) {
            Button("Remove", role: .destructive) {
                if let console = consolePendingRemoval { model.removeConsole(console) }
                consolePendingRemoval = nil
            }
            Button("Cancel", role: .cancel) { consolePendingRemoval = nil }
        } message: {
            Text("This deletes the saved registration keys from the Keychain. You will need a new pairing code to use this console again.")
        }
        .onReceive(NotificationCenter.default.publisher(for: .visionPlayLaunchRequest)) { _ in handleLaunchRequest() }
        .onAppear {
            // Only step away if a game is really on the screen right now. Never close Home just
            // because a flag says the screen is open: that flag can be stale (the screen closed
            // while the app was in the background), and then the app would open to nothing.
            // A game is on but its window isn't showing (you could hear it but not see it):
            // bring the game window back. Opening it when it's already open just brings it to
            // the front, so this is always safe.
            if model.stream.isActive && !model.customScreenOpen && !model.customScreenOpening {
                openWindow(id: SceneID.playback)
            } else if model.customScreenOpen && model.stream.isActive {
                dismissWindow(id: SceneID.main)
            }
            model.stream.writeDisplayStatus()
            handleLaunchRequest()
            if !model.discovery.isRunning {
                model.discovery.start(extraAddresses: model.consoles.consoles.map(\.lastKnownAddress))
            }
        }
        .onChange(of: model.stream.phase) { _, phase in
            if phase == .streaming { model.startGameDetection() }
            if phase == .disconnected { model.stopGameDetection() }
            switch phase {
            case .connecting, .streaming, .reconnecting:
                // The game opens in the game window (movable, works in Apple's Environments).
                // The Cinema (Custom Screen) is one tap away in its toolbar.
                // Always ask for the game window, even if a flag says it's open: a window that was
                // still closing from the last game left the flag on, so no window opened and you
                // heard the game without seeing it. Asking again only brings it to the front.
                if !model.customScreenOpen && !model.customScreenOpening {
                    openWindow(id: SceneID.playback)
                }
            default: break
            }
        }
    }
}

/// Live connection state (never shows Streaming unless the session reported CONNECTED).
extension Notification.Name {
    static let visionPlayPairAgain = Notification.Name("VisionPlay.pairAgain")
}

struct ConnectionBanner: View {
    @Environment(\.openWindow) private var openWindow
    @Environment(AppModel.self) private var model

    var body: some View {
        let stream = model.stream
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Circle()
                    .fill(color(for: stream.phase))
                    .frame(width: 14, height: 14)
                Text(stream.phase.rawValue)
                    .font(.title3.weight(.semibold))
                if stream.phase == .connecting || stream.phase == .reconnecting || stream.phase == .disconnecting {
                    ProgressView().controlSize(.small)
                }
                Spacer()
                if stream.isActive {
                    // Brings the game window back if you can hear the game but not see it.
                    Button { openWindow(id: SceneID.playback) } label: {
                        Label("Show Game", systemImage: "rectangle.on.rectangle")
                    }
                    .buttonStyle(.borderedProminent)
                    Button("Disconnect", role: .destructive) { stream.disconnect() }
                }
            }
            if !stream.statusDetail.isEmpty {
                Text(stream.statusDetail).foregroundStyle(.secondary)
            }
            if let progress = stream.wakeProgress {
                ProgressView(value: progress) { Text("Waking console") }
                    .progressViewStyle(.linear)
            }
            if let notice = stream.connectionNotice {
                Label(notice, systemImage: "antenna.radiowaves.left.and.right").font(.callout).foregroundStyle(.secondary)
            }
            if !stream.network.isConnected {
                Label("The Vision Pro has no network connection.", systemImage: "wifi.slash").foregroundStyle(.red)
            }
            if let message = stream.lanNotFoundMessage, stream.phase == .disconnected {
                Label(message, systemImage: "wifi.exclamationmark").foregroundStyle(.orange)
            }
            if stream.isActive {
                Label("Route: \(stream.routeDescription)", systemImage: stream.routeDescription.hasPrefix("Internet") ? "globe" : "wifi")
                    .font(.caption).foregroundStyle(.secondary)
            }
            if let error = stream.lastError, stream.phase == .disconnected {
                Label(error.localizedDescription, systemImage: "exclamationmark.triangle.fill")
                    .foregroundStyle(.orange)
            }
            // Live connection stages while connecting, and after a failed start.
            if stream.phase == .connecting || stream.phase == .reconnecting
                || (stream.phase == .disconnected && stream.progress.failedStage != nil) {
                ConnectionStepsView(progress: stream.progress,
                                    onPairAgain: stream.needsRepairing == nil ? nil : {
                                        NotificationCenter.default.post(name: .visionPlayPairAgain, object: nil)
                                    })
                .padding(.top, 6)
            }
        }
        .padding(.vertical, 4)
    }

    private func color(for phase: ConnectionPhase) -> Color {
        switch phase {
        case .streaming: return .green
        case .connecting, .reconnecting, .registering, .discovering: return .yellow
        case .disconnecting: return .orange
        case .disconnected: return .gray
        }
    }
}

struct RegisteredConsoleRow: View {
    @Environment(AppModel.self) private var model
    let console: RegisteredConsole
    let onRemove: () -> Void
    @State private var showInternetPlay = false
    @State private var showConnectionTest = false

    var body: some View {
        let seen = model.discoveryInfo(for: console)
        let isThisConsoleActive = model.stream.connectedConsole?.id == console.id && model.stream.isActive
        HStack(spacing: 16) {
            Image(systemName: "playstation.logo")
                .font(.largeTitle)
            VStack(alignment: .leading, spacing: 4) {
                Text(console.displayName).font(.headline)
                Text("\(console.isPS5 ? "PS5" : "PS4") · \(seen?.address ?? console.lastKnownAddress) · \(console.displayMAC)\(console.psnDeviceID != nil ? " · Internet Play" : "")")
                    .font(.caption).foregroundStyle(.secondary)
                if let seen {
                    Text(seen.state == .ready
                         ? (seen.runningAppName.map { "Ready · \($0)" } ?? "Ready")
                         : seen.state == .standby ? "Rest mode" : "Unknown state")
                        .font(.caption)
                        .foregroundStyle(seen.state == .ready ? .green : .orange)
                } else {
                    Text(console.psnDeviceID != nil ? "Not on this network · Connect will use the internet" : "Not seen on this network yet")
                        .font(.caption).foregroundStyle(.tertiary)
                }
            }
            Spacer()
            if seen?.state == .standby {
                Button("Wake") { model.wake(console) }
            }
            if isThisConsoleActive {
                Button("Disconnect", role: .destructive) { model.stream.disconnect() }
            } else {
                Button("Connect") { model.stream.connectAutomatically(to: console) }
                    .buttonStyle(.borderedProminent)
                    .disabled(model.stream.isActive)
            }
            Menu {
                Button { model.stream.connect(to: console) } label: {
                    Label("Connect on Home Network Only", systemImage: "wifi")
                }
                .disabled(model.stream.isActive)
                if console.psnDeviceID != nil {
                    Button { model.stream.connectOverInternet(to: console) } label: {
                        Label("Connect over the Internet", systemImage: "globe")
                    }
                    .disabled(model.stream.isActive)
                }
                Button { showConnectionTest = true } label: { Label("Test Connection…", systemImage: "speedometer") }
                Button { showInternetPlay = true } label: { Label("Internet Play…", systemImage: "network") }
                Divider()
                Button("Remove Registered Console", role: .destructive, action: onRemove)
            } label: {
                Image(systemName: "ellipsis.circle")
            }
        }
        .padding(.vertical, 6)
        .lockedSheet(isPresented: $showInternetPlay) { InternetPlayView(console: console) }
        .lockedSheet(isPresented: $showConnectionTest) { ConnectionTestView(console: console) }
    }
}
