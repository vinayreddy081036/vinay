import SwiftUI

/// A console on the user's PSN account (from Sony's device list).
struct PSNDevice: Identifiable, Equatable, Sendable {
    var id: String { deviceID }
    var name: String
    var deviceID: String       // 64 hex characters
    var remotePlayEnabled: Bool
    var isPS5: Bool

    /// Lists consoles registered to the signed-in PSN account. Runs the blocking C call off the main thread.
    static func list(accessToken: String, ps5: Bool) async throws -> [PSNDevice] {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                var buffer = [VPRemoteDevice](repeating: VPRemoteDevice(), count: 16)
                var count = 0
                let err = accessToken.withCString { token in
                    buffer.withUnsafeMutableBufferPointer { vp_psn_list_devices(token, ps5, $0.baseAddress, $0.count, &count) }
                }
                guard err == CHIAKI_ERR_SUCCESS else {
                    continuation.resume(throwing: ConnectionError.network("PSN device list failed (\(ChiakiRuntime.describe(err)))"))
                    return
                }
                let devices = buffer.prefix(count).map { raw -> PSNDevice in
                    var device = raw
                    let name = withUnsafeBytes(of: &device.name) { String(decoding: $0.prefix { $0 != 0 }, as: UTF8.self) }
                    let duid = withUnsafeBytes(of: &device.duid_hex) { String(decoding: $0.prefix { $0 != 0 }, as: UTF8.self) }
                    return PSNDevice(name: name, deviceID: duid, remotePlayEnabled: device.remoteplay_enabled, isPS5: device.ps5)
                }
                continuation.resume(returning: devices)
            }
        }
    }
}

/// Links a registered console to its PSN device so it can be streamed over the internet.
struct InternetPlayView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    let console: RegisteredConsole

    @State private var signedIn = PSNTokenStore.shared.hasRefreshToken
    @State private var showLogin = false
    @State private var loading = false
    @State private var devices: [PSNDevice] = []
    @State private var message: String?
    @State private var showSignInInfo = false

    private var linkedID: String? { model.consoles.console(id: console.id)?.psnDeviceID }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Internet Play connects to \(console.nickname) when you're away from home, through PlayStation Network. On the PS5, enable Settings › System › Power Saving › Features Available in Rest Mode › Stay Connected to the Internet and Enable Turning On PS5 from Network.")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }

                Section("PlayStation Network") {
                    if signedIn {
                        Label("Signed in", systemImage: "checkmark.seal.fill").foregroundStyle(.green)
                        Button("Find My Consoles") { Task { await loadDevices() } }
                            .disabled(loading)
                        Button("Sign Out of PSN", role: .destructive) {
                            Task {
                                try? await PSNTokenStore.shared.signOut()
                                signedIn = false
                                devices = []
                            }
                        }
                    } else {
                        Button {
                            showLogin = true
                        } label: {
                            Label("Sign in to PlayStation Network (headset, QR code or code)", systemImage: "person.badge.key")
                        }
                    }
                    Button { showSignInInfo = true } label: { Label("How sign-in works", systemImage: "info.circle") }
                }

                if loading {
                    Section { HStack { ProgressView(); Text("Asking PSN for your consoles…") } }
                }

                if !devices.isEmpty {
                    Section("Consoles on Your Account") {
                        ForEach(devices) { device in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(device.name).font(.headline)
                                    Text("\(device.isPS5 ? "PS5" : "PS4") · Remote Play \(device.remotePlayEnabled ? "on" : "off")")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                if linkedID?.caseInsensitiveCompare(device.deviceID) == .orderedSame {
                                    Label("Linked", systemImage: "link").foregroundStyle(.green)
                                } else {
                                    Button("Link to \(console.nickname)") {
                                        model.consoles.setPSNDevice(consoleID: console.id, deviceID: device.deviceID)
                                        message = "Linked. Use Connect › Over the Internet."
                                    }
                                }
                            }
                        }
                    }
                }

                Section {
                    @Bindable var settings = model.settings
                    Toggle("Use Fixed Ports", isOn: $settings.internetFixedPorts)
                    if settings.internetFixedPorts {
                        Stepper("Control port: \(settings.internetControlPort)", value: $settings.internetControlPort, in: 1024...65534)
                        Stepper("Data port: \(settings.internetDataPort)", value: $settings.internetDataPort, in: 1024...65535)
                        Text("In your home router, forward UDP ports \(settings.internetControlPort) and \(settings.internetDataPort) to this Vision Pro (\(IPv4Interface.current().first?.addressString ?? "its IP address")). Only needed for the network the Vision Pro is on when you're away — e.g. your own second home; skip it if Internet Play already works.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                } header: {
                    Text("Router Port Forwarding (optional)")
                } footer: {
                    Text("visionOS doesn't allow the automatic router setup (UPnP) that helps internet connections through strict routers. Fixed, forwarded ports are the manual equivalent.")
                }

                if linkedID != nil {
                    Section {
                        Button("Unlink", role: .destructive) {
                            model.consoles.setPSNDevice(consoleID: console.id, deviceID: nil)
                        }
                    }
                }

                if let message {
                    Section { Text(message).font(.callout) }
                }
            }
            .navigationTitle("Internet Play")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
        .frame(minWidth: 620, minHeight: 640)
        .lockedSheet(isPresented: $showSignInInfo) { SignInInfoView() }
        .lockedSheet(isPresented: $showLogin) {
            PSNLoginView { result in
                showLogin = false
                switch result {
                case .success:
                    signedIn = true
                    Task { await loadDevices() }
                case .failure(let error):
                    message = "Sign-in failed: \(error.localizedDescription)"
                }
            }
        }
        .task { if signedIn && devices.isEmpty { await loadDevices() } }
    }

    private func loadDevices() async {
        loading = true
        defer { loading = false }
        do {
            let token = try await PSNTokenStore.shared.accessToken()
            devices = try await PSNDevice.list(accessToken: token, ps5: console.isPS5)
            message = devices.isEmpty ? "No consoles with Remote Play were found on this PSN account." : nil
        } catch {
            message = error.localizedDescription
        }
    }
}
