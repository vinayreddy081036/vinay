import SwiftUI

/// Diagnostics › Error Codes: every code VisionPlay can show, with what it means and the fix.
struct ErrorCodesView: View {
    @State private var search = ""

    private var codes: [VPErrorCode] {
        let q = search.trimmingCharacters(in: .whitespaces).lowercased()
        guard !q.isEmpty else { return VPErrorCode.all }
        return VPErrorCode.all.filter {
            $0.code.lowercased().contains(q) || $0.title.lowercased().contains(q) || $0.fix.lowercased().contains(q)
        }
    }

    var body: some View {
        List(codes) { code in
            VStack(alignment: .leading, spacing: 4) {
                Text(code.code).font(.headline.monospaced())
                Text(code.title).font(.subheadline.weight(.semibold))
                Text(code.fix).font(.callout).foregroundStyle(.secondary)
            }
            .padding(.vertical, 4)
            .textSelection(.enabled)
        }
        .searchable(text: $search, prompt: "Code or words, e.g. 110")
        .navigationTitle("Error Codes")
    }
}
