import SwiftUI

/// On-screen controls you use with eye-look + pinch, for moments the DualSense isn't in
/// reach (or for the touchpad, which is awkward to hit while wearing the headset).
///
/// - Touchpad: look at the pad and pinch-drag to swipe; a quick pinch clicks it.
/// - PS, Create, Options and the D-pad / face buttons press while pinched.
/// Everything is merged with a connected physical controller, so both work at once.
struct HandControlsView: View {
    let controllers: ControllerManager
    @State private var pad = GamepadSnapshot()
    @State private var dragStart: Date?
    /// True only while the touchpad pinch is held; resets by itself if the pinch is lost.
    @GestureState private var touching = false

    var body: some View {
        VStack(spacing: 14) {
            HStack(spacing: 10) {
                hold("Create", systemImage: "square.and.arrow.up", \.create)
                touchpad
                hold("Options", systemImage: "line.3.horizontal", \.options)
            }
            HStack(spacing: 24) {
                dpad
                hold("PS", systemImage: "playstation.logo", \.ps)
                    .font(.title3)
                faceButtons
            }
        }
        .padding(16)
        .glassBackgroundEffect()
        .onDisappear {
            pad = GamepadSnapshot()
            controllers.setVirtualInput(pad)
        }
    }

    // MARK: Touchpad

    private var touchpad: some View {
        GeometryReader { geo in
            RoundedRectangle(cornerRadius: 14)
                .fill(.white.opacity(pad.touch0 == nil ? 0.08 : 0.2))
                .overlay {
                    Text("Touchpad").font(.caption).foregroundStyle(.secondary)
                }
                .contentShape(.hoverEffect, RoundedRectangle(cornerRadius: 14))
                .hoverEffect()
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .updating($touching) { _, state, _ in state = true }
                        .onChanged { value in
                            if dragStart == nil { dragStart = Date() }
                            let x = Float(min(max(value.location.x / geo.size.width, 0), 1))
                            let y = Float(min(max(value.location.y / geo.size.height, 0), 1))
                            update { $0.touch0 = SIMD2(x, y) }
                        }
                        .onEnded { value in
                            let quick = Date().timeIntervalSince(dragStart ?? Date()) < 0.25
                            let still = hypot(value.translation.width, value.translation.height) < 8
                            dragStart = nil
                            update { $0.touch0 = nil }
                            if quick && still { tap(\.touchpadButton) }
                        }
                )
        }
        .frame(width: 260, height: 120)
        // Pinch lost or cancelled (no onEnded): lift the finger off the touchpad anyway.
        .onChange(of: touching) { _, isTouching in
            if !isTouching && pad.touch0 != nil {
                dragStart = nil
                update { $0.touch0 = nil }
            }
        }
        .accessibilityLabel("Touchpad")
    }

    // MARK: Buttons

    private var dpad: some View {
        Grid(horizontalSpacing: 4, verticalSpacing: 4) {
            GridRow { Color.clear.frame(width: 40, height: 40); hold("", systemImage: "arrowtriangle.up.fill", \.dpadUp); Color.clear.frame(width: 40, height: 40) }
            GridRow { hold("", systemImage: "arrowtriangle.left.fill", \.dpadLeft); Color.clear.frame(width: 40, height: 40); hold("", systemImage: "arrowtriangle.right.fill", \.dpadRight) }
            GridRow { Color.clear.frame(width: 40, height: 40); hold("", systemImage: "arrowtriangle.down.fill", \.dpadDown); Color.clear.frame(width: 40, height: 40) }
        }
    }

    private var faceButtons: some View {
        Grid(horizontalSpacing: 4, verticalSpacing: 4) {
            GridRow { Color.clear.frame(width: 40, height: 40); hold("", systemImage: "triangle", \.triangle); Color.clear.frame(width: 40, height: 40) }
            GridRow { hold("", systemImage: "square", \.square); Color.clear.frame(width: 40, height: 40); hold("", systemImage: "circle", \.circle) }
            GridRow { Color.clear.frame(width: 40, height: 40); hold("", systemImage: "xmark", \.cross); Color.clear.frame(width: 40, height: 40) }
        }
    }

    /// A button that stays pressed for as long as the pinch is held — and is always released,
    /// even when visionOS loses or cancels the pinch.
    private func hold(_ title: String, systemImage: String, _ key: WritableKeyPath<GamepadSnapshot, Bool>) -> some View {
        HoldButton(title: title, systemImage: systemImage, pressed: pad[keyPath: key]) { down in
            if pad[keyPath: key] != down { update { $0[keyPath: key] = down } }
        }
        .accessibilityAction { tap(key) }
    }

    private func tap(_ key: WritableKeyPath<GamepadSnapshot, Bool>) {
        update { $0[keyPath: key] = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
            update { $0[keyPath: key] = false }
        }
    }

    private func update(_ change: (inout GamepadSnapshot) -> Void) {
        change(&pad)
        controllers.setVirtualInput(pad)
    }
}

/// One hold-to-press button. Its own @GestureState means the press ends whenever the gesture
/// ends for any reason, so a lost pinch can never leave a PS5 button held down.
private struct HoldButton: View {
    let title: String
    let systemImage: String
    let pressed: Bool
    let onPress: (Bool) -> Void
    @GestureState private var holding = false

    var body: some View {
        Group {
            if title.isEmpty {
                Image(systemName: systemImage).frame(width: 40, height: 40)
            } else {
                Label(title, systemImage: systemImage).labelStyle(.iconOnly).frame(width: 56, height: 56)
            }
        }
        .background(Circle().fill(.white.opacity(pressed ? 0.35 : 0.1)))
        .contentShape(.hoverEffect, Circle())
        .hoverEffect()
        .gesture(DragGesture(minimumDistance: 0).updating($holding) { _, state, _ in state = true })
        .onChange(of: holding) { _, isHolding in onPress(isHolding) }
        .onDisappear { if pressed { onPress(false) } }
        .accessibilityLabel(title.isEmpty ? systemImage : title)
        .accessibilityAddTraits(.isButton)
    }
}
