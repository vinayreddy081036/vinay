import SwiftUI
import WebKit
import CoreImage
import CoreImage.CIFilterBuiltins

/// PlayStation Network sign-in, made simple:
///  • **Sign in with PlayStation** (the big button) — Sony's own sign-in page right here; the
///    code is picked up automatically, nothing to copy or paste. Saved passwords and passkeys
///    from your Apple Account fill in as usual.
///  • **Use my phone** — scan a QR code, sign in on your phone, paste the final address back
///    (Universal Clipboard brings it over).
///  • **Enter a code** — sign in from any browser and paste the code.
/// Every step is shown live in "How sign-in works".
struct PSNLoginView: View {
    let completion: (Result<PSNAccountService.LoginResult, Error>) -> Void

    enum Method: String, CaseIterable, Identifiable {
        case headset = "Sign in here"
        case qr = "Use my phone"
        case code = "Enter a code"
        var id: String { rawValue }
    }

    /// nil = the start screen.
    @State private var method: Method?
    @State private var working = false
    @State private var pasted = ""
    @State private var inputError: String?
    @State private var showHowItWorks = false
    /// Bumped to reload Sony's page after a failed sign-in.
    @State private var webAttempt = 0
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if let method {
                    VStack(spacing: 16) {
                        ZStack {
                            switch method {
                            case .headset:
                                PSNWebView { code in submit(code: code) }
                                    .id(webAttempt)
                                    .clipShape(RoundedRectangle(cornerRadius: 16))
                            case .qr:
                                QRSignInPanel(pasted: $pasted, inputError: inputError, onSubmit: submitPasted)
                            case .code:
                                CodeSignInPanel(pasted: $pasted, inputError: inputError, onSubmit: submitPasted)
                            }
                            if working {
                                ProgressView("Signing in…")
                                    .padding(30)
                                    .glassBackgroundEffect()
                            }
                        }
                        if method == .headset, let inputError {
                            HStack {
                                Text(inputError).font(.callout).foregroundStyle(.orange)
                                Spacer()
                                Button("Try Again") { self.inputError = nil; webAttempt += 1 }
                            }
                        }
                        DisclosureGroup("How sign-in works", isExpanded: $showHowItWorks) {
                            SignInExplanation()
                        }
                    }
                    .padding([.horizontal, .bottom])
                } else {
                    SignInStart { chosen in inputError = nil; method = chosen }
                }
            }
            .navigationTitle(method == nil ? "" : "Sign in with PlayStation")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    if method != nil {
                        Button { method = nil; inputError = nil } label: { Label("Back", systemImage: "chevron.left") }
                    } else {
                        Button("Cancel") { dismiss() }
                    }
                }
            }
        }
        .frame(minWidth: method == nil ? 560 : 760, minHeight: method == nil ? 640 : 900)
        .animation(.easeInOut(duration: 0.2), value: method)
        .onAppear {
            PSNSignInTrace.shared.clear()
            PSNSignInTrace.log(.info, "Sign-in started", "nothing is sent until you sign in on Sony's page")
        }
    }

    private func submitPasted() {
        guard let code = PSNAccountService.extractCode(from: pasted) else {
            inputError = "That doesn't contain a sign-in code. Paste the whole address that starts with https://remoteplay.dl.playstation.net/remoteplay/redirect?code=…"
            return
        }
        inputError = nil
        submit(code: code)
    }

    private func submit(code: String) {
        guard !working else { return }
        working = true
        Task {
            do {
                let result = try await PSNAccountService.completeLogin(code: code)
                try? await PSNTokenStore.shared.save(result.tokens)
                await MainActor.run {
                    working = false
                    completion(.success(result))
                }
            } catch {
                await MainActor.run {
                    working = false
                    if method == .headset {
                        inputError = "Sign-in didn't finish: \(error.localizedDescription)"
                    } else {
                        inputError = "Sign-in failed: \(error.localizedDescription). Codes work only once and expire after a few minutes — scan the QR code again for a fresh one."
                    }
                }
            }
        }
    }
}

// MARK: - Start screen

/// One big button for the usual case; the phone and code options sit underneath.
private struct SignInStart: View {
    let choose: (PSNLoginView.Method) -> Void

    var body: some View {
        VStack(spacing: 22) {
            Spacer(minLength: 10)
            Image(systemName: "playstation.logo")
                .font(.system(size: 64))
                .foregroundStyle(.blue)
            Text("Add PlayStation Account").font(.largeTitle.bold())
            Text("Sign in once. ViniPlay keeps you signed in, so you won't need to do this again.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .frame(maxWidth: 420)

            Button { choose(.headset) } label: {
                Label("Sign in with PlayStation", systemImage: "person.crop.circle.badge.checkmark")
                    .font(.title3.weight(.semibold))
                    .frame(maxWidth: 380)
                    .padding(.vertical, 8)
            }
            .buttonStyle(.borderedProminent)
            .tint(.blue)
            Text("Sony's own page, right here. Saved passwords and passkeys fill in. Nothing to copy or paste.")
                .font(.caption).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .frame(maxWidth: 400)

            HStack(spacing: 14) {
                Button { choose(.qr) } label: { Label("Use My Phone", systemImage: "qrcode.viewfinder") }
                Button { choose(.code) } label: { Label("Enter a Code", systemImage: "keyboard") }
            }
            .buttonStyle(.bordered)
            Spacer(minLength: 10)
        }
        .padding(30)
    }
}

// MARK: - QR code

private struct QRSignInPanel: View {
    @Binding var pasted: String
    let inputError: String?
    let onSubmit: () -> Void

    var body: some View {
        ScrollView {
            HStack(alignment: .top, spacing: 28) {
                VStack {
                    if let image = QRCode.image(for: PSNAccountService.loginURL.absoluteString) {
                        Image(decorative: image, scale: 1)
                            .interpolation(.none)
                            .resizable()
                            .frame(width: 280, height: 280)
                            .padding(14)
                            .background(.white, in: RoundedRectangle(cornerRadius: 14))
                    }
                    Text("Sony's official sign-in page").font(.caption).foregroundStyle(.secondary)
                }
                VStack(alignment: .leading, spacing: 12) {
                    Label("Scan with your iPhone camera and sign in to PlayStation Network.", systemImage: "1.circle.fill")
                    Label("Sony then opens a mostly blank page. Copy its address: tap the address bar, then Copy (in Safari, touch and hold the address bar).", systemImage: "2.circle.fill")
                    Label("Paste it here. With the same Apple Account on both devices, Universal Clipboard brings it over automatically.", systemImage: "3.circle.fill")
                    PasteRow(pasted: $pasted, onSubmit: onSubmit)
                    if let inputError { Text(inputError).font(.callout).foregroundStyle(.orange) }
                    Text("The address contains a one-time code that only works for a few minutes. Your password stays on your phone.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(24)
        }
        .glassBackgroundEffect(in: RoundedRectangle(cornerRadius: 16))
    }
}

// MARK: - Code

private struct CodeSignInPanel: View {
    @Binding var pasted: String
    let inputError: String?
    let onSubmit: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("Sign in from any browser (phone, Mac or PC):").font(.headline)
                Label("Open the sign-in link below (tap Share to send it to another device), and sign in to PlayStation Network.", systemImage: "1.circle.fill")
                ShareLink(item: PSNAccountService.loginURL) {
                    Label("Share Sony sign-in link", systemImage: "square.and.arrow.up")
                }
                Label("When sign-in finishes, copy the code from the end of the page's address (the part after code=), or copy the whole address.", systemImage: "2.circle.fill")
                Label("Paste or type it here and tap Sign In.", systemImage: "3.circle.fill")
                PasteRow(pasted: $pasted, onSubmit: onSubmit)
                if let inputError { Text(inputError).font(.callout).foregroundStyle(.orange) }
                Divider()
                Text("Already have your PSN account ID (for example from chiaki-ng)? Close this and type it into the Account ID field instead. That's enough for registering on your home network; Internet Play needs a sign-in here.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(24)
        }
        .glassBackgroundEffect(in: RoundedRectangle(cornerRadius: 16))
    }
}

private struct PasteRow: View {
    @Binding var pasted: String
    let onSubmit: () -> Void

    var body: some View {
        HStack {
            TextField("Address or code", text: $pasted, axis: .vertical)
                .lineLimit(1...3)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .font(.body.monospaced())
                .onSubmit(onSubmit)
            PasteButton(payloadType: String.self) { strings in
                if let first = strings.first {
                    pasted = first
                    onSubmit()
                }
            }
            .labelStyle(.iconOnly)
            Button("Sign In", action: onSubmit)
                .buttonStyle(.borderedProminent)
                .disabled(pasted.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
    }
}

/// QR code rendering with Core Image (no network involved).
enum QRCode {
    static func image(for text: String, scale: CGFloat = 8) -> CGImage? {
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(text.utf8)
        filter.correctionLevel = "M"
        guard let output = filter.outputImage?.transformed(by: CGAffineTransform(scaleX: scale, y: scale)) else { return nil }
        return CIContext().createCGImage(output, from: output.extent)
    }
}

// MARK: - How it works

/// Plain-language explanation plus the live step log.
struct SignInExplanation: View {
    var showsLog = true

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Group {
                Text("1. You sign in on **Sony's own page** (auth.api.sonyentertainmentnetwork.com). VisionPlay never sees or stores your email or password.")
                Text("2. Sony sends the browser to remoteplay.dl.playstation.net with a **one-time code** that expires within minutes.")
                Text("3. VisionPlay exchanges the code with Sony for an **access token** (about an hour) and a **refresh token**, using the same public Remote Play app identity that chiaki-ng uses.")
                Text("4. It reads your **PSN account number**. The PS5 needs it (as an 8-byte \"account ID\") to pair and to know which user is playing.")
                Text("5. Stored on this Vision Pro only, in the **Keychain**: the account ID and the refresh token (for Internet Play). Nothing is sent anywhere else.")
                Text("6. For Internet Play, the refresh token gets a fresh access token, used to ask PSN for your consoles and to set up the connection. **Sign Out** deletes it.")
            }
            .font(.callout)
            .fixedSize(horizontal: false, vertical: true)

            if showsLog {
                SignInLog()
            }
        }
        .padding(.top, 6)
    }
}

struct SignInLog: View {
    private var trace: PSNSignInTrace { PSNSignInTrace.shared }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("What happened (this session)").font(.headline).padding(.top, 6)
            if trace.steps.isEmpty {
                Text("No sign-in activity yet.").font(.caption).foregroundStyle(.secondary)
            }
            ForEach(trace.steps) { step in
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(step.status.rawValue)
                        .foregroundStyle(step.status == .failed ? .red : step.status == .done ? .green : .secondary)
                        .frame(width: 16)
                    VStack(alignment: .leading, spacing: 1) {
                        Text("\(step.date.formatted(date: .omitted, time: .standard))  \(step.title)").font(.caption)
                        if !step.detail.isEmpty {
                            Text(step.detail).font(.caption2.monospaced()).foregroundStyle(.secondary).textSelection(.enabled)
                        }
                    }
                }
            }
        }
    }
}

/// Standalone "How VisionPlay signs in to PlayStation" screen (from Diagnostics / Internet Play).
struct SignInInfoView: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                SignInExplanation().padding(24)
            }
            .navigationTitle("How Sign-In Works")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
        .frame(minWidth: 640, minHeight: 640)
    }
}

// MARK: - Embedded browser

private struct PSNWebView: UIViewRepresentable {
    let onCode: (String) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onCode: onCode) }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        // Default store: Sony remembers this device (fewer verification codes next time) and
        // password / passkey AutoFill works. Cookies stay inside ViniPlay.
        configuration.websiteDataStore = .default()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        PSNSignInTrace.log(.running, "Opening Sony's sign-in page", "auth.api.sonyentertainmentnetwork.com (Sony may remember this device)")
        webView.load(URLRequest(url: PSNAccountService.loginURL))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        let onCode: (String) -> Void
        private var delivered = false
        init(onCode: @escaping (String) -> Void) { self.onCode = onCode }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let url = navigationAction.request.url, let code = PSNAccountService.authorizationCode(fromRedirect: url) {
                decisionHandler(.cancel)
                if !delivered {
                    delivered = true
                    onCode(code)
                }
                return
            }
            decisionHandler(.allow)
        }
    }
}
