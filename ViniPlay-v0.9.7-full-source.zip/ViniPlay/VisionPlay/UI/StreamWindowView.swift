import SwiftUI
import UIKit

/// Screenshot + "save last 30 s" buttons (also: hold Create and press Options on the controller).
struct CaptureButtons: View {
    let stream: StreamCoordinator
    let instantReplay: Bool

    var body: some View {
        Button { stream.saveScreenshot() } label: { Label("Screenshot", systemImage: "camera") }
            .disabled(stream.phase != .streaming)
        if instantReplay {
            Button { stream.saveClip() } label: {
                Label(stream.savingClip ? "Saving…" : "Save 30 s", systemImage: "record.circle")
            }
            .disabled(stream.phase != .streaming || stream.savingClip)
            .help("Saves the last 30 seconds to Photos (or hold Create + press Options)")
        }
    }
}

struct StatsOverlay: View {
    let stats: StreamStatistics
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("\(stats.streamWidth)×\(stats.streamHeight) \(stats.codec) → \(stats.render.outputWidth)×\(stats.render.outputHeight)")
            Text(String(format: "Net %.1f fps · Out %.1f fps · RTT %.0f ms · Loss %.1f%%",
                        stats.networkFPS, stats.render.presentedFPS, stats.rttMilliseconds, stats.packetLossPercent))
            Text(String(format: "Decode %.1f ms · GPU %.2f ms · Decode→display %.1f ms",
                        stats.decoder.averageDecodeMilliseconds, stats.render.gpuMillisecondsAverage,
                        stats.render.pipelineLatencyMilliseconds))
            Text(stats.render.neuralStatus)
            if !stats.render.frameGenStatus.isEmpty { Text(stats.render.frameGenStatus) }
            Text("\(stats.render.technique.rawValue) · audio \(Int(stats.audio.bufferedMilliseconds)) ms")
            ForEach(Self.extraLines(stats), id: \.self) { Text($0) }
        }
        .font(.caption.monospacedDigit())
        .padding(12)
        .background(.black.opacity(0.55), in: RoundedRectangle(cornerRadius: 12))
    }
}
