import SwiftUI

/// Manual IP fallback for networks where the subnet sweep does not find the console.
struct ManualAddView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    let onRegister: (_ host: String, _ isPS5: Bool, _ name: String?) -> Void

    @State private var address = ""
    @State private var probing = false
    @State private var probeStarted: Date?
    @State private var isPS5 = true

    private var found: DiscoveredConsole? {
        model.discovery.consoles.first { $0.address == address.trimmingCharacters(in: .whitespaces) }
    }

    private var addressIsValid: Bool {
        if case .success = RegistrationService.validateHost(address) { return true }
        return false
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("192.168.1.20", text: $address)
                        .keyboardType(.numbersAndPunctuation)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button("Check Address") {
                        probing = true
                        probeStarted = Date()
                        model.discovery.probe(address: address.trimmingCharacters(in: .whitespaces))
                    }
                    .disabled(!addressIsValid)
                } header: {
                    Text("Manual IP Address")
                } footer: {
                    Text("Find the address on the PS5 under Settings › Network › Connection Status › View Connection Status. A fixed (reserved) address in your router is recommended.")
                }

                if probing {
                    Section("Result") {
                        if let found {
                            Label("\(found.hostName) — \(found.isPS5 ? "PS5" : "PS4"), \(found.state.rawValue)",
                                  systemImage: "checkmark.circle.fill")
                                .foregroundStyle(.green)
                            Button("Register This Console") { onRegister(found.address, found.isPS5, found.hostName) }
                                .buttonStyle(.borderedProminent)
                        } else {
                            TimelineView(.periodic(from: .now, by: 1)) { context in
                                let waited = context.date.timeIntervalSince(probeStarted ?? context.date)
                                if waited < 6 {
                                    HStack { ProgressView(); Text("Waiting for a reply…") }
                                } else {
                                    VStack(alignment: .leading, spacing: 8) {
                                        Label("No discovery reply from \(address).", systemImage: "questionmark.circle")
                                            .foregroundStyle(.orange)
                                        Text("The console may be off, on another subnet, or blocking discovery. You can still try to register it directly.")
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                }
                            }
                            Toggle("PlayStation 5", isOn: $isPS5)
                            Button("Register Anyway") { onRegister(address.trimmingCharacters(in: .whitespaces), isPS5, nil) }
                        }
                    }
                }
            }
            .navigationTitle("Add Console")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } }
            }
        }
        .frame(minWidth: 560, minHeight: 520)
    }
}
