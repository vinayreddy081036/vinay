import SwiftUI

/// Screen size presets (55″ … 205″, IMAX) plus a free viewing distance.
struct ScreenSizeControls: View {
    @Bindable var settings: AppSettings
    var compact = false

    private var presets: [ScreenSize] { ScreenSize.allCases }

    var body: some View {
        let current = settings.screenSize
        VStack(alignment: .leading, spacing: compact ? 6 : 10) {
            Text("Screen Size").font(.headline)
            if compact {
                Picker("Screen Size", selection: $settings.screenSize) {
                    ForEach(presets) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.menu)
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 92), spacing: 8)], spacing: 8) {
                    ForEach(presets) { size in
                        Button {
                            settings.screenSize = size
                        } label: {
                            VStack(spacing: 2) {
                                Text(size.rawValue).font(.headline)
                                Text(size.widthMeters.map { String(format: "%.1f m wide", $0) } ?? "Your own size").font(.caption2).foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 6)
                        }
                        .buttonStyle(.bordered)
                        .tint(size == current ? Color.accentColor : nil)
                    }
                }
            }
            Text("Custom Screen").font(.headline)
            ScreenBarsView(showPreview: true)
            Text("Size is the screen's real width and stays as you set it. Distance moves that same screen back (up to 10 km), so it looks smaller the farther it goes, like a cinema. A big screen is never placed so close that it reaches your face. The drawing shows changes as you drag; with Custom Screen open, a glowing outline shows the new spot and the picture glides there when you let go.")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
}
