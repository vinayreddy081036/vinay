import SwiftUI
import UIKit

struct DiagnosticsView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @State private var showDebug = false
    @State private var showSignInInfo = false

    var body: some View {
        let stats = model.stream.statistics
        let log = DiagnosticsLog.shared
        NavigationStack {
            Form {
                Section("Connection") {
                    row("State", model.stream.phase.rawValue)
                    if let error = model.stream.lastError {
                        row("Last error", error.code.label)
                    }
                    NavigationLink("Error Codes") { ErrorCodesView() }
                    row("Route", model.stream.routeDescription)
                    row("Vision Pro network", "\(model.stream.network.interfaceName) \(model.stream.network.localAddress ?? "")")
                    row("Network changes seen", "\(model.stream.network.changeCount)")
                    row("Adaptive quality", model.settings.adaptiveQuality ? model.stream.qualityStepLabel : "Off")
                    row("Console", model.stream.connectedConsole.map { "\($0.nickname) (\($0.lastKnownAddress))" } ?? "—")
                    row("Round-trip time", stats.rttMilliseconds > 0 ? String(format: "%.1f ms", stats.rttMilliseconds) : "—")
                    row("Packet loss", String(format: "%.2f %%", stats.packetLossPercent))
                    row("Reconnect attempts", "\(stats.reconnectAttempts)")
                    row("Discovery interfaces", model.discovery.interfaceDescription)
                    row("PSN (Internet Play)", PSNTokenStore.shared.hasRefreshToken ? "Signed in" : "Not signed in")
                    Button { showSignInInfo = true } label: { Label("How VisionPlay signs in to PlayStation", systemImage: "info.circle") }
                }
                Section("Video") {
                    row("Stream", stats.streamWidth > 0 ? "\(stats.streamWidth)×\(stats.streamHeight) \(stats.codec) @ \(stats.bitrateKbps) kbps" : "—")
                    row("Network frame rate", String(format: "%.1f FPS (jitter %.1f ms)", stats.networkFPS, stats.jitterMilliseconds))
                    row("Frames lost / late", "\(stats.framesLost) / \(stats.lateFrames)")
                    row("Decoded", "\(stats.decoder.decoded) of \(stats.decoder.submitted) (failed \(stats.decoder.failed), waiting for keyframe \(stats.decoder.droppedWaitingForKeyframe))")
                    row("Decode time", String(format: "%.2f ms avg", stats.decoder.averageDecodeMilliseconds))
                    row("Decoded size", stats.decoder.width > 0 ? "\(stats.decoder.width)×\(stats.decoder.height)" : "—")
                }
                Section("Rendering") {
                    row("Actual output", stats.render.outputWidth > 0 ? "\(stats.render.outputWidth)×\(stats.render.outputHeight)" : "—")
                    row("Scaling technique", stats.render.technique.rawValue)
                    row("Colour", stats.render.colorDescription)
                    row("Dynamic range", stats.render.dynamicRange)
                    row("MetalFX Spatial", stats.render.metalFXAvailable ? "Available" : "Unavailable")
                    row("Presented", String(format: "%.1f FPS", stats.render.presentedFPS))
                    row("GPU time", String(format: "%.2f ms (avg %.2f ms)", stats.render.gpuMilliseconds, stats.render.gpuMillisecondsAverage))
                    row("Decode→display latency", String(format: "%.1f ms", stats.render.pipelineLatencyMilliseconds))
                    row("Picture quality", stats.quality.summary.replacingOccurrences(of: "Picture: ", with: ""))
                    if !stats.quality.advice.isEmpty { Text(stats.quality.advice).font(.caption).foregroundStyle(.secondary) }
                    row("Estimated press-to-picture lag", String(format: "%.0f ms", stats.lag.totalMs))
                    row("Lag breakdown", stats.lag.breakdown)
                    row("Frames rendered / replaced", "\(stats.render.framesRendered) / \(stats.render.framesDropped)")
                    if let error = model.stream.rendererError { row("Renderer error", error) }
                }
                Section("Audio") {
                    row("Format", stats.audio.sampleRate > 0 ? "Opus \(stats.audio.channels) ch @ \(stats.audio.sampleRate) Hz" : "—")
                    row("Buffered", String(format: "%.0f ms", stats.audio.bufferedMilliseconds))
                    row("Packets / errors", "\(stats.audio.packetsDecoded) / \(stats.audio.decodeErrors)")
                    row("Underruns / dropped (late)", "\(stats.audio.underruns) / \(stats.audio.overflowDrops) frames")
                    row("Microphone", stats.audio.microphoneActive ? "On · \(stats.audio.microphonePacketsSent) packets sent" : "Off")
                }
                Section {
                    Toggle("Show debug lines", isOn: $showDebug)
                    ForEach(log.entries.reversed().filter { showDebug || $0.level != .debug }.prefix(200)) { entry in
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(entry.date.formatted(date: .omitted, time: .standard)) · \(entry.level.rawValue) · \(entry.category)")
                                .font(.caption2).foregroundStyle(color(entry.level))
                            Text(entry.message).font(.caption.monospaced()).textSelection(.enabled)
                        }
                    }
                } header: {
                    HStack {
                        Text("Log")
                        Spacer()
                        ShareLink(item: log.exportText) { Label("Export", systemImage: "square.and.arrow.up") }
                        Button {
                            UIPasteboard.general.string = DiagnosticsLog.shared.lastAttemptText
                        } label: { Label("Copy Last Attempt", systemImage: "doc.on.doc") }
                        ShareLink(item: ProblemReport.make(model: model)) {
                            Label("Share Problem Report", systemImage: "ladybug")
                        }
                        Button("Clear") { log.clear() }
                    }
                }
            }
            .navigationTitle("Connection Diagnostics")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
        .frame(minWidth: 720, minHeight: 820)
        .lockedSheet(isPresented: $showSignInInfo) { SignInInfoView() }
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title)
            Spacer()
            Text(value).foregroundStyle(.secondary).multilineTextAlignment(.trailing).monospacedDigit()
        }
    }

    private func color(_ level: DiagnosticsLog.Entry.Level) -> Color {
        switch level {
        case .error: return .red
        case .warning: return .orange
        case .info: return .secondary
        case .debug: return .gray
        }
    }
}
