import SwiftUI

/// One-tap network check to a console: round trip, jitter and loss, with plain advice and
/// the settings that suit this network.
struct ConnectionTestView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    let console: RegisteredConsole

    @State private var running = false
    @State private var result: ConnectionTestResult?
    @State private var applied = false
    @State private var port: PortCheck.Result?
    @State private var fullTest = false
    @State private var fullTestVerdict: String?

    private var address: String {
        model.discoveryInfo(for: console)?.address ?? console.lastKnownAddress
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Sends 30 small discovery messages to \(console.nickname) at \(address) and times the replies. Takes about 10 seconds; nothing changes on the console.")
                        .font(.callout).foregroundStyle(.secondary)
                    Button {
                        Task { await runTest() }
                    } label: {
                        Label(running ? "Testing…" : (result == nil ? "Run Connection Test" : "Run Again"), systemImage: "speedometer")
                    }
                    .disabled(running || model.stream.isActive)
                    if model.stream.isActive {
                        Text("Disconnect first; the test measures an idle network.").font(.caption).foregroundStyle(.orange)
                    }
                    if running { ProgressView().progressViewStyle(.linear) }
                    if let port {
                        Label(port.summary, systemImage: port.passed ? "checkmark.circle.fill" : "xmark.octagon.fill")
                            .foregroundStyle(port.passed ? .green : .red)
                    }
                }

                Section {
                    Text("Starts a real stream for a few seconds and shows each step, so you can see exactly where it stops. It checks the pairing keys and that video gets through your router, then disconnects.")
                        .font(.callout).foregroundStyle(.secondary)
                    Button {
                        startFullTest()
                    } label: {
                        Label(fullTest ? "Testing…" : "Run Full Stream Test", systemImage: "play.rectangle")
                    }
                    .disabled(fullTest || model.stream.isActive || running)
                    if fullTest || model.stream.progress.failedStage != nil || fullTestVerdict != nil {
                        ConnectionStepsView(progress: model.stream.progress)
                    }
                    if let fullTestVerdict { Text(fullTestVerdict).font(.callout.weight(.semibold)) }
                } header: {
                    Text("Full Stream Test")
                }

                if let result {
                    Section("Result") {
                        HStack {
                            Text(result.grade.rawValue).font(.title2.bold()).foregroundStyle(color(result.grade))
                            Spacer()
                            Text("Network: \(model.stream.network.interfaceName)").font(.caption).foregroundStyle(.secondary)
                        }
                        if result.grade != .unreachable {
                            metric("Round trip (median)", String(format: "%.1f ms", result.medianMilliseconds))
                            metric("Jitter", String(format: "%.1f ms", result.jitterMilliseconds))
                            metric("Packet loss", String(format: "%.0f %%", result.lossPercent))
                            SampleBars(samples: result.samples).frame(height: 60)
                        }
                    }
                    Section("Advice") {
                        ForEach(result.advice, id: \.self) { Label($0, systemImage: "lightbulb").font(.callout) }
                    }
                    if let suggested = result.suggested {
                        Section("Suggested settings for this network") {
                            Text("\(suggested.resolution.label) · \(suggested.fps) FPS · \(suggested.mode.rawValue) upscaling · \(suggested.networkMode.rawValue) network")
                            Button(applied ? "Applied" : "Apply Suggested Settings") {
                                let settings = model.settings
                                settings.resolution = suggested.resolution
                                settings.fps = suggested.fps
                                settings.upscaleMode = suggested.mode
                                settings.networkMode = suggested.networkMode
                                model.stream.applyUpscalerSettings()
                                applied = true
                            }
                            .disabled(applied)
                        }
                    }
                }
            }
            .navigationTitle("Connection Test")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
        .frame(minWidth: 620, minHeight: 680)
    }

    private func runTest() async {
        running = true
        applied = false
        port = nil
        port = await PortCheck.tcp(host: address)
        result = await ConnectionTestResult.run(address: address, ps5: console.isPS5, interface: model.stream.network.interfaceName)
        running = false
        if let result {
            vpLog(.info, "network", String(format: "Connection test to %@: %@, median %.1f ms, jitter %.1f ms, loss %.0f%%",
                                           address, result.grade.rawValue, result.medianMilliseconds, result.jitterMilliseconds, result.lossPercent))
        }
    }

    /// Connects for real, waits for video (or a failure, up to 50 s), then disconnects.
    private func startFullTest() {
        fullTest = true
        fullTestVerdict = nil
        model.stream.connect(to: console)
        Task { @MainActor in
            let start = Date()
            while Date().timeIntervalSince(start) < 50 {
                try? await Task.sleep(for: .milliseconds(300))
                let stream = model.stream
                if stream.phase == .streaming {
                    try? await Task.sleep(for: .seconds(4))   // let a few seconds of video arrive
                    let fps = stream.statistics.render.presentedFPS
                    fullTestVerdict = fps > 1
                        ? String(format: "Passed: video is playing (%.0f fps). Connection works.", fps)
                        : "Connected, but no video frames yet — try Codec H.264 in Settings."
                    stream.disconnect()
                    break
                }
                if stream.phase == .disconnected {
                    let code = stream.lastError?.code.code ?? stream.progress.failedStage?.failureCode.code ?? "VP-199"
                    fullTestVerdict = "Failed with \(code). See the stopped step above; Copy Log to send the details."
                    break
                }
            }
            if fullTestVerdict == nil {
                fullTestVerdict = "No result after 50 seconds (\(VPErrorCode.timeout.code))."
                model.stream.disconnect()
            }
            fullTest = false
        }
    }

    private func metric(_ title: String, _ value: String) -> some View {
        HStack { Text(title); Spacer(); Text(value).monospacedDigit().foregroundStyle(.secondary) }
    }

    private func color(_ grade: ConnectionTestResult.Grade) -> Color {
        switch grade {
        case .excellent: return .green
        case .good: return .mint
        case .fair: return .yellow
        case .poor: return .orange
        case .unreachable: return .red
        }
    }
}

/// Tiny bar chart of the probe round trips (red = lost).
private struct SampleBars: View {
    let samples: [Double]
    var body: some View {
        GeometryReader { geometry in
            let maxValue = max(samples.max() ?? 1, 10)
            HStack(alignment: .bottom, spacing: 2) {
                ForEach(Array(samples.enumerated()), id: \.offset) { item in
                    let lost = item.element < 0
                    RoundedRectangle(cornerRadius: 2)
                        .fill(lost ? Color.red : Color.accentColor)
                        .frame(height: lost ? geometry.size.height : max(2, geometry.size.height * item.element / maxValue))
                        .opacity(lost ? 0.5 : 1)
                }
            }
        }
    }
}
