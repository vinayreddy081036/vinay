import SwiftUI

/// Settings › Picture: presets, sliders, sharpening extras and letterbox handling.
struct PictureSettingsSection: View {
    @Environment(AppModel.self) private var model
    let settings: AppSettings

    var body: some View {
        @Bindable var settings = settings
        Section {
            Picker("Picture Mode", selection: Binding(get: { settings.pictureMode },
                                                     set: { settings.applyPictureMode($0); apply() })) {
                ForEach(PictureMode.allCases) { Text($0.rawValue).tag($0) }
            }
            Text(settings.pictureMode.detail).font(.caption).foregroundStyle(.secondary)
            slider("Brightness", \.brightness, PictureAdjustments.brightnessRange, format: "%+.0f", scale: 500)
            slider("Contrast", \.contrast, PictureAdjustments.contrastRange, format: "%.0f%%", scale: 100)
            slider("Colour", \.saturation, PictureAdjustments.saturationRange, format: "%.0f%%", scale: 100)
            slider("Warmth", \.temperature, PictureAdjustments.temperatureRange, format: "%+.0f", scale: 10)
            slider("Shadow Lift", \.shadowLift, PictureAdjustments.shadowLiftRange, format: "%.0f%%", scale: 100)
            Toggle("Smart Sharpening", isOn: $settings.smartSharpening)
            VStack(alignment: .leading) {
                HStack {
                    Text("Text Clarity")
                    Spacer()
                    Text("\(Int((settings.textClarity * 100).rounded()))%").monospacedDigit().foregroundStyle(.secondary)
                }
                Slider(value: $settings.textClarity, in: 0...1, step: 0.05)
            }
            .disabled(settings.lowLatency || settings.upscaleMode == .performance)
            Picker("Black Bars in Cutscenes", selection: $settings.blackBars) {
                ForEach(BlackBarsMode.allCases) { Text($0.rawValue).tag($0) }
            }
            Button("Reset Picture") { settings.applyPictureMode(.standard); apply() }
        } header: {
            Text("Picture")
        } footer: {
            Text("Shadow Lift brightens dark areas without greying the highlights. Smart Sharpening sharpens edges fully and flat areas (skin, sky) lightly. Text Clarity adds sharpening to hard, colourless edges such as menus, maps and subtitles. Black Bars: Pure Black stops the bars of letterboxed cutscenes glowing grey; Zoom to Fill enlarges the picture to fill the screen (the sides are cropped). Use Compare in the stream window to see the raw stream beside the processed one.")
        }
        .onChange(of: settings.smartSharpening) { apply() }
        .onChange(of: settings.textClarity) { apply() }
        .onChange(of: settings.blackBars) { apply() }
    }

    private func apply() { model.stream.applyUpscalerSettings() }

    private func slider(_ title: String, _ key: WritableKeyPath<PictureAdjustments, Double>,
                        _ range: ClosedRange<Double>, format: String, scale: Double) -> some View {
        VStack(alignment: .leading) {
            HStack {
                Text(title)
                Spacer()
                Text(String(format: format, settings.picture[keyPath: key] * scale)).monospacedDigit().foregroundStyle(.secondary)
            }
            Slider(value: Binding(get: { settings.picture[keyPath: key] },
                                  set: { value in settings.setPicture { $0[keyPath: key] = value }; apply() }),
                   in: range)
        }
    }
}
