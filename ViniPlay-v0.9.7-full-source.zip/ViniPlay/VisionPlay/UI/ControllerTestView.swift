import SwiftUI

/// Live view of controller input as VisionPlay sees it (no console needed).
struct ControllerTestView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let controllers = model.controllers
        let pad = controllers.snapshot
        let mapped = ControllerMapping.buttonsAndAxes(from: pad)
        NavigationStack {
            Form {
                Section("Connected Controllers") {
                    if controllers.controllers.isEmpty {
                        Text("No controller connected. Pair a DualSense in visionOS Settings › Bluetooth (hold PS + Create until the light bar flashes).")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(controllers.controllers) { info in
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text(info.name).font(.headline)
                                if info.isDualSense { Text("DualSense").font(.caption).padding(4).background(.blue.opacity(0.3), in: Capsule()) }
                                if info.name == controllers.activeName { Text("Active").font(.caption).foregroundStyle(.green) }
                            }
                            Text([info.batteryLevel.map { "Battery \(Int($0 * 100))%" },
                                  info.hasHaptics ? "Haptics" : nil,
                                  info.hasMotion ? "Motion" : nil,
                                  info.hasLight ? "Light bar" : nil].compactMap { $0 }.joined(separator: " · "))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }

                Section("Sticks & Triggers") {
                    HStack(spacing: 40) {
                        StickView(title: "Left", value: pad.leftStick, pressed: pad.l3)
                        StickView(title: "Right", value: pad.rightStick, pressed: pad.r3)
                        TriggerView(title: "L2", value: pad.leftTrigger, raw: mapped.l2)
                        TriggerView(title: "R2", value: pad.rightTrigger, raw: mapped.r2)
                    }
                    .frame(maxWidth: .infinity)
                    Text("Remote Play values → LX \(mapped.lx)  LY \(mapped.ly)  RX \(mapped.rx)  RY \(mapped.ry)")
                        .font(.caption.monospaced())
                }

                Section("Buttons") {
                    let names = pad.pressedButtonNames
                    Text(names.isEmpty ? "Press any button…" : names.joined(separator: "  ·  "))
                        .font(.title3)
                        .foregroundStyle(names.isEmpty ? .secondary : .primary)
                    Text(String(format: "Button mask 0x%05X", mapped.buttons)).font(.caption.monospaced())
                }

                Section("Touchpad") {
                    TouchpadView(touch0: pad.touch0, touch1: pad.touch1, clicked: pad.touchpadButton)
                        .frame(height: 140)
                }

                Section("Console Feedback") {
                    Text("Last adaptive-trigger effect: \(controllers.lastTriggerEffect)").font(.caption)
                    Button("Test Trigger Resistance (2 seconds)") { controllers.testTriggerFeedback() }
                        .disabled(model.stream.isActive)
                    Button("Stop Feedback") { controllers.resetFeedback() }
                }
            }
            .navigationTitle("Controller Test")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
        .frame(minWidth: 640, minHeight: 760)
        .onAppear { controllers.refresh(); controllers.publishSnapshot = true }
        .onDisappear { controllers.publishSnapshot = false }
    }
}

private struct StickView: View {
    let title: String
    let value: SIMD2<Float>
    let pressed: Bool
    var body: some View {
        VStack {
            ZStack {
                Circle().stroke(.secondary, lineWidth: 2)
                Circle().fill(pressed ? Color.green : Color.white)
                    .frame(width: 18, height: 18)
                    .offset(x: CGFloat(value.x) * 40, y: CGFloat(-value.y) * 40)
            }
            .frame(width: 100, height: 100)
            Text(title).font(.caption)
        }
    }
}

private struct TriggerView: View {
    let title: String
    let value: Float
    let raw: UInt8
    var body: some View {
        VStack {
            ZStack(alignment: .bottom) {
                RoundedRectangle(cornerRadius: 6).stroke(.secondary, lineWidth: 2)
                RoundedRectangle(cornerRadius: 6).fill(.blue).frame(height: CGFloat(value) * 100)
            }
            .frame(width: 30, height: 100)
            Text("\(title) \(raw)").font(.caption.monospacedDigit())
        }
    }
}

private struct TouchpadView: View {
    let touch0: SIMD2<Float>?
    let touch1: SIMD2<Float>?
    let clicked: Bool
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 12)
                    .fill(clicked ? Color.blue.opacity(0.35) : Color.white.opacity(0.08))
                ForEach(Array([touch0, touch1].enumerated()), id: \.offset) { item in
                    if let point = item.element {
                        Circle().fill(item.offset == 0 ? Color.orange : Color.pink)
                            .frame(width: 22, height: 22)
                            .position(x: CGFloat(point.x) * geometry.size.width, y: CGFloat(point.y) * geometry.size.height)
                    }
                }
            }
        }
    }
}
