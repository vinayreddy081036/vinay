import SwiftUI
import UIKit

/// The game window: an ordinary visionOS window, so you can drag it anywhere by its window
/// bar, resize it from a corner, and play inside Apple's Environments (Moon, Mount Hood…).
///
/// Under the picture there is a toolbar like Apple's own video apps: Screen (size, Cinema),
/// Volume, PS button, Microphone and More (Settings, Screenshot, End Game).
///
/// The picture is drawn exactly as before (MetalStreamView, the same renderer path as v0.9);
/// this file only adds the window and its buttons.
struct GameWindowView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.openWindow) private var openWindow
    @Environment(\.dismissWindow) private var dismissWindow
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.physicalMetrics) private var metrics
    /// A game has played in this window; when it ends, the window closes and Home returns.
    @State private var hadGame = false
    @State private var windowScene: UIWindowScene?
    /// The game window's TV size in inches (diagonal), any size you like. Saved.
    @AppStorage("vp.window.inches") private var windowInches: Double = 0

    var body: some View {
        let stream = model.stream
        ZStack {
            RoundedRectangle(cornerRadius: 46, style: .continuous).fill(.black)
            if let renderer = stream.renderer {
                // The window is kept 16:9, so the picture fills it edge to edge.
                MetalStreamView(renderer: renderer)
                    .aspectRatio(16.0 / 9.0, contentMode: .fit)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            if stream.phase == .connecting || stream.phase == .reconnecting {
                ConnectingCard().environment(model)
            }
            if stream.loginPINRequest != nil {
                PINPrompt().environment(model).frame(maxWidth: 520).glassBackgroundEffect()
            }
        }
        // Small minimum so 55″ and 65″ are never both clamped to the same size.
        .frame(minWidth: 480, minHeight: 270)
        .ornament(attachmentAnchor: .scene(.bottom), contentAlignment: .top) {
            GameToolbar(inches: $windowInches, onSize: { resize(inches: $0) }, onCinema: openCinema, onEnd: endGame,
                        onSettings: { openWindow(id: SceneID.settings) })
                .environment(model)
                .padding(.top, 16)
        }
        .background(WindowSceneReader { windowScene = $0 })
        .onChange(of: windowScene) {
            if windowInches > 0 {
                resize(inches: windowInches)
            } else if let windowScene {
                // Lock 16:9 from the start, even before you pick a size.
                let preferences = UIWindowScene.GeometryPreferences.Vision()
                preferences.resizingRestrictions = .uniform
                windowScene.requestGeometryUpdate(preferences) { _ in }
            }
        }
        .controllerPlaysTheGame()
        .onAppear {
            model.gameWindowOpen = true
            hadGame = stream.isActive
            if stream.phase == .streaming { model.startGameDetection() }
            dismissWindow(id: SceneID.main)
        }
        .onChange(of: stream.phase) { _, phase in
            if stream.isActive { hadGame = true }
            if phase == .streaming { model.startGameDetection() }
            // The game ended: back to Home, where any error is shown.
            if hadGame && !stream.isActive { dismissWindow(id: SceneID.playback) }
        }
        .onDisappear {
            model.gameWindowOpen = false
            dismissWindow(id: SceneID.settings)
            // Swapped for the Cinema screen: the game keeps running there.
            if model.switchingScreens { return }
            model.stopGameDetection()
            if stream.isActive { stream.disconnect() }
            openWindow(id: SceneID.main)
        }
    }

    /// Resize the window to look like a TV of that size (any size, in inches) seen from a proper
    /// seat. The window stays a normal window: move it anywhere, use it in Apple's
    /// Environments, or drag a corner afterwards.
    private func resize(inches: Double) {
        windowInches = inches
        guard let windowScene else { return }
        let realWidth = ScreenSize.width(forDiagonalInches: inches)
        // Width grows in step with the size you pick, so 55″ and 65″ are clearly different
        // (the old "proper seat" maths made neighbouring sizes almost the same). A TV seen
        // from 2.4 m, drawn in a window about 1.5 m away.
        let apparent = realWidth * 1.5 / 2.4
        let width = max(480, Double(metrics.convert(CGFloat(apparent), from: .meters)))
        let size = CGSize(width: width, height: width * 9 / 16)
        requestSize(size, on: windowScene, attempt: 1)
    }

    /// visionOS can ignore a resize while a popover is closing or the window is being moved,
    /// so a refused or ignored request is tried again (up to four times).
    private func requestSize(_ size: CGSize, on windowScene: UIWindowScene, attempt: Int) {
        let preferences = UIWindowScene.GeometryPreferences.Vision()
        preferences.size = size
        // Keep it 16:9: dragging a corner scales both sides together, so no black bars.
        preferences.resizingRestrictions = .uniform
        windowScene.requestGeometryUpdate(preferences) { error in
            vpLog(.info, "window", "Resize attempt \(attempt) refused: \(error.localizedDescription)")
        }
        guard attempt < 4 else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let current = windowScene.effectiveGeometry.coordinateSpace.bounds.size
            if abs(current.width - size.width) > 8 || abs(current.height - size.height) > 8 {
                requestSize(size, on: windowScene, attempt: attempt + 1)
            }
        }
    }

    private func openCinema() {
        model.switchingScreens = true
        Task {
            let result = await openImmersiveSpace(id: SceneID.customScreen)
            if case .opened = result {
                dismissWindow(id: SceneID.playback)
            }
            // Let the window's onDisappear see the flag, then clear it.
            try? await Task.sleep(for: .milliseconds(500))
            model.switchingScreens = false
        }
    }

    private func endGame() {
        model.stream.disconnect()
        dismissWindow(id: SceneID.playback)
    }
}

/// The toolbar under the game window (always visible).
private struct GameToolbar: View {
    @Environment(AppModel.self) private var model
    @Binding var inches: Double
    let onSize: (Double) -> Void
    @State private var showSize = false
    @State private var draftInches: Double = 65
    let onCinema: () -> Void
    let onEnd: () -> Void
    let onSettings: () -> Void
    @State private var showVolume = false
    @State private var confirmEnd = false

    var body: some View {
        let settings = model.settings
        let stream = model.stream
        HStack(spacing: 20) {
            Button { draftInches = inches > 0 ? inches : 65; showSize.toggle() } label: {
                Image(systemName: "rectangle.inset.filled").font(.title2)
            }
            .help("Screen size")
            .popover(isPresented: $showSize) {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Screen Size").font(.headline)
                        Spacer()
                        Text("\(Int(draftInches))″").monospacedDigit().foregroundStyle(.secondary)
                    }
                    // Any size from 40″ to 300″; the window resizes when you let go.
                    Slider(value: $draftInches, in: 40...300, step: 1, onEditingChanged: { editing in
                        if !editing { apply(draftInches) }
                    })
                    .frame(width: 360)
                    HStack(spacing: 6) {
                        ForEach([55, 65, 75, 85, 105, 125, 175, 205], id: \.self) { size in
                            Button("\(size)″") { draftInches = Double(size); apply(Double(size)) }
                                .buttonStyle(.bordered)
                                .controlSize(.small)
                        }
                    }
                    Text("The window stays a normal window: drag its bar to put it anywhere, and it works in Apple's Environments. You can also drag a corner.")
                        .font(.caption).foregroundStyle(.secondary)
                        .frame(width: 360, alignment: .leading)
                    Divider()
                    Button { showSize = false; onCinema() } label: { Label("Cinema (giant screen)", systemImage: "theatermasks") }
                }
                .padding()
            }

            Button { showVolume.toggle() } label: {
                Image(systemName: settings.volume < 0.01 ? "speaker.slash.fill" : "speaker.wave.3.fill").font(.title2)
            }
            .help("Volume")
            .popover(isPresented: $showVolume) {
                HStack {
                    Image(systemName: "speaker.fill")
                    Slider(value: Binding(get: { settings.volume },
                                          set: { settings.volume = $0; stream.setVolume($0) }), in: 0...1)
                        .frame(width: 260)
                    Image(systemName: "speaker.wave.3.fill")
                }
                .padding()
            }

            Button { pressPSButton() } label: { Image(systemName: "playstation.logo").font(.title2) }
                .help("PS button")

            Button { stream.toggleMicrophone() } label: {
                Image(systemName: stream.microphoneOn ? "mic.fill" : "mic.slash.fill").font(.title2)
            }
            .help(stream.microphoneOn ? "Microphone on" : "Microphone off")

            if let battery = model.controllers.batteryStatus {
                let percent = Int((battery.level * 100).rounded())
                Text("\(percent)%\(battery.charging ? " ⚡︎" : "")")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(percent <= 15 && !battery.charging ? .red : .secondary)
            }

            if confirmEnd {
                Button("Keep Playing") { confirmEnd = false }
                Button("End Game", role: .destructive) { confirmEnd = false; onEnd() }
                    .buttonStyle(.borderedProminent)
            } else {
                Menu {
                    Button { onSettings() } label: { Label("Settings", systemImage: "gearshape") }
                    Button { stream.saveScreenshot() } label: { Label("Screenshot", systemImage: "camera") }
                        .disabled(stream.phase != .streaming)
                    Button(role: .destructive) { confirmEnd = true } label: { Label("End Game", systemImage: "xmark") }
                } label: {
                    Image(systemName: "ellipsis").font(.title2)
                }
                .help("More")
            }
        }
        .buttonStyle(.borderless)
        .padding(.horizontal, 28)
        .padding(.vertical, 14)
        .glassBackgroundEffect(in: Capsule())
    }

    /// Close the size popover first (visionOS may ignore a resize while it is open), then resize.
    private func apply(_ value: Double) {
        showSize = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { onSize(value) }
    }

    /// A short press of the PS button (opens the PS5's control centre).
    private func pressPSButton() {
        var pad = GamepadSnapshot()
        pad.ps = true
        model.controllers.setVirtualInput(pad)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            model.controllers.setVirtualInput(GamepadSnapshot())
        }
    }
}

/// Finds the UIWindowScene that hosts a SwiftUI view (for resizing the window).
private struct WindowSceneReader: UIViewRepresentable {
    let found: (UIWindowScene?) -> Void
    func makeUIView(context: Context) -> SceneProbe { SceneProbe(found: found) }
    func updateUIView(_ view: SceneProbe, context: Context) {}

    final class SceneProbe: UIView {
        let found: (UIWindowScene?) -> Void
        init(found: @escaping (UIWindowScene?) -> Void) {
            self.found = found
            super.init(frame: .zero)
            isUserInteractionEnabled = false
        }
        required init?(coder: NSCoder) { fatalError() }
        override func didMoveToWindow() {
            super.didMoveToWindow()
            let scene = window?.windowScene
            DispatchQueue.main.async { self.found(scene) }
        }
    }
}

/// The Settings window, separate from the game and movable. Done closes it.
struct SettingsWindowRoot: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismissWindow) private var dismissWindow
    var body: some View {
        SettingsView(inPlayback: model.stream.isActive, onDone: { dismissWindow(id: SceneID.settings) })
    }
}
