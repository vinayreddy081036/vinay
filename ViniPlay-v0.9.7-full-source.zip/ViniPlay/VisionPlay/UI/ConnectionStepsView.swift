import SwiftUI
import UIKit

/// Live checklist of the connection stages, with Copy Log and (when the PS5 rejected the
/// pairing) Pair Again. Shown on Home while connecting and after a failed start.
struct ConnectionStepsView: View {
    let progress: ConnectionProgress
    var onPairAgain: (() -> Void)?
    @State private var copied = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(ConnectionProgress.Stage.allCases) { stage in
                HStack(spacing: 10) {
                    icon(progress.status(stage))
                        .frame(width: 22)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(stage.title)
                            .foregroundStyle(progress.status(stage) == .pending ? .secondary : .primary)
                        if let detail = progress.detail[stage] {
                            Text(detail).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            if let note = progress.note {
                Label(note, systemImage: "arrow.triangle.2.circlepath").font(.caption).foregroundStyle(.secondary)
            }
            if let failed = progress.failedStage {
                Text("Stopped at “\(failed.title)” — \(progress.detail[failed] ?? failed.failureCode.code)")
                    .font(.callout.weight(.semibold))
            }
            HStack {
                Button {
                    UIPasteboard.general.string = DiagnosticsLog.shared.lastAttemptText
                    copied = true
                } label: {
                    Label(copied ? "Copied" : "Copy Log", systemImage: copied ? "checkmark" : "doc.on.doc")
                }
                .help("Copies the last connection attempt's log so you can paste it into a message.")
                if let onPairAgain {
                    Button(action: onPairAgain) { Label("Pair Again", systemImage: "link.badge.plus") }
                        .buttonStyle(.borderedProminent)
                }
            }
            .padding(.top, 4)
        }
        .onChange(of: progress.isRunning) { if progress.isRunning { copied = false } }
    }

    @ViewBuilder private func icon(_ status: ConnectionProgress.Status) -> some View {
        switch status {
        case .pending: Image(systemName: "circle").foregroundStyle(.secondary)
        case .active: ProgressView().controlSize(.small)
        case .done: Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
        case .failed: Image(systemName: "xmark.circle.fill").foregroundStyle(.red)
        }
    }
}
