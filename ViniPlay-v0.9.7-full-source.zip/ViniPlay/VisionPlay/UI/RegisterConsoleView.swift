import SwiftUI

struct RegisterConsoleView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss

    @State private var host: String
    @State private var isPS5: Bool
    @State private var accountID = ""
    @State private var pin = ""
    @State private var accountName = ""
    @State private var showPSNLogin = false
    @State private var psnStatus: String?
    @State private var showSignInInfo = false
    let consoleName: String?

    init(initialHost: String, isPS5: Bool, consoleName: String?) {
        _host = State(initialValue: initialHost)
        _isPS5 = State(initialValue: isPS5)
        self.consoleName = consoleName
    }

    var body: some View {
        let registration = model.registration
        NavigationStack {
            Form {
                Section {
                    TextField("192.168.1.20", text: $host)
                        .keyboardType(.numbersAndPunctuation)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Toggle("PlayStation 5", isOn: $isPS5)
                } header: {
                    Text(consoleName.map { "Console — \($0)" } ?? "Console IP Address")
                }

                Section {
                    TextField("Base64, e.g. AbCdEfGhIjk=", text: $accountID)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .font(.body.monospaced())
                    Button {
                        showPSNLogin = true
                    } label: {
                        Label("Sign in to PlayStation Network to fetch it (headset, QR code or code)", systemImage: "person.badge.key")
                    }
                    Button { showSignInInfo = true } label: { Label("How sign-in works", systemImage: "info.circle") }
                    if let psnStatus { Text(psnStatus).font(.caption).foregroundStyle(.secondary) }
                } header: {
                    Text("PSN Account ID")
                } footer: {
                    Text("Required by the PS5 to identify the user. It is the account number of the PSN user signed in on the console, not your password. VisionPlay keeps only this ID, in the Keychain.")
                }

                Section {
                    TextField("e.g. Vinay (optional)", text: $accountName)
                } header: {
                    Text("Player Name")
                } footer: {
                    Text("To play on the same PS5 with a second PSN account, pair it again signed in as that account and give it a name — both registrations appear on the home screen.")
                }

                Section {
                    TextField("8-digit code", text: $pin)
                        .keyboardType(.numberPad)
                        .font(.title2.monospacedDigit())
                } header: {
                    Text("Enter Pairing PIN")
                } footer: {
                    Text("On the PS5: Settings › System › Remote Play › Pair Device. The code expires after about five minutes.")
                }

                Section {
                    switch registration.state {
                    case .idle, .canceled:
                        EmptyView()
                    case .validating:
                        ProgressView("Checking…")
                    case .registering(let target):
                        HStack { ProgressView(); Text("Registering with \(target)…") }
                    case .succeeded(let console):
                        Label("Registered \(console.nickname)", systemImage: "checkmark.seal.fill").foregroundStyle(.green)
                    case .failed(let error):
                        Label(error.localizedDescription, systemImage: "xmark.octagon.fill").foregroundStyle(.red)
                    }
                    Button {
                        registration.register(host: host, isPS5: isPS5, pinText: pin, accountIDBase64: accountID,
                                              accountName: accountName,
                                              store: model.consoles) { result in
                            if case .success = result {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { dismiss() }
                            }
                        }
                    } label: {
                        Label("Register", systemImage: "link")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(registration.state.isBusy || host.isEmpty || pin.isEmpty || accountID.isEmpty)
                }
            }
            .navigationTitle("Register PS5")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") {
                        registration.reset()
                        dismiss()
                    }
                }
            }
        }
        .frame(minWidth: 620, minHeight: 720)
        .onAppear {
            registration.reset()
            if accountID.isEmpty, let saved = try? model.consoles.keychain.psnAccountID() {
                accountID = saved.base64EncodedString()
                psnStatus = "Using the account ID saved from a previous registration."
            }
        }
        .lockedSheet(isPresented: $showSignInInfo) { SignInInfoView() }
        .lockedSheet(isPresented: $showPSNLogin) {
            PSNLoginView { result in
                showPSNLogin = false
                switch result {
                case .success(let login):
                    accountID = login.accountID.base64EncodedString()
                    psnStatus = "Account ID received from PlayStation Network."
                case .failure(let error):
                    psnStatus = "Sign-in failed: \(error.localizedDescription)"
                }
            }
        }
    }
}
