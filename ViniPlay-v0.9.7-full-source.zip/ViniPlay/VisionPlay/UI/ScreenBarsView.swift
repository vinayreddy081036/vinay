import SwiftUI

/// Size and Distance bars shared by Settings and the in-room panel. Dragging edits a draft
/// (live preview + outline in the room); letting go commits it and the screen glides there.
struct ScreenBarsView: View {
    @Environment(AppModel.self) private var model
    var showPreview = true
    var quickDistances: [Double] = [5, 20, 50, 200, 1000, 10000]

    var body: some View {
        let settings = model.settings
        let editor = model.screenEditor
        VStack(alignment: .leading, spacing: 10) {
            if showPreview {
                ScreenPreviewDrawing(angle: editor.angle(settings), distance: editor.distance(settings),
                                     width: editor.width(settings), dragging: editor.isDragging)
                    .frame(height: 170)
            }

            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    Label("Size", systemImage: "arrow.up.left.and.arrow.down.right")
                    Spacer()
                    Text("\(Self.meters(editor.width(settings))) wide").monospacedDigit().foregroundStyle(.secondary)
                }
                Slider(value: logBinding(Binding(get: { editor.width(settings) }, set: { editor.setWidth($0, settings) }),
                                         range: AppSettings.customWidthRange),
                       in: 0...1) {
                    Text("Size")
                } minimumValueLabel: { Text("1 m").font(.caption2) } maximumValueLabel: { Text("2 km").font(.caption2) }
                onEditingChanged: { editing in
                    if editing { editor.begin(settings) } else { editor.commit(settings) }
                }
                   // hands or controller
            }

            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    Label("Distance", systemImage: "arrow.forward.to.line")
                    Spacer()
                    Text(String(format: "%@ away · %.0f° · %@", Self.meters(editor.distance(settings)),
                                editor.angle(settings), AppSettings.describe(angle: editor.angle(settings))))
                        .monospacedDigit().foregroundStyle(.secondary)
                }
                Slider(value: logBinding(Binding(get: { editor.distance(settings) }, set: { editor.setDistance($0, settings) }),
                                         range: AppSettings.customDistanceRange),
                       in: 0...1) {
                    Text("Distance")
                } minimumValueLabel: { Text("2 m").font(.caption2) } maximumValueLabel: { Text("10 km").font(.caption2) }
                onEditingChanged: { editing in
                    if editing { editor.begin(settings) } else { editor.commit(settings) }
                }
                   // hands or controller
                if editor.distance(settings) > (editor.draftDistance ?? settings.viewingDistance) + 0.01 {
                    Text("Pushed back so this size doesn't reach your face.").font(.caption2).foregroundStyle(.orange)
                }
            }

            HStack(spacing: 6) {
                Text("Size").font(.caption).foregroundStyle(.secondary)
                ForEach([("TV", 1.6), ("Cinema", 15.0), ("IMAX", 38.8), ("Giant", 100.0), ("Huge", 500.0), ("2 km", 2000.0)], id: \.0) { item in
                    Button(item.0) { editor.apply(width: item.1, settings) }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                }
            }
            HStack(spacing: 6) {
                Text("Distance").font(.caption).foregroundStyle(.secondary)
                ForEach(quickDistances, id: \.self) { d in
                    Button(Self.meters(d)) { editor.apply(distance: d, settings) }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                }
            }
        }
    }

    static func meters(_ v: Double) -> String {
        if v >= 1000 { return String(format: v.truncatingRemainder(dividingBy: 1000) == 0 ? "%.0f km" : "%.1f km", v / 1000) }
        return v < 10 ? String(format: "%.1f m", v) : String(format: "%.0f m", v)
    }

    static func distanceText(_ distance: Double, width: Double) -> String {
        "\(meters(distance)) away · \(meters(width)) wide"
    }

    private func logBinding(_ value: Binding<Double>, range: ClosedRange<Double>) -> Binding<Double> {
        let lo = log(range.lowerBound), hi = log(range.upperBound)
        return Binding(
            get: { (log(min(max(value.wrappedValue, range.lowerBound), range.upperBound)) - lo) / (hi - lo) },
            set: { value.wrappedValue = exp(lo + min(max($0, 0), 1) * (hi - lo)) }
        )
    }
}

/// Top-down sketch: you at the bottom, the screen ahead, the cone of your view it fills.
/// Distance is drawn on a log scale so 2 m and 10 km both fit; the angle is drawn true.
struct ScreenPreviewDrawing: View {
    let angle: Double
    let distance: Double
    let width: Double
    let dragging: Bool

    var body: some View {
        Canvas { context, size in
            let you = CGPoint(x: size.width / 2, y: size.height - 18)
            // Log-scaled depth: 2 m → near you, 10 km → top of the box.
            let lo = log(AppSettings.customDistanceRange.lowerBound), hi = log(AppSettings.customDistanceRange.upperBound)
            let t = (log(min(max(distance, AppSettings.customDistanceRange.lowerBound), AppSettings.customDistanceRange.upperBound)) - lo) / (hi - lo)
            let depth = 28 + t * (size.height - 60)
            let half = min(angle, 179) / 2 * .pi / 180
            let screenY = you.y - depth
            let halfWidth = min(depth * tan(half), size.width / 2 - 6)
            let accent = dragging ? Color.cyan : Color.accentColor

            // Field-of-view cone (your eyes' natural ~100° marked faintly).
            var natural = Path()
            let nat = 50.0 * .pi / 180
            natural.move(to: you)
            natural.addLine(to: CGPoint(x: you.x - depth * tan(nat), y: screenY))
            natural.move(to: you)
            natural.addLine(to: CGPoint(x: you.x + depth * tan(nat), y: screenY))
            context.stroke(natural, with: .color(.secondary.opacity(0.35)), style: StrokeStyle(lineWidth: 1, dash: [3, 4]))

            var cone = Path()
            cone.move(to: you)
            cone.addLine(to: CGPoint(x: you.x - halfWidth, y: screenY))
            cone.addLine(to: CGPoint(x: you.x + halfWidth, y: screenY))
            cone.closeSubpath()
            context.fill(cone, with: .color(accent.opacity(0.15)))

            // The screen.
            var screen = Path()
            screen.move(to: CGPoint(x: you.x - halfWidth, y: screenY))
            screen.addLine(to: CGPoint(x: you.x + halfWidth, y: screenY))
            context.stroke(screen, with: .color(accent), style: StrokeStyle(lineWidth: dragging ? 5 : 4, lineCap: .round))
            if dragging {
                context.stroke(screen, with: .color(.cyan.opacity(0.35)), style: StrokeStyle(lineWidth: 12, lineCap: .round))
            }

            // You.
            context.fill(Path(ellipseIn: CGRect(x: you.x - 7, y: you.y - 7, width: 14, height: 14)), with: .color(.primary))
            context.draw(Text("You").font(.caption2), at: CGPoint(x: you.x, y: you.y + 12))

            // Labels.
            context.draw(Text(String(format: "%.0f°", angle)).font(.caption.bold()), at: CGPoint(x: you.x, y: you.y - depth / 2))
            context.draw(Text(ScreenBarsView.distanceText(distance, width: width)).font(.caption2),
                         at: CGPoint(x: you.x, y: max(screenY - 12, 8)))
        }
        .background(.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 14))
        .accessibilityLabel(String(format: "Screen %.0f degrees wide, %@", angle, ScreenBarsView.distanceText(distance, width: width)))
        .animation(.easeOut(duration: 0.2), value: angle)
        .animation(.easeOut(duration: 0.2), value: distance)
    }
}
