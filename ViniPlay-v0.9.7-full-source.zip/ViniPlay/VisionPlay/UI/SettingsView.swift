import SwiftUI

struct SettingsView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissWindow) private var dismissWindow
    var inPlayback = false
    var onDone: (() -> Void)? = nil
    @State private var confirmReset = false
    @State private var consolePendingRemoval: RegisteredConsole?

    /// Opens Custom Screen and closes this window, so nothing sits in front of the picture
    /// and the controller can only ever reach the game. The screen's own settings are on
    /// your left inside Custom Screen.
    private func openCustomScreen() {
        Task {
            // Open first; only close the windows once the space is really open, so a failed
            // or cancelled open never leaves you with no windows at all.
            guard case .opened = await openImmersiveSpace(id: SceneID.customScreen) else { return }
            // Custom Screen is the only screen: Home steps away. (customScreenOpen is set by the
            // screen itself when it appears, so it is always true to what's on screen.)
            dismissWindow(id: SceneID.main)
        }
    }

    var body: some View {
        @Bindable var settings = model.settings
        NavigationStack {
            Form {
                // Keep the screen controls first: they are the controls used
                // before a Remote Play session starts.
                Section("Screen Size & Distance") {
                    ScreenSizeControls(settings: settings)
                    if !model.customScreenOpen {
                        Button("Preview Screen") { openCustomScreen() }
                        Text("Games play on this screen at the size and distance above. Preview it here before you play.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }

                Section {
                    Button("Use High Quality Picture") {
                        settings.useHighQualityPicture()
                        model.stream.resetAdaptiveQuality()
                        model.stream.applyUpscalerSettings()
                    }
                    Text("1080p HEVC · 25 Mbps · detailed 4K scaling. Reconnect to apply stream quality. Adaptive Quality remains available for weaker networks.")
                        .font(.caption).foregroundStyle(.secondary)
                    Picker("Resolution", selection: $settings.resolution) {
                        ForEach(StreamResolution.allCases) { Text($0.label).tag($0) }
                    }
                    Picker("Frame Rate", selection: $settings.fps) {
                        Text("30 FPS").tag(30)
                        Text("60 FPS").tag(60)
                    }
                    Picker("Codec", selection: Binding(
                        get: { settings.codec == .h264 ? StreamCodec.h264 : StreamCodec.hevc },
                        set: { settings.codec = $0 })) {
                        Text(StreamCodec.h264.label).tag(StreamCodec.h264)
                        Text(StreamCodec.hevc.label).tag(StreamCodec.hevc)
                    }
                    // One HDR switch. HDR needs HEVC, and the PS5's own HDR setting must be on.
                    Toggle("HDR", isOn: Binding(
                        get: { settings.codec == .hevcHDR },
                        set: { settings.codec = $0 ? .hevcHDR : .hevc }))
                        .disabled(settings.codec == .h264)
                    Picker("Network Mode", selection: $settings.networkMode) {
                        ForEach(NetworkMode.allCases) { Text($0.rawValue).tag($0) }
                    }
                    Toggle("Custom Bitrate", isOn: Binding(
                        get: { settings.customBitrateMbps > 0 },
                        set: { settings.customBitrateMbps = $0 ? 40 : 0 }))
                    if settings.customBitrateMbps > 0 {
                        VStack(alignment: .leading) {
                            Text("Bitrate: \(settings.customBitrateMbps) Mbps")
                            Slider(value: Binding(get: { Double(settings.customBitrateMbps) },
                                                  set: { settings.customBitrateMbps = Int($0.rounded()) }),
                                   in: 2...100, step: 1)
                        }
                        Text("Higher bitrate = fewer compression blocks, but needs a strong connection (Ethernet to the PS5, 5 or 6 GHz Wi-Fi). The PS5 may cap what it really sends; if it refuses, ViniPlay retries with safe settings.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Toggle("Automatic Reconnection", isOn: $settings.reconnection)
                    Toggle("Adaptive Quality", isOn: $settings.adaptiveQuality)
                    Toggle("Resume When I Put the Headset Back On", isOn: $settings.resumeAfterHeadsetOff)
                    Button("Reset Adaptive Quality for This Network") { model.stream.resetAdaptiveQuality() }
                        .disabled(!settings.adaptiveQuality)
                } header: {
                    Text("Streaming")
                } footer: {
                    Text("Adaptive Quality lowers the bitrate, then the resolution, when a connection keeps losing packets, and goes back up after two clean minutes; it remembers each network separately. Reconnection retries immediately, then backs off, and also kicks in when Wi-Fi drops or changes. PS5 Remote Play streams at up to 1080p. Changes apply to the next connection. HEVC uses less bandwidth at the same quality; use H.264 if you see decoder errors. HEVC HDR shows HDR games with real highlights in the window (EDR) and tone-mapped on the screen; the PS5's own HDR setting must be on.")
                }

                PictureSettingsSection(settings: settings)

                Section {
                    Toggle("Upscaling", isOn: $settings.upscalingEnabled)
                    Picker("Mode", selection: $settings.upscaleMode) {
                        ForEach(UpscaleMode.allCases) { Text($0.rawValue).tag($0) }
                    }
                    .disabled(!settings.upscalingEnabled)
                    Picker("Output Target", selection: $settings.outputTarget) {
                        ForEach(OutputTarget.allCases) { Text($0.rawValue).tag($0) }
                    }
                    .disabled(!settings.upscalingEnabled)
                    VStack(alignment: .leading) {
                        HStack {
                            Text("Sharpening")
                            Spacer()
                            Text("\(Int((settings.sharpening * 100).rounded()))%").monospacedDigit().foregroundStyle(.secondary)
                        }
                        Slider(value: $settings.sharpening, in: 0...1, step: 0.01)
                    }
                    .disabled(!settings.upscalingEnabled || settings.upscaleMode == .performance)
                    Text(settings.upscaleMode.summary).font(.caption).foregroundStyle(.secondary)
                } header: {
                    Text("Upscaling")
                } footer: {
                    Text("Upscaling enlarges the 1080p stream on the GPU; it is not native 4K from the PS5. MetalFX: \(model.stream.renderer?.currentStats.metalFXAvailable == true ? "available on this device" : "not available here (Lanczos fallback)").")
                }
                .onChange(of: settings.upscalingEnabled) { model.stream.applyUpscalerSettings() }
                .onChange(of: settings.upscaleMode) { model.stream.applyUpscalerSettings() }
                .onChange(of: settings.outputTarget) { model.stream.applyUpscalerSettings() }
                .onChange(of: settings.sharpening) { model.stream.applyUpscalerSettings() }

                Section {
                    LabeledSlider(title: "Volume", value: $settings.volume, range: 0...1, unit: "")
                        .onChange(of: settings.volume) { model.stream.setVolume(settings.volume) }
                    Toggle("Sound From the Screen", isOn: $settings.spatialAudio)
                    Toggle("Room Acoustics", isOn: $settings.roomAcoustics)
                        .disabled(!settings.spatialAudio)
                    Toggle("Virtual Surround (effect)", isOn: $settings.surroundUpmix)
                        .disabled(!settings.spatialAudio)
                    DisclosureGroup("Getting 3D Audio from your PS5") {
                        PS5AudioHelpText()
                    }
                } header: {
                    Text("Audio")
                } footer: {
                    Text("Sound From the Screen places the game's left and right channels at the edges of the virtual screen using visionOS spatial audio, with head tracking — turn your head and the sound stays with the screen. Room Acoustics adds a subtle reverb sized to the screen (living room for small screens, cinema hall for 175″ and up). Virtual Surround adds soft rear ambience made from the stereo mix; it is an effect, not the game's real surround channels, so it is off by default.")
                }
                .onChange(of: settings.spatialAudio) { model.refreshAudioLayout() }
                .onChange(of: settings.roomAcoustics) { model.refreshAudioLayout() }
                .onChange(of: settings.surroundUpmix) { model.refreshAudioLayout() }
                .onChange(of: settings.screenWidthMeters) { model.refreshAudioLayout() }
                .onChange(of: settings.viewingDistance) { model.refreshAudioLayout() }

                Section {
                    Picker("Compression Clean-up", selection: $settings.deblock) {
                        Text("Off").tag(0.0)
                        Text("Light").tag(0.5)
                        Text("Strong").tag(1.0)
                    }
                } header: {
                    Text("Clean-up")
                } footer: {
                    Text("Compression Clean-up smooths blocks and banding in flat, dark areas (skies, fog, shadows) before upscaling; edges and texture are left alone. Frames are always shown in step with the display (120 Hz), so motion stays even. Screenshots go to Photos.")
                }
                .onChange(of: settings.deblock) { model.stream.applyUpscalerSettings() }

                Section {
                    Toggle("Motion Controls (experimental)", isOn: $settings.motionControls)
                } header: {
                    Text("Controller & Overlay")
                } footer: {
                    Text("Controller vibration is not used (it slowed the game down). Motion forwarding uses the DualSense gyroscope; its axis mapping has not been verified against games yet.")
                }

                Section("Registered Consoles") {
                    if model.consoles.consoles.isEmpty {
                        Text("None").foregroundStyle(.secondary)
                    }
                    ForEach(model.consoles.consoles) { console in
                        HStack {
                            Text(console.nickname)
                            Spacer()
                            Button("Remove Registered Console", role: .destructive) { consolePendingRemoval = console }
                        }
                    }
                }

                Section {
                    Button("Reset Settings", role: .destructive) { confirmReset = true }
                } footer: {
                    Text("Restores the defaults: 1080p, 60 FPS, upscaling on, Quality mode, 3840 × 2160 output, 35% sharpening, flat display, automatic network mode, reconnection on. Registered consoles are kept.")
                }
            }
            .navigationTitle("Settings")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { if let onDone { onDone() } else { dismiss() } } } }
        }
        .frame(minWidth: inPlayback ? 480 : 640, minHeight: inPlayback ? 0 : 760)
        .confirmationDialog("Reset all settings to their defaults?", isPresented: $confirmReset, titleVisibility: .visible) {
            Button("Reset Settings", role: .destructive) {
                model.settings.reset()
                model.stream.applyUpscalerSettings()
            }
        }
        .alert("Remove \(consolePendingRemoval?.nickname ?? "console")?",
               isPresented: Binding(get: { consolePendingRemoval != nil }, set: { if !$0 { consolePendingRemoval = nil } })) {
            Button("Remove", role: .destructive) {
                if let console = consolePendingRemoval { model.removeConsole(console) }
                consolePendingRemoval = nil
            }
            Button("Cancel", role: .cancel) { consolePendingRemoval = nil }
        }
    }
}

private struct PS5AudioHelpText: View {
    var body: some View {
        Text(PS5AudioGuide.text)
            .font(.callout)
            .foregroundStyle(.secondary)
    }
}

struct LabeledSlider: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let unit: String

    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Text(title)
                Spacer()
                Text(unit.isEmpty ? "\(Int((value * 100).rounded()))%" : String(format: "%.2f %@", value, unit))
                    .monospacedDigit().foregroundStyle(.secondary)
            }
            Slider(value: $value, in: range)
        }
    }
}
