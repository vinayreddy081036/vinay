// VisionPlay GPU video pipeline.
//
//   VideoToolbox NV12 (IOSurface) ──► ycbcr_to_rgb ──► [MetalFX Spatial | separable Lanczos-3 | separable Catmull-Rom]
//                                                   ──► compose_fragment (CAS sharpening + letterbox) ──► drawable / RealityKit texture
//
// Performance mode skips the intermediate passes and runs compose_yuv_fragment, which
// converts and bilinear-scales straight into the output in one pass.

#include <metal_stdlib>
using namespace metal;

struct ColorConversion {
    float3x3 matrix;     // Y'CbCr → R'G'B'
    float3 offset;       // subtracted from (Y, Cb, Cr) before the matrix
    float3 scale;        // range expansion for (Y, Cb, Cr)
};

struct ScaleUniforms {
    float2 sourceSize;   // texels
    float2 destSize;     // texels
    float  support;      // filter radius in source texels (2 for Catmull-Rom, 3 for Lanczos-3)
    uint   filter;       // 0 = Catmull-Rom, 1 = Lanczos-3
    uint   horizontal;   // 1 = horizontal pass, 0 = vertical pass
    float  pad;
};

struct ComposeUniforms {
    float4 contentRect;  // x, y, width, height in normalized target coordinates
    float2 contentSize;  // texels of the content texture
    float  casPeakDenominator; // see UpscalerConfiguration.casPeakDenominator
    float  sharpenAmount;      // 0 disables sharpening
    uint   decodeToLinear;     // 1 when the render target is sRGB/float (expects linear light)
    uint   transferMode;       // 0 = SDR video, 1 = PQ → EDR (BT.2020 linear), 2 = PQ → SDR tone-mapped (BT.709)
    float  headroom;           // EDR peak relative to SDR white (mode 1)
    float  referenceWhiteNits; // nits mapped to 1.0 (BT.2408: 203)
    float4 picture;            // brightness, contrast, saturation, temperature
    float4 extra;              // shadowLift, textClarity, compareSplit (0 = off, else x in 0…1), sourcePeakNits
    float2 bars;               // letterbox top / bottom as fractions of the content height
    uint   barsMode;           // 0 leave, 1 force black, 2 zoom to fill
    uint   smartSharpen;       // 1 = edge-aware sharpening
};

// MARK: - Helpers

static inline float3 ycbcr_to_rgb_value(float y, float2 cbcr, constant ColorConversion &cc) {
    float3 ycc = (float3(y, cbcr) - cc.offset) * cc.scale;
    return saturate(cc.matrix * ycc);
}

static inline float3 srgb_to_linear(float3 c) {
    float3 lo = c / 12.92;
    float3 hi = pow((c + 0.055) / 1.055, 2.4);
    return select(hi, lo, c <= 0.04045);
}

static inline float3 linear_to_srgb(float3 c) {
    c = saturate(c);
    float3 lo = c * 12.92;
    float3 hi = 1.055 * pow(c, 1.0 / 2.4) - 0.055;
    return select(hi, lo, c <= 0.0031308);
}

/// SMPTE ST 2084 (PQ) EOTF: non-linear [0,1] → absolute luminance in nits.
static inline float3 pq_to_nits(float3 e) {
    const float m1 = 0.1593017578125, m2 = 78.84375;
    const float c1 = 0.8359375, c2 = 18.8515625, c3 = 18.6875;
    float3 p = pow(max(e, 0.0), 1.0 / m2);
    float3 l = pow(max(p - c1, 0.0) / (c2 - c3 * p), 1.0 / m1);
    return l * 10000.0;
}

/// Soft-knee roll-off that is linear below 75 % of `peak` and approaches `peak`
/// asymptotically above it. Applied to max(R,G,B) so hue is preserved.
static inline float3 tone_map(float3 c, float peak) {
    float m = max(max(c.r, c.g), c.b);
    float knee = 0.75 * peak;
    if (m <= knee || m <= 0.0) return c;
    float range = peak - knee;
    float mapped = knee + range * (1.0 - exp(-(m - knee) / range));
    return c * (mapped / m);
}

/// Inverse PQ: absolute nits → non-linear [0,1].
static inline float nits_to_pq(float nits) {
    const float m1 = 0.1593017578125, m2 = 78.84375;
    const float c1 = 0.8359375, c2 = 18.8515625, c3 = 18.6875;
    float y = pow(max(nits, 0.0) / 10000.0, m1);
    return pow((c1 + c2 * y) / (1.0 + c3 * y), m2);
}

static inline float pq_to_nits1(float e) {
    const float m1 = 0.1593017578125, m2 = 78.84375;
    const float c1 = 0.8359375, c2 = 18.8515625, c3 = 18.6875;
    float p = pow(max(e, 0.0), 1.0 / m2);
    return pow(max(p - c1, 0.0) / (c2 - c3 * p), 1.0 / m1) * 10000.0;
}

/// ITU-R BT.2390 EETF: compresses highlights from the game's mastering peak to the display
/// peak with a Hermite knee in PQ space, so bright detail (sun, neon, explosions) keeps its
/// gradation instead of clipping. Works on max(R,G,B) in nits; hue is preserved.
static inline float3 tone_map_2390(float3 nits, float sourcePeakNits, float targetPeakNits) {
    float m = max(max(nits.r, nits.g), nits.b);
    if (m <= 0.0) return nits;
    if (sourcePeakNits <= targetPeakNits) return m > targetPeakNits ? nits * (targetPeakNits / m) : nits;
    float srcPQ = nits_to_pq(sourcePeakNits);
    float e = nits_to_pq(m) / srcPQ;                    // 0…1 relative to the source peak
    float maxLum = nits_to_pq(targetPeakNits) / srcPQ;
    float ks = 1.5 * maxLum - 0.5;
    float e2 = e;
    if (e > ks) {
        float t = (e - ks) / (1.0 - ks);
        float t2 = t * t, t3 = t2 * t;
        e2 = (2.0 * t3 - 3.0 * t2 + 1.0) * ks + (t3 - 2.0 * t2 + t) * (1.0 - ks) + (-2.0 * t3 + 3.0 * t2) * maxLum;
    }
    float mapped = pq_to_nits1(min(e2, 1.0) * srcPQ);
    return nits * (mapped / m);
}

static inline float3 bt2020_to_bt709(float3 c) {
    const float3x3 m = float3x3(float3( 1.6605, -0.1246, -0.0182),
                                float3(-0.5876,  1.1329, -0.1006),
                                float3(-0.0728, -0.0083,  1.1187));
    return m * c;
}

static inline float luma709(float3 c) { return dot(c, float3(0.2126, 0.7152, 0.0722)); }

/// Picture mode / sliders on a display-referred (gamma-encoded) value. Mirrors
/// PictureAdjustments.apply in Swift. Shadow lift raises dark tones with a luma gamma that
/// fades out by the mid-tones, so blacks open up without greying the highlights.
static inline float3 adjust_picture(float3 c, float4 picture, float shadowLift) {
    float l = luma709(c);
    if (shadowLift > 0.0 && l > 0.0) {
        float lifted = pow(l, 1.0 / (1.0 + 0.7 * shadowLift));
        float target = mix(lifted, l, smoothstep(0.25, 0.75, l));
        c *= target / l;
    }
    c += picture.x;
    c = (c - 0.5) * picture.y + 0.5;
    float l2 = luma709(c);
    c = l2 + (c - l2) * picture.z;
    float warm = picture.w * 0.08;
    c *= float3(1.0 + warm, 1.0, 1.0 - warm);
    return c;
}

/// Converts the pipeline's working value (gamma-encoded SDR or PQ-encoded HDR) to what the
/// render target expects.
static inline bool picture_is_neutral(constant ComposeUniforms &u) {
    return all(u.picture == float4(0.0, 1.0, 1.0, 0.0)) && u.extra.x <= 0.0;
}

static inline float3 finish_color(float3 c, constant ComposeUniforms &u) {
    if (u.transferMode == 0) {
        if (!picture_is_neutral(u)) c = saturate(adjust_picture(c, u.picture, u.extra.x));
        return u.decodeToLinear != 0 ? srgb_to_linear(c) : c;
    }
    float white = max(u.referenceWhiteNits, 1.0);
    float sourcePeak = u.extra.w > 0.0 ? u.extra.w : 1000.0;   // HDR10 metadata, else typical game peak
    float3 nits = pq_to_nits(c);
    float3 linear;
    if (u.transferMode == 1) {
        linear = tone_map_2390(nits, sourcePeak, white * max(u.headroom, 1.0)) / white;   // EDR, still BT.2020
    } else {
        // SDR display: keep a little room above reference white for the roll-off.
        linear = saturate(bt2020_to_bt709(tone_map_2390(nits, sourcePeak, white * 1.0) / white));
    }
    if (!picture_is_neutral(u)) {
        // Adjust in a gamma-like domain so sliders feel the same as SDR; values above 1 (EDR) survive.
        float3 g = pow(max(linear, 0.0), 1.0 / 2.2);
        linear = pow(max(adjust_picture(g, u.picture, u.extra.x), 0.0), 2.2);
        if (u.transferMode != 1) linear = saturate(linear);
    }
    return u.decodeToLinear != 0 ? linear : linear_to_srgb(linear);
}

// MARK: - Pass 1: Y'CbCr → RGB at source resolution

kernel void ycbcr_to_rgb(texture2d<float, access::read>   lumaTexture   [[texture(0)]],
                         texture2d<float, access::sample> chromaTexture [[texture(1)]],
                         texture2d<half,  access::write>  outTexture    [[texture(2)]],
                         constant ColorConversion &cc [[buffer(0)]],
                         uint2 gid [[thread_position_in_grid]])
{
    if (gid.x >= outTexture.get_width() || gid.y >= outTexture.get_height()) return;
    constexpr sampler chromaSampler(coord::normalized, address::clamp_to_edge, filter::linear);
    float2 uv = (float2(gid) + 0.5) / float2(outTexture.get_width(), outTexture.get_height());
    float y = lumaTexture.read(gid).r;
    float2 cbcr = chromaTexture.sample(chromaSampler, uv).rg;
    outTexture.write(half4(half3(ycbcr_to_rgb_value(y, cbcr, cc)), 1.0h), gid);
}

// MARK: - Pass 1b (optional): deblock / deband before upscaling
//
// Streaming compression leaves blocks and banding in flat, dark areas (night skies, fog,
// shadows). Upscaling and sharpening would enlarge them. For each pixel, neighbours at
// radius 2 and 4 that are within a small threshold of it (i.e. the area is flat) are
// averaged in; real edges and texture exceed the threshold and are left untouched.
// A tiny ordered dither breaks up remaining bands.

kernel void deblock(texture2d<half, access::read>  inTexture  [[texture(0)]],
                    texture2d<half, access::write> outTexture [[texture(1)]],
                    constant float &strength [[buffer(0)]],
                    uint2 gid [[thread_position_in_grid]])
{
    uint W = inTexture.get_width(), H = inTexture.get_height();
    if (gid.x >= W || gid.y >= H) return;
    float3 c = float3(inTexture.read(gid).rgb);
    float lc = dot(c, float3(0.2126, 0.7152, 0.0722));
    // Darker pixels get a lower threshold in absolute terms but artifacts there are more visible.
    float threshold = mix(0.012, 0.03, saturate(lc));
    const int2 offsets[16] = {
        int2(-2, 0), int2(2, 0), int2(0, -2), int2(0, 2), int2(-2, -2), int2(2, 2), int2(-2, 2), int2(2, -2),
        int2(-4, 0), int2(4, 0), int2(0, -4), int2(0, 4), int2(-4, -4), int2(4, 4), int2(-4, 4), int2(4, -4)
    };
    float3 sum = c;
    float weight = 1.0;
    for (int i = 0; i < 16; i++) {
        int2 p = clamp(int2(gid) + offsets[i], int2(0), int2(W - 1, H - 1));
        float3 n = float3(inTexture.read(uint2(p)).rgb);
        float d = max(max(fabs(n.r - c.r), fabs(n.g - c.g)), fabs(n.b - c.b));
        float w = saturate(1.0 - d / threshold);
        sum += n * w;
        weight += w;
    }
    float3 smoothed = sum / weight;
    // 4×4 Bayer dither, ±0.5 of a 10-bit step, only where smoothing happened.
    const float bayer[16] = { 0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5 };
    float dither = (bayer[(gid.y % 4) * 4 + (gid.x % 4)] / 16.0 - 0.5) / 1023.0;
    float amount = strength * saturate((weight - 1.0) / 8.0);
    float3 result = mix(c, smoothed + dither, amount);
    outTexture.write(half4(half3(result), 1.0h), gid);
}

// MARK: - Pass 2 (fallback / Balanced): separable resampling

static inline float catmull_rom(float x) {
    x = fabs(x);
    if (x < 1.0) return 1.5 * x * x * x - 2.5 * x * x + 1.0;
    if (x < 2.0) return -0.5 * x * x * x + 2.5 * x * x - 4.0 * x + 2.0;
    return 0.0;
}

static inline float sinc(float x) {
    if (fabs(x) < 1e-5) return 1.0;
    float px = M_PI_F * x;
    return sin(px) / px;
}

static inline float lanczos3(float x) {
    x = fabs(x);
    return x < 3.0 ? sinc(x) * sinc(x / 3.0) : 0.0;
}

kernel void resample_separable(texture2d<half, access::read>  inTexture  [[texture(0)]],
                               texture2d<half, access::write> outTexture [[texture(1)]],
                               constant ScaleUniforms &u [[buffer(0)]],
                               uint2 gid [[thread_position_in_grid]])
{
    if (gid.x >= outTexture.get_width() || gid.y >= outTexture.get_height()) return;

    const bool horizontal = u.horizontal != 0;
    const float srcLen = horizontal ? u.sourceSize.x : u.sourceSize.y;
    const float dstLen = horizontal ? u.destSize.x : u.destSize.y;
    const float dstPos = horizontal ? float(gid.x) : float(gid.y);
    const float scale = srcLen / dstLen;
    // When minifying, widen the kernel to avoid aliasing.
    const float filterScale = max(scale, 1.0);
    const float center = (dstPos + 0.5) * scale - 0.5;
    const float radius = u.support * filterScale;
    const int first = int(floor(center - radius)) + 1;
    const int last = int(floor(center + radius));
    const int maxIndex = int(srcLen) - 1;

    float4 sum = 0.0;
    float weightSum = 0.0;
    for (int i = first; i <= last; ++i) {
        float x = (float(i) - center) / filterScale;
        float w = u.filter == 0 ? catmull_rom(x) : lanczos3(x);
        int clamped = clamp(i, 0, maxIndex);
        uint2 coord = horizontal ? uint2(clamped, gid.y) : uint2(gid.x, clamped);
        sum += float4(inTexture.read(coord)) * w;
        weightSum += w;
    }
    float4 result = weightSum != 0.0 ? sum / weightSum : float4(0.0);
    // Clamp to the [0,1] range: negative lobes would otherwise ring on hard edges.
    outTexture.write(half4(saturate(result)), gid);
}

// MARK: - Final pass: compose (letterbox + contrast-adaptive sharpening)

struct FullscreenVertex {
    float4 position [[position]];
    float2 uv;
};

vertex FullscreenVertex fullscreen_vertex(uint vid [[vertex_id]]) {
    // One oversized triangle covering the viewport.
    float2 positions[3] = { float2(-1.0, -1.0), float2(3.0, -1.0), float2(-1.0, 3.0) };
    FullscreenVertex out;
    out.position = float4(positions[vid], 0.0, 1.0);
    out.uv = float2((positions[vid].x + 1.0) * 0.5, 1.0 - (positions[vid].y + 1.0) * 0.5);
    return out;
}

/// Contrast-adaptive sharpening (after AMD FidelityFX CAS, MIT licence), cross-shaped 3×3.
/// The negative lobe is scaled by local contrast so flat or already high-contrast regions
/// receive less sharpening, which limits halos and amplification of compression noise.
static inline float3 cas_sample(texture2d<half, access::sample> tex, sampler s, float2 uv, float2 texel,
                                float peakDenominator, float amount, bool smart, float textClarity) {
    float3 b = float3(tex.sample(s, uv + float2( 0.0, -texel.y)).rgb);
    float3 d = float3(tex.sample(s, uv + float2(-texel.x,  0.0)).rgb);
    float3 e = float3(tex.sample(s, uv).rgb);
    float3 f = float3(tex.sample(s, uv + float2( texel.x,  0.0)).rgb);
    float3 h = float3(tex.sample(s, uv + float2( 0.0,  texel.y)).rgb);

    float3 mn = min(min(min(d, e), min(f, b)), h);
    float3 mx = max(max(max(d, e), max(f, b)), h);

    // Amplitude: how far the neighbourhood is from clipping, per channel.
    float3 amp = saturate(min(mn, 1.0 - mx) / max(mx, 1e-4));
    amp = sqrt(amp);
    float3 w = -amp / peakDenominator;          // negative lobe weight in [-1/peak, 0]

    // Edge-aware: full strength on edges, ~35 % on flat areas (skin, sky), so compression
    // noise isn't brought out. Text: hard, low-saturation edges (menus, maps, subtitles)
    // get extra strength, up to the maximum lobe.
    float edge = max(fabs(luma709(b) - luma709(h)), fabs(luma709(d) - luma709(f)));
    if (smart) amount *= mix(0.35, 1.0, smoothstep(0.03, 0.15, edge));
    if (textClarity > 0.0) {
        float chroma = max(max(e.r, e.g), e.b) - min(min(e.r, e.g), e.b);
        float textMask = smoothstep(0.25, 0.5, edge) * (1.0 - smoothstep(0.1, 0.3, chroma));
        amount = saturate(amount + textClarity * textMask * 0.6);
        w = mix(w, float3(-1.0 / 5.0), textClarity * textMask * 0.5);
    }
    float3 sharpened = (b * w + d * w + f * w + h * w + e) / (1.0 + 4.0 * w);
    return mix(e, saturate(sharpened), amount);
}

/// Letterbox handling. Returns false when the pixel is inside a bar that should be black.
static inline bool apply_bars(thread float2 &local, constant ComposeUniforms &u) {
    float top = u.bars.x, bottom = u.bars.y;
    if (u.barsMode == 0 || (top <= 0.0 && bottom <= 0.0)) return true;
    if (u.barsMode == 1) return local.y >= top && local.y <= 1.0 - bottom;
    // Zoom to fill: scale about the active picture's centre so it fills the height (sides crop).
    float active = max(1.0 - top - bottom, 0.1);
    float2 centre = float2(0.5, top + active * 0.5);
    local = centre + (local - 0.5) * active;
    return true;
}

fragment half4 compose_fragment(FullscreenVertex in [[stage_in]],
                                texture2d<half, access::sample> content [[texture(0)]],
                                texture2d<half, access::sample> original [[texture(1)]],
                                constant ComposeUniforms &u [[buffer(0)]])
{
    float2 local = (in.uv - u.contentRect.xy) / u.contentRect.zw;
    if (any(local < 0.0) || any(local > 1.0)) return half4(0.0h, 0.0h, 0.0h, 1.0h);
    float split = u.extra.z;
    float splitX = local.x;   // before zoom, so the divider stays put on screen
    if (!apply_bars(local, u)) return half4(0.0h, 0.0h, 0.0h, 1.0h);

    constexpr sampler linearSampler(coord::normalized, address::clamp_to_edge, filter::linear);
    float3 color;
    if (split > 0.0 && splitX < split) {
        // Before/after compare: left side is the raw stream, plainly scaled (bilinear), with
        // no clean-up or sharpening. Picture-mode adjustments still apply to both sides.
        color = float3(original.sample(linearSampler, local).rgb);
    } else if (u.sharpenAmount > 0.0 || u.extra.y > 0.0) {
        // Strength is encoded in casPeakDenominator; sharpenAmount fades in the first
        // few percent so that 1 % is not a sudden jump from 0 %.
        float2 texel = 1.0 / u.contentSize;
        color = cas_sample(content, linearSampler, local, texel, u.casPeakDenominator,
                           saturate(u.sharpenAmount * 10.0), u.smartSharpen != 0, u.extra.y);
    } else {
        color = float3(content.sample(linearSampler, local).rgb);
    }
    float3 result = finish_color(color, u);
    if (split > 0.0 && fabs(splitX - split) < 0.0012) result = float3(1.0, 1.0, 1.0) * (u.decodeToLinear != 0 ? 0.8 : 0.9);
    return half4(half3(result), 1.0h);
}

/// Performance mode: Y'CbCr conversion and bilinear scaling straight into the target.
fragment half4 compose_yuv_fragment(FullscreenVertex in [[stage_in]],
                                    texture2d<float, access::sample> lumaTexture   [[texture(0)]],
                                    texture2d<float, access::sample> chromaTexture [[texture(1)]],
                                    constant ComposeUniforms &u [[buffer(0)]],
                                    constant ColorConversion &cc [[buffer(1)]])
{
    float2 local = (in.uv - u.contentRect.xy) / u.contentRect.zw;
    if (any(local < 0.0) || any(local > 1.0)) return half4(0.0h, 0.0h, 0.0h, 1.0h);
    if (!apply_bars(local, u)) return half4(0.0h, 0.0h, 0.0h, 1.0h);
    constexpr sampler linearSampler(coord::normalized, address::clamp_to_edge, filter::linear);
    float y = lumaTexture.sample(linearSampler, local).r;
    float2 cbcr = chromaTexture.sample(linearSampler, local).rg;
    float3 color = ycbcr_to_rgb_value(y, cbcr, cc);
    return half4(half3(finish_color(color, u)), 1.0h);
}

// MARK: - Test pattern (used by unit tests and the "no signal" screen)

kernel void test_pattern(texture2d<half, access::write> outTexture [[texture(0)]],
                         constant float &time [[buffer(0)]],
                         uint2 gid [[thread_position_in_grid]])
{
    if (gid.x >= outTexture.get_width() || gid.y >= outTexture.get_height()) return;
    float2 uv = float2(gid) / float2(outTexture.get_width(), outTexture.get_height());
    float bar = floor(uv.x * 8.0);
    float3 bars[8] = { float3(1,1,1), float3(1,1,0), float3(0,1,1), float3(0,1,0),
                       float3(1,0,1), float3(1,0,0), float3(0,0,1), float3(0,0,0) };
    float3 c = bars[int(clamp(bar, 0.0, 7.0))] * 0.75;
    if (uv.y > 0.8) c = float3(fract(uv.x * 4.0 + time));
    outTexture.write(half4(half3(c), 1.0h), gid);
}
