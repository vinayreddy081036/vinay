import Foundation

/// Process-wide Chiaki initialisation and log routing.
enum ChiakiRuntime {
    private static let initResult: ChiakiErrorCode = {
        // Chiaki log levels: DEBUG=1, VERBOSE=2, INFO=4, WARNING=8, ERROR=16.
        let mask: UInt32 = 1 | 4 | 8 | 16
        vp_set_log_callback({ level, message, _ in
            guard let message else { return }
            let text = String(cString: message)
            let mapped: DiagnosticsLog.Entry.Level
            switch level {
            case 16: mapped = .error
            case 8: mapped = .warning
            case 4: mapped = .info
            default: mapped = .debug
            }
            vpLog(mapped, "chiaki", text)
        }, nil, mask)
        // Mozilla CA bundle (from certifi) for libcurl's HTTPS/WSS connections to PSN.
        if let caPath = Bundle.main.path(forResource: "cacert", ofType: "pem") {
            vp_set_ca_bundle_path(caPath)
        }
        return vp_lib_init()
    }()

    /// Initialises Chiaki once. Returns a readable error if the core failed to start.
    @discardableResult
    static func ensureInitialized() -> Result<Void, ConnectionError> {
        let err = initResult
        if err == CHIAKI_ERR_SUCCESS { return .success(()) }
        return .failure(.network("Remote Play core failed to initialise (\(ChiakiRuntime.describe(err)))"))
    }

    static func describe(_ err: ChiakiErrorCode) -> String {
        guard let cString = vp_error_string(err) else { return "error \(err.rawValue)" }
        return String(cString: cString)
    }
}

extension ConnectionError {
    /// Maps low-level Chiaki error codes to user-facing errors.
    static func from(chiaki err: ChiakiErrorCode, context: String) -> ConnectionError {
        switch err {
        case CHIAKI_ERR_HOST_DOWN, CHIAKI_ERR_HOST_UNREACH:
            return .network("\(context): console unreachable")
        case CHIAKI_ERR_CONNECTION_REFUSED:
            return .network("\(context): connection refused")
        case CHIAKI_ERR_TIMEOUT:
            return .network("\(context): timed out")
        case CHIAKI_ERR_PARSE_ADDR:
            return .network("\(context): invalid IP address")
        case CHIAKI_ERR_INVALID_MAC, CHIAKI_ERR_INVALID_RESPONSE:
            return .authenticationFailed(context)
        case CHIAKI_ERR_VERSION_MISMATCH:
            return .unsupportedStream("\(context): protocol version mismatch")
        default:
            return .network("\(context): \(ChiakiRuntime.describe(err))")
        }
    }
}
