import Foundation

/// Asks PSN which game the signed-in account is playing, so the matching game profile can
/// be applied automatically. Best effort: this uses PSN's public presence endpoint with the
/// Remote Play sign-in token, and Sony may not grant that token presence access — in which
/// case it quietly returns nil and profiles stay manual. Untested against a real account.
enum GamePresence {
    static func currentTitle(accessToken: String, accountID: Data, session: URLSession = .shared) async -> String? {
        guard accountID.count == 8 else { return nil }
        let value = accountID.withUnsafeBytes { $0.loadUnaligned(as: UInt64.self) }.littleEndian
        var components = URLComponents(string: "https://m.np.playstation.com/api/userProfile/v1/internal/users/\(value)/basicPresences")!
        components.queryItems = [URLQueryItem(name: "type", value: "primary")]
        guard let url = components.url else { return nil }
        var request = URLRequest(url: url, timeoutInterval: 8)
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        guard let (data, response) = try? await session.data(for: request),
              (response as? HTTPURLResponse)?.statusCode == 200 else { return nil }
        return parseTitle(data)
    }

    /// Pulls the first title name out of a basicPresences response.
    static func parseTitle(_ data: Data) -> String? {
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        let presence = (json["basicPresence"] as? [String: Any]) ?? json
        guard let titles = presence["gameTitleInfoList"] as? [[String: Any]] else { return nil }
        for title in titles {
            if let name = title["titleName"] as? String, !name.isEmpty { return name }
        }
        return nil
    }
}
