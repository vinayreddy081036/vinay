import Foundation
import Observation

/// A visible, step-by-step record of what VisionPlay does when signing in to PlayStation
/// Network. Secrets are never recorded: codes and tokens are shortened to their first
/// characters, and the password is never seen by the app at all.
@Observable
@MainActor
final class PSNSignInTrace {
    struct Step: Identifiable, Equatable {
        enum Status: String { case running = "…", done = "✓", failed = "✕", info = "•" }
        let id = UUID()
        let date: Date
        var status: Status
        let title: String
        let detail: String
    }

    static let shared = PSNSignInTrace()
    private(set) var steps: [Step] = []

    func clear() { steps.removeAll() }

    func record(_ status: Step.Status, _ title: String, _ detail: String = "") {
        steps.append(Step(date: Date(), status: status, title: title, detail: detail))
        if steps.count > 100 { steps.removeFirst(steps.count - 100) }
    }

    /// Thread-safe entry point for non-main-actor code.
    nonisolated static func log(_ status: Step.Status, _ title: String, _ detail: String = "") {
        Task { @MainActor in shared.record(status, title, detail) }
        vpLog(status == .failed ? .warning : .info, "psn", "\(title)\(detail.isEmpty ? "" : " — \(detail)")")
    }

    /// "v3.AbCdEf…(43 chars)" — enough to recognise, useless to anyone else.
    nonisolated static func redact(_ secret: String) -> String {
        guard secret.count > 6 else { return "••••" }
        return "\(secret.prefix(4))…(\(secret.count) chars)"
    }
}
