import Foundation
import Observation

/// Registered consoles (non-secret metadata in UserDefaults, secrets in Keychain).
@Observable
final class ConsoleStore {
    private static let storageKey = "vp.consoles.registered"

    @ObservationIgnored private let defaults: UserDefaults
    @ObservationIgnored let keychain: KeychainStore

    private(set) var consoles: [RegisteredConsole] = []

    init(defaults: UserDefaults = .standard, keychain: KeychainStore = KeychainStore()) {
        self.defaults = defaults
        self.keychain = keychain
        load()
    }

    private func load() {
        guard let data = defaults.data(forKey: Self.storageKey),
              let decoded = try? JSONDecoder().decode([RegisteredConsole].self, from: data) else {
            consoles = []
            return
        }
        consoles = decoded.sorted { $0.registeredAt < $1.registeredAt }
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(consoles) {
            defaults.set(data, forKey: Self.storageKey)
        }
    }

    /// Read-only snapshot for App Intents (Shortcuts may ask before the app UI exists).
    static func loadSaved(defaults: UserDefaults = .standard) -> [RegisteredConsole] {
        guard let data = defaults.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([RegisteredConsole].self, from: data) else { return [] }
        return decoded.sorted { $0.registeredAt < $1.registeredAt }
    }

    func console(id: String) -> RegisteredConsole? {
        consoles.first { $0.id == id }
    }

    /// Adds or replaces a console and stores its credentials in the Keychain.
    func register(_ console: RegisteredConsole, credentials: ConsoleCredentials) throws {
        try keychain.saveCredentials(credentials, consoleID: console.id)
        if let index = consoles.firstIndex(where: { $0.id == console.id }) {
            consoles[index] = console
        } else {
            consoles.append(console)
        }
        persist()
    }

    func updateAddress(consoleID: String, address: String) {
        guard let index = consoles.firstIndex(where: { $0.id == consoleID }),
              consoles[index].lastKnownAddress != address else { return }
        consoles[index].lastKnownAddress = address
        persist()
    }

    func setPSNDevice(consoleID: String, deviceID: String?) {
        guard let index = consoles.firstIndex(where: { $0.id == consoleID }) else { return }
        consoles[index].psnDeviceID = deviceID
        persist()
    }

    func rename(consoleID: String, to nickname: String) {
        guard let index = consoles.firstIndex(where: { $0.id == consoleID }) else { return }
        consoles[index].nickname = nickname
        persist()
    }

    /// Removes the console and deletes its Keychain credentials.
    func remove(consoleID: String) throws {
        try keychain.deleteCredentials(consoleID: consoleID)
        consoles.removeAll { $0.id == consoleID }
        persist()
    }

    func credentials(for consoleID: String) throws -> ConsoleCredentials? {
        try keychain.credentials(consoleID: consoleID)
    }
}
