import Foundation

/// Obtains the 8-byte PSN account ID that PS5 registration requires.
///
/// The flow mirrors chiaki-ng's (based on grill2010's script): the user signs in to
/// Sony's own login page in an embedded web view, Sony redirects to the Remote Play
/// redirect URL with an authorization `code`, the code is exchanged for an access token,
/// and the token-info endpoint returns the numeric `user_id`. The account ID is that
/// number as 8 little-endian bytes, Base64-encoded.
///
/// The account ID and the OAuth refresh token are stored in the Keychain. The refresh token
/// is what internet Remote Play needs to obtain short-lived access tokens; the user's
/// password never passes through VisionPlay code.
enum PSNAccountService {
    static let clientID = "ba495a24-818c-472b-b12d-ff231c1b5745"
    static let clientSecret = "mvaiZkRsAsI1IBkY"
    static let redirectURI = "https://remoteplay.dl.playstation.net/remoteplay/redirect"
    static let tokenURL = URL(string: "https://auth.api.sonyentertainmentnetwork.com/2.0/oauth/token")!
    static let scope = "psn:clientapp referenceDataService:countryConfig.read pushNotification:webSocket.desktop.connect sessionManager:remotePlaySession.system.update"

    enum ServiceError: Error, LocalizedError, Equatable {
        case noCode
        case http(Int)
        case malformedResponse
        case invalidUserID

        var errorDescription: String? {
            switch self {
            case .noCode: return "Sony did not return an authorization code."
            case .http(let code): return "Sony's server returned HTTP \(code)."
            case .malformedResponse: return "Unexpected response from Sony's server."
            case .invalidUserID: return "Sony returned an invalid account number."
            }
        }
    }

    static var loginURL: URL {
        var components = URLComponents(string: "https://auth.api.sonyentertainmentnetwork.com/2.0/oauth/authorize")!
        components.queryItems = [
            URLQueryItem(name: "service_entity", value: "urn:service-entity:psn"),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "client_id", value: clientID),
            URLQueryItem(name: "redirect_uri", value: redirectURI),
            URLQueryItem(name: "scope", value: scope),
            URLQueryItem(name: "request_locale", value: "en_US"),
            URLQueryItem(name: "ui", value: "pr"),
            URLQueryItem(name: "service_logo", value: "ps"),
            URLQueryItem(name: "layout_type", value: "popup"),
            URLQueryItem(name: "smcid", value: "remoteplay"),
            URLQueryItem(name: "prompt", value: "always"),
            URLQueryItem(name: "PlatformPrivacyWs1", value: "minimal"),
        ]
        return components.url!
    }

    /// Accepts what the user pastes for QR/code sign-in: the full redirect address from the
    /// phone ("https://remoteplay.dl.playstation.net/remoteplay/redirect?code=…"), just the
    /// query ("code=…&cid=…"), or the bare code itself.
    static func extractCode(from input: String) -> String? {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        if trimmed.contains("code=") {
            let query = trimmed.contains("?") ? String(trimmed[trimmed.index(after: trimmed.firstIndex(of: "?")!)...]) : trimmed
            var components = URLComponents()
            components.percentEncodedQuery = query
            if let code = components.queryItems?.first(where: { $0.name == "code" })?.value, !code.isEmpty {
                return code
            }
            return nil
        }
        // A bare code: no spaces or URL punctuation, sensible length.
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_.~"))
        guard trimmed.count >= 4, trimmed.count <= 512,
              trimmed.unicodeScalars.allSatisfy({ allowed.contains($0) }) else { return nil }
        return trimmed
    }

    /// Returns the authorization code if `url` is Sony's redirect after login.
    static func authorizationCode(fromRedirect url: URL) -> String? {
        guard url.absoluteString.hasPrefix(redirectURI),
              let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems else { return nil }
        return items.first { $0.name == "code" }?.value
    }

    /// Converts Sony's decimal `user_id` to the Remote Play account ID bytes (8 bytes, little endian).
    static func accountIDBytes(fromUserID userID: String) -> Data? {
        guard let value = UInt64(userID.trimmingCharacters(in: .whitespaces)) else { return nil }
        var littleEndian = value.littleEndian
        return withUnsafeBytes(of: &littleEndian) { Data($0) }
    }

    static func accountIDBase64(fromUserID userID: String) -> String? {
        accountIDBytes(fromUserID: userID)?.base64EncodedString()
    }

    private static var basicAuthHeader: String {
        "Basic " + Data("\(clientID):\(clientSecret)".utf8).base64EncodedString()
    }

    struct Tokens: Equatable, Sendable {
        var accessToken: String
        var refreshToken: String
        var expiresAt: Date
    }

    struct LoginResult: Equatable, Sendable {
        var accountID: Data
        var tokens: Tokens
    }

    /// Exchanges the redirect `code` for tokens and the account ID.
    static func completeLogin(code: String, session: URLSession = .shared) async throws -> LoginResult {
        PSNSignInTrace.log(.done, "Received a one-time sign-in code from Sony", PSNSignInTrace.redact(code))
        PSNSignInTrace.log(.running, "Exchanging the code for tokens", "POST auth.api.sonyentertainmentnetwork.com/2.0/oauth/token")
        let tokens: Tokens
        do {
            tokens = try await requestTokens(grant: [
                URLQueryItem(name: "grant_type", value: "authorization_code"),
                URLQueryItem(name: "code", value: code),
            ], session: session)
        } catch {
            PSNSignInTrace.log(.failed, "Sony did not accept the code", "\(error.localizedDescription) — codes work once and expire after a few minutes")
            throw error
        }
        PSNSignInTrace.log(.done, "Got an access token and a refresh token",
                           "access \(PSNSignInTrace.redact(tokens.accessToken)), valid until \(tokens.expiresAt.formatted(date: .omitted, time: .shortened))")
        PSNSignInTrace.log(.running, "Reading your PSN account number", "GET …/2.0/oauth/token/<access token>")
        let accountID: Data
        do {
            accountID = try await fetchAccountID(accessToken: tokens.accessToken, session: session)
        } catch {
            PSNSignInTrace.log(.failed, "Could not read the account number", error.localizedDescription)
            throw error
        }
        PSNSignInTrace.log(.done, "Account ID for Remote Play", accountID.base64EncodedString() + " (8-byte number, little-endian, Base64)")
        return LoginResult(accountID: accountID, tokens: tokens)
    }

    /// Gets a fresh access token from a stored refresh token.
    static func refresh(refreshToken: String, session: URLSession = .shared) async throws -> Tokens {
        var tokens = try await requestTokens(grant: [
            URLQueryItem(name: "grant_type", value: "refresh_token"),
            URLQueryItem(name: "refresh_token", value: refreshToken),
        ], session: session)
        if tokens.refreshToken.isEmpty { tokens.refreshToken = refreshToken }
        return tokens
    }

    private static func requestTokens(grant: [URLQueryItem], session: URLSession) async throws -> Tokens {
        var request = URLRequest(url: tokenURL)
        request.httpMethod = "POST"
        request.setValue(basicAuthHeader, forHTTPHeaderField: "Authorization")
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        var form = URLComponents()
        form.queryItems = grant + [
            URLQueryItem(name: "scope", value: scope),
            URLQueryItem(name: "redirect_uri", value: redirectURI),
        ]
        request.httpBody = form.percentEncodedQuery?.data(using: .utf8)
        let (data, response) = try await session.data(for: request)
        try check(response)
        return try parseTokens(data, now: Date())
    }

    static func parseTokens(_ data: Data, now: Date) throws -> Tokens {
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let access = json["access_token"] as? String else { throw ServiceError.malformedResponse }
        let refresh = json["refresh_token"] as? String ?? ""
        let expiresIn = (json["expires_in"] as? NSNumber)?.doubleValue ?? 3600
        // Refresh a minute early so a token never expires mid-connection.
        return Tokens(accessToken: access, refreshToken: refresh, expiresAt: now.addingTimeInterval(max(60, expiresIn - 60)))
    }

    static func fetchAccountID(accessToken: String, session: URLSession = .shared) async throws -> Data {
        var infoRequest = URLRequest(url: tokenURL.appendingPathComponent(accessToken))
        infoRequest.setValue(basicAuthHeader, forHTTPHeaderField: "Authorization")
        infoRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let (infoData, infoResponse) = try await session.data(for: infoRequest)
        try check(infoResponse)
        guard let infoJSON = try JSONSerialization.jsonObject(with: infoData) as? [String: Any] else {
            throw ServiceError.malformedResponse
        }
        let userID: String
        if let string = infoJSON["user_id"] as? String { userID = string }
        else if let number = infoJSON["user_id"] as? NSNumber { userID = number.stringValue }
        else { throw ServiceError.malformedResponse }
        guard let bytes = accountIDBytes(fromUserID: userID) else { throw ServiceError.invalidUserID }
        return bytes
    }

    private static func check(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { throw ServiceError.malformedResponse }
        guard (200..<300).contains(http.statusCode) else { throw ServiceError.http(http.statusCode) }
    }
}

/// Keeps the PSN refresh token in the Keychain and hands out valid access tokens.
actor PSNTokenStore {
    static let shared = PSNTokenStore()
    private let keychain: KeychainStore
    private var cached: PSNAccountService.Tokens?
    private static let refreshAccount = "psn.refreshToken"

    init(keychain: KeychainStore = KeychainStore()) {
        self.keychain = keychain
    }

    nonisolated var hasRefreshToken: Bool {
        (try? keychain.data(account: Self.refreshAccount)) != nil
    }

    func save(_ tokens: PSNAccountService.Tokens) throws {
        cached = tokens
        if !tokens.refreshToken.isEmpty {
            try keychain.setData(Data(tokens.refreshToken.utf8), account: Self.refreshAccount)
            PSNSignInTrace.log(.done, "Refresh token saved in the Keychain", "this device only, never synced")
        }
    }

    func signOut() throws {
        cached = nil
        try keychain.delete(account: Self.refreshAccount)
        PSNSignInTrace.log(.info, "Signed out", "refresh token deleted from the Keychain")
    }

    enum TokenError: Error, LocalizedError {
        case notSignedIn
        var errorDescription: String? { "Sign in to PlayStation Network first (Internet Play)." }
    }

    /// A valid access token, refreshed when needed.
    func accessToken() async throws -> String {
        if let cached, cached.expiresAt > Date() { return cached.accessToken }
        guard let data = try keychain.data(account: Self.refreshAccount),
              let refreshToken = String(data: data, encoding: .utf8), !refreshToken.isEmpty else {
            throw TokenError.notSignedIn
        }
        PSNSignInTrace.log(.running, "Renewing the PSN access token", "using the refresh token from the Keychain")
        do {
            let tokens = try await PSNAccountService.refresh(refreshToken: refreshToken)
            try save(tokens)
            PSNSignInTrace.log(.done, "Access token renewed", "valid until \(tokens.expiresAt.formatted(date: .omitted, time: .shortened))")
            return tokens.accessToken
        } catch {
            PSNSignInTrace.log(.failed, "Token renewal failed", "\(error.localizedDescription) — sign in again")
            throw error
        }
    }
}
