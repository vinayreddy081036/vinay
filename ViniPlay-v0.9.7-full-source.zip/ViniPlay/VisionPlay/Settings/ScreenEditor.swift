import Foundation
import Observation

/// A Size/Distance change in progress. While you drag, the draft drives the preview
/// drawing and the glowing outline in the room; the game picture moves only when you let go.
@Observable
final class ScreenEditor {
    /// Draft values while a slider is held (nil when nothing is being dragged).
    private(set) var draftWidth: Double?
    private(set) var draftDistance: Double?
    private(set) var isDragging = false

    /// Values to show: the draft while dragging, otherwise the committed settings.
    func width(_ settings: AppSettings) -> Double { draftWidth ?? settings.customWidth }
    func distance(_ settings: AppSettings) -> Double {
        let d = draftDistance ?? settings.customDistance
        // Same rule as the settings: a big screen can't sit in your face.
        return max(d, AppSettings.minimumDistance(forWidth: width(settings)))
    }
    func angle(_ settings: AppSettings) -> Double {
        AppSettings.viewAngle(width: width(settings), distance: distance(settings))
    }

    func begin(_ settings: AppSettings) {
        guard !isDragging else { return }
        isDragging = true
        draftWidth = settings.customWidth
        draftDistance = settings.customDistance
    }

    func setWidth(_ value: Double, _ settings: AppSettings) {
        if !isDragging { begin(settings) }
        draftWidth = min(max(value, AppSettings.customWidthRange.lowerBound), AppSettings.customWidthRange.upperBound)
    }

    func setDistance(_ value: Double, _ settings: AppSettings) {
        if !isDragging { begin(settings) }
        draftDistance = min(max(value, AppSettings.customDistanceRange.lowerBound), AppSettings.customDistanceRange.upperBound)
    }

    /// Let go: apply the draft (the screen then glides there).
    func commit(_ settings: AppSettings) {
        guard isDragging else { return }
        let width = width(settings), distance = distance(settings)
        settings.customWidth = width
        settings.customDistance = distance
        draftWidth = nil
        draftDistance = nil
        isDragging = false
    }

    /// Quick buttons apply straight away.
    func apply(width: Double? = nil, distance: Double? = nil, _ settings: AppSettings) {
        if let width { settings.customWidth = width }
        if let distance { settings.customDistance = distance }
    }
}
