import Foundation
import Observation

enum StreamResolution: Int, CaseIterable, Identifiable, Codable, Sendable {
    // Raw values match ChiakiVideoResolutionPreset.
    case p360 = 1, p540 = 2, p720 = 3, p1080 = 4
    var id: Int { rawValue }
    var label: String {
        switch self {
        case .p360: return "360p"
        case .p540: return "540p"
        case .p720: return "720p"
        case .p1080: return "1080p"
        }
    }
    var size: (width: Int, height: Int) {
        switch self {
        case .p360: return (640, 360)
        case .p540: return (960, 540)
        case .p720: return (1280, 720)
        case .p1080: return (1920, 1080)
        }
    }
}

enum StreamCodec: Int, CaseIterable, Identifiable, Codable, Sendable {
    // Raw values match ChiakiCodec.
    case h264 = 0, hevc = 1, hevcHDR = 2
    var id: Int { rawValue }
    var label: String {
        switch self {
        case .h264: return "H.264"
        case .hevc: return "HEVC"
        case .hevcHDR: return "HEVC HDR"
        }
    }
}

enum DisplayShape: String, CaseIterable, Identifiable, Codable, Sendable {
    case flat = "Flat"
    case curved = "Curved"
    var id: String { rawValue }
}

extension AppSettings {
    /// The bitrate asked of the PS5 (kbps): the manual setting if set, else the Network Mode's.
    func requestedBitrate(for resolution: StreamResolution) -> UInt32? {
        customBitrateMbps > 0 ? UInt32(customBitrateMbps * 1000) : networkMode.bitrate(for: resolution)
    }
}

enum NetworkMode: String, CaseIterable, Identifiable, Codable, Sendable {
    case automatic = "Automatic"
    case lowLatency = "Low Latency"
    case highQuality = "High Quality"
    var id: String { rawValue }

    /// Bitrate override in kbps (nil = Chiaki preset default for the resolution).
    func bitrate(for resolution: StreamResolution) -> UInt32? {
        switch self {
        case .automatic: return nil
        case .lowLatency:
            return resolution == .p1080 ? 10_000 : nil
        case .highQuality:
            return resolution == .p1080 ? 25_000 : nil
        }
    }
}

/// Ordinary (non-secret) preferences, persisted in UserDefaults.
/// Credentials are never stored here — see `KeychainStore`.
@Observable
final class AppSettings {
    enum Key {
        static let resolution = "vp.stream.resolution"
        static let fps = "vp.stream.fps"
        static let codec = "vp.stream.codec"
        static let upscalingEnabled = "vp.upscale.enabled"
        static let upscaleMode = "vp.upscale.mode"
        static let outputTarget = "vp.upscale.output"
        static let sharpening = "vp.upscale.sharpening"
        static let displayShape = "vp.display.shape"
        static let screenWidthMeters = "vp.display.widthMeters"
        static let viewingDistance = "vp.display.distance"
        static let screenHeightOffset = "vp.display.heightOffset"
        static let curvature = "vp.display.curvature"
        static let darkEnvironment = "vp.display.dark"
        static let networkMode = "vp.network.mode"
        static let reconnection = "vp.network.reconnect"
        static let volume = "vp.audio.volume"
        static let showStats = "vp.ui.stats"
        static let motionControls = "vp.controller.motion"
        static let hapticsEnabled = "vp.controller.vibration"
        static let hapticsIntensity = "vp.controller.hapticsIntensity"
        static let hdrHeadroom = "vp.display.hdrHeadroom"
        static let screenHorizontalOffset = "vp.display.horizontalOffset"
        static let adaptiveQuality = "vp.network.adaptive"
        static let resumeAfterHeadsetOff = "vp.network.resume"
        static let internetFixedPorts = "vp.network.fixedPorts"
        static let internetControlPort = "vp.network.controlPort"
        static let internetDataPort = "vp.network.dataPort"
        static let spatialAudio = "vp.audio.spatial"
        static let roomAcoustics = "vp.audio.room"
        static let surroundUpmix = "vp.audio.upmix"
        static let smoothMotion = "vp.display.smoothMotion"
        static let cinemaRoom = "vp.display.cinemaRoom"
        static let instantReplay = "vp.capture.instantReplay"
        static let deblock = "vp.video.deblock"
        static let lowLatency = "vp.stream.lowLatency"
        static let pinScreenToRoom = "vp.display.pinToRoom"
        static let pictureMode = "vp.picture.mode"
        static let picture = "vp.picture.adjustments"
        static let textClarity = "vp.picture.textClarity"
        static let smartSharpening = "vp.picture.smartSharpening"
        static let blackBars = "vp.picture.blackBars"
        static let all: [String] = [resolution, fps, codec, upscalingEnabled, upscaleMode, outputTarget,
                                    sharpening, displayShape, screenWidthMeters, viewingDistance,
                                    screenHeightOffset, curvature, darkEnvironment, networkMode,
                                    reconnection, volume, showStats, motionControls, hapticsEnabled,
                                    hapticsIntensity, hdrHeadroom, screenHorizontalOffset, adaptiveQuality,
                                    resumeAfterHeadsetOff, internetFixedPorts, internetControlPort, internetDataPort,
                                    spatialAudio, roomAcoustics, surroundUpmix, smoothMotion, cinemaRoom, instantReplay,
                                    deblock, lowLatency, pinScreenToRoom,
                                    pictureMode, picture, textClarity, smartSharpening, blackBars]
    }

    enum Defaults {
        static let resolution = StreamResolution.p1080
        static let fps = 60
        static let codec = StreamCodec.hevc
        static let upscalingEnabled = true
        static let upscaleMode = UpscaleMode.quality
        static let outputTarget = OutputTarget.uhd4K
        static let sharpening = 0.35
        static let displayShape = DisplayShape.flat
        static let screenWidthMeters = 3.0
        static let viewingDistance = 3.5
        static let screenHeightOffset = 0.0
        static let curvature = 0.35
        static let darkEnvironment = true
        static let networkMode = NetworkMode.highQuality
        static let reconnection = true
        static let volume = 1.0
        static let showStats = false
        static let motionControls = false
        static let hapticsEnabled = false   // Controller Vibration starts off
        static let hapticsIntensity = 1.0
        /// Peak HDR brightness relative to SDR white (EDR headroom) used for tone mapping.
        static let hdrHeadroom = 2.0
        static let screenHorizontalOffset = 0.0
        static let adaptiveQuality = true
        static let resumeAfterHeadsetOff = true
        static let internetFixedPorts = false
        static let internetControlPort = 9320
        static let internetDataPort = 9321
        static let spatialAudio = true
        static let roomAcoustics = false
        static let surroundUpmix = false
        static let smoothMotion = true
        static let cinemaRoom = false
        static let instantReplay = false
        static let deblock = 0.15
        static let lowLatency = false
        static let pinScreenToRoom = true
        static let textClarity = 0.3
        static let smartSharpening = true
        static let blackBars = BlackBarsMode.darken
    }

    @ObservationIgnored private let defaults: UserDefaults

    var manualNativeWidth: Double? { didSet { defaults.set(manualNativeWidth, forKey: "vp.display.manualNativeWidth") } }
    var neuralUpscaling = true { didSet { defaults.set(neuralUpscaling, forKey: "vp.picture.neural") } }
    /// Manual bitrate in Mbps (2…100); 0 = use the Network Mode's choice.
    var customBitrateMbps: Int = 0 { didSet { defaults.set(customBitrateMbps, forKey: "vp.stream.customBitrate") } }
    /// 120 fps frame generation (off by default: adds about 8 ms of delay).
    var frameGeneration = false { didSet { defaults.set(frameGeneration, forKey: "vp.video.frameGeneration") } }
    var imaxScale: Double = 1 { didSet { defaults.set(imaxScale, forKey: "vp.display.imaxScale") } }
    /// Where you moved Custom Screen's settings panel (x, y, z in metres); nil = on your left.
    var screenPanelPosition: [Double]? { didSet { defaults.set(screenPanelPosition, forKey: "vp.display.panelPosition") } }
    /// Where the Cinema screen sits around you: [turn left/right, tilt up/down] in radians.
    /// nil = straight ahead. Set by pinching the screen and dragging it.
    var cinemaScreenAngles: [Double]? { didSet { defaults.set(cinemaScreenAngles, forKey: "vp.cinema.screenAngles") } }
    var resolution: StreamResolution { didSet { defaults.set(resolution.rawValue, forKey: Key.resolution) } }
    var fps: Int { didSet { defaults.set(fps, forKey: Key.fps) } }
    var codec: StreamCodec { didSet { defaults.set(codec.rawValue, forKey: Key.codec) } }
    var upscalingEnabled: Bool { didSet { defaults.set(upscalingEnabled, forKey: Key.upscalingEnabled) } }
    var upscaleMode: UpscaleMode { didSet { defaults.set(upscaleMode.rawValue, forKey: Key.upscaleMode) } }
    var outputTarget: OutputTarget { didSet { defaults.set(outputTarget.rawValue, forKey: Key.outputTarget) } }
    /// 0…1, shown to the user as a percentage. Default 0.35 (35 %).
    var sharpening: Double { didSet { defaults.set(sharpening, forKey: Key.sharpening) } }
    var displayShape: DisplayShape { didSet { defaults.set(displayShape.rawValue, forKey: Key.displayShape) } }
    var screenWidthMeters: Double { didSet { defaults.set(screenWidthMeters, forKey: Key.screenWidthMeters) } }
    var viewingDistance: Double { didSet { defaults.set(viewingDistance, forKey: Key.viewingDistance) } }
    var screenHeightOffset: Double { didSet { defaults.set(screenHeightOffset, forKey: Key.screenHeightOffset) } }
    var curvature: Double { didSet { defaults.set(curvature, forKey: Key.curvature) } }
    var darkEnvironment: Bool { didSet { defaults.set(darkEnvironment, forKey: Key.darkEnvironment) } }
    var networkMode: NetworkMode { didSet { defaults.set(networkMode.rawValue, forKey: Key.networkMode) } }
    var reconnection: Bool { didSet { defaults.set(reconnection, forKey: Key.reconnection) } }
    var volume: Double { didSet { defaults.set(volume, forKey: Key.volume) } }
    var showStats: Bool { didSet { defaults.set(showStats, forKey: Key.showStats) } }
    /// Experimental: forward DualSense gyro/accelerometer to the console.
    var motionControls: Bool { didSet { defaults.set(motionControls, forKey: Key.motionControls) } }
    /// Play the PS5's DualSense haptics stream on the controller.
    var hapticsEnabled: Bool { didSet { defaults.set(hapticsEnabled, forKey: Key.hapticsEnabled) } }
    var hapticsIntensity: Double { didSet { defaults.set(hapticsIntensity, forKey: Key.hapticsIntensity) } }
    var hdrHeadroom: Double { didSet { defaults.set(hdrHeadroom, forKey: Key.hdrHeadroom) } }
    /// Theater screen placement (sideways), saved between sessions.
    var screenHorizontalOffset: Double { didSet { defaults.set(screenHorizontalOffset, forKey: Key.screenHorizontalOffset) } }
    /// Step quality down automatically on a struggling connection (and back up when it's clean).
    var adaptiveQuality: Bool { didSet { defaults.set(adaptiveQuality, forKey: Key.adaptiveQuality) } }
    /// Reconnect automatically when the headset is put back on after a stream was interrupted.
    var resumeAfterHeadsetOff: Bool { didSet { defaults.set(resumeAfterHeadsetOff, forKey: Key.resumeAfterHeadsetOff) } }
    /// Internet Play: bind to fixed UDP ports that are forwarded on the router.
    var internetFixedPorts: Bool { didSet { defaults.set(internetFixedPorts, forKey: Key.internetFixedPorts) } }
    var internetControlPort: Int { didSet { defaults.set(internetControlPort, forKey: Key.internetControlPort) } }
    var internetDataPort: Int { didSet { defaults.set(internetDataPort, forKey: Key.internetDataPort) } }
    /// Game sound placed at the virtual screen, head-tracked.
    var spatialAudio: Bool { didSet { defaults.set(spatialAudio, forKey: Key.spatialAudio) } }
    /// Subtle room reverb sized to the screen (living room → auditorium).
    var roomAcoustics: Bool { didSet { defaults.set(roomAcoustics, forKey: Key.roomAcoustics) } }
    /// Soft rear ambience made from the stereo signal (an effect, not real surround).
    var surroundUpmix: Bool { didSet { defaults.set(surroundUpmix, forKey: Key.surroundUpmix) } }
    /// Present frames in step with the display (120 Hz where available) instead of immediately.
    var smoothMotion: Bool { didSet { defaults.set(smoothMotion, forKey: Key.smoothMotion) } }
    /// Theater: a dark cinema auditorium (walls, seats, screen glow) instead of the plain backdrop.
    var cinemaRoom: Bool { didSet { defaults.set(cinemaRoom, forKey: Key.cinemaRoom) } }
    /// Keep the last 30 s ready to save as a clip (uses the hardware video encoder while streaming).
    var instantReplay: Bool { didSet { defaults.set(instantReplay, forKey: Key.instantReplay) } }
    /// Compression clean-up before upscaling: 0 off, 0.5 light (default), 1 strong.
    var deblock: Double { didSet { defaults.set(deblock, forKey: Key.deblock) } }
    /// Competitive mode: 60 FPS, no display pacing, fastest scaling, smallest audio buffer.
    var lowLatency: Bool { didSet { defaults.set(lowLatency, forKey: Key.lowLatency) } }
    /// Theater: keep the screen where you put it in your room (ARKit world anchor).
    var pinScreenToRoom: Bool { didSet { defaults.set(pinScreenToRoom, forKey: Key.pinScreenToRoom) } }
    /// Picture preset; moving any slider switches it to Custom (see `setPicture`).
    var pictureMode: PictureMode { didSet { defaults.set(pictureMode.rawValue, forKey: Key.pictureMode) } }
    private(set) var picture: PictureAdjustments {
        didSet { defaults.set(try? JSONEncoder().encode(picture), forKey: Key.picture) }
    }
    /// Extra sharpening for menus, maps and subtitles (0…1).
    var textClarity: Double { didSet { defaults.set(textClarity, forKey: Key.textClarity) } }
    var smartSharpening: Bool { didSet { defaults.set(smartSharpening, forKey: Key.smartSharpening) } }
    var blackBars: BlackBarsMode { didSet { defaults.set(blackBars.rawValue, forKey: Key.blackBars) } }

    func applyPictureMode(_ mode: PictureMode) {
        pictureMode = mode
        if let preset = mode.adjustments { picture = preset }
    }

    /// Slider edits: changes the value and marks the mode Custom.
    func setPicture(_ change: (inout PictureAdjustments) -> Void) {
        var p = picture
        change(&p)
        picture = p.clamped()
        if let preset = pictureMode.adjustments, preset != picture { pictureMode = .custom }
    }

    /// Profiles restore exact values without changing them to Custom.
    func restorePicture(mode: PictureMode, adjustments: PictureAdjustments) {
        picture = adjustments.clamped()
        pictureMode = mode
    }

    /// What actually applies after Low-Latency Mode overrides.
    /// Frame pacing is always on: without it a 60 fps stream on a 90 Hz display hitches
    /// every 2–3 frames.
    var effectiveSmoothMotion: Bool { true }
    var effectiveFPS: Int { lowLatency ? 60 : fps }
    var audioBufferMilliseconds: Double { lowLatency ? 40 : 100 }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        resolution = StreamResolution(rawValue: defaults.object(forKey: Key.resolution) as? Int ?? -1) ?? Defaults.resolution
        let storedFPS = defaults.object(forKey: Key.fps) as? Int ?? Defaults.fps
        fps = (storedFPS == 30 || storedFPS == 60) ? storedFPS : Defaults.fps
        codec = StreamCodec(rawValue: defaults.object(forKey: Key.codec) as? Int ?? -1) ?? Defaults.codec
        upscalingEnabled = defaults.object(forKey: Key.upscalingEnabled) as? Bool ?? Defaults.upscalingEnabled
        upscaleMode = UpscaleMode(rawValue: defaults.string(forKey: Key.upscaleMode) ?? "") ?? Defaults.upscaleMode
        outputTarget = OutputTarget(rawValue: defaults.string(forKey: Key.outputTarget) ?? "") ?? Defaults.outputTarget
        sharpening = Self.clamp(defaults.object(forKey: Key.sharpening) as? Double ?? Defaults.sharpening, 0, 1)
        displayShape = DisplayShape(rawValue: defaults.string(forKey: Key.displayShape) ?? "") ?? Defaults.displayShape
        screenWidthMeters = Self.clamp(defaults.object(forKey: Key.screenWidthMeters) as? Double ?? Defaults.screenWidthMeters, Self.screenWidthRange.lowerBound, Self.screenWidthRange.upperBound)
        viewingDistance = Self.clamp(defaults.object(forKey: Key.viewingDistance) as? Double ?? Defaults.viewingDistance, Self.viewingDistanceRange.lowerBound, Self.viewingDistanceRange.upperBound)
        screenHeightOffset = Self.clamp(defaults.object(forKey: Key.screenHeightOffset) as? Double ?? Defaults.screenHeightOffset, -2, 3)
        curvature = Self.clamp(defaults.object(forKey: Key.curvature) as? Double ?? Defaults.curvature, 0, 1)
        darkEnvironment = defaults.object(forKey: Key.darkEnvironment) as? Bool ?? Defaults.darkEnvironment
        networkMode = NetworkMode(rawValue: defaults.string(forKey: Key.networkMode) ?? "") ?? Defaults.networkMode
        reconnection = defaults.object(forKey: Key.reconnection) as? Bool ?? Defaults.reconnection
        volume = Self.clamp(defaults.object(forKey: Key.volume) as? Double ?? Defaults.volume, 0, 1)
        showStats = defaults.object(forKey: Key.showStats) as? Bool ?? Defaults.showStats
        motionControls = defaults.object(forKey: Key.motionControls) as? Bool ?? Defaults.motionControls
        hapticsEnabled = defaults.object(forKey: Key.hapticsEnabled) as? Bool ?? Defaults.hapticsEnabled
        hapticsIntensity = Self.clamp(defaults.object(forKey: Key.hapticsIntensity) as? Double ?? Defaults.hapticsIntensity, 0, 2)
        hdrHeadroom = Self.clamp(defaults.object(forKey: Key.hdrHeadroom) as? Double ?? Defaults.hdrHeadroom, 1, 8)
        screenHorizontalOffset = Self.clamp(defaults.object(forKey: Key.screenHorizontalOffset) as? Double ?? Defaults.screenHorizontalOffset, -6, 6)
        adaptiveQuality = defaults.object(forKey: Key.adaptiveQuality) as? Bool ?? Defaults.adaptiveQuality
        resumeAfterHeadsetOff = defaults.object(forKey: Key.resumeAfterHeadsetOff) as? Bool ?? Defaults.resumeAfterHeadsetOff
        internetFixedPorts = defaults.object(forKey: Key.internetFixedPorts) as? Bool ?? Defaults.internetFixedPorts
        internetControlPort = Self.validPort(defaults.object(forKey: Key.internetControlPort) as? Int, Defaults.internetControlPort)
        internetDataPort = Self.validPort(defaults.object(forKey: Key.internetDataPort) as? Int, Defaults.internetDataPort)
        spatialAudio = defaults.object(forKey: Key.spatialAudio) as? Bool ?? Defaults.spatialAudio
        roomAcoustics = defaults.object(forKey: Key.roomAcoustics) as? Bool ?? Defaults.roomAcoustics
        surroundUpmix = defaults.object(forKey: Key.surroundUpmix) as? Bool ?? Defaults.surroundUpmix
        smoothMotion = defaults.object(forKey: Key.smoothMotion) as? Bool ?? Defaults.smoothMotion
        cinemaRoom = defaults.object(forKey: Key.cinemaRoom) as? Bool ?? Defaults.cinemaRoom
        instantReplay = defaults.object(forKey: Key.instantReplay) as? Bool ?? Defaults.instantReplay
        deblock = Self.clamp(defaults.object(forKey: Key.deblock) as? Double ?? Defaults.deblock, 0, 1)
        // Low-Latency Mode was removed (it switched off frame pacing). Clear an old saved value.
        lowLatency = false
        defaults.set(false, forKey: Key.lowLatency)
        pinScreenToRoom = defaults.object(forKey: Key.pinScreenToRoom) as? Bool ?? Defaults.pinScreenToRoom
        pictureMode = (defaults.string(forKey: Key.pictureMode)).flatMap(PictureMode.init(rawValue:)) ?? .standard
        picture = (defaults.data(forKey: Key.picture)).flatMap { try? JSONDecoder().decode(PictureAdjustments.self, from: $0) }?.clamped()
            ?? PictureAdjustments()
        textClarity = Self.clamp(defaults.object(forKey: Key.textClarity) as? Double ?? Defaults.textClarity, 0, 1)
        smartSharpening = defaults.object(forKey: Key.smartSharpening) as? Bool ?? Defaults.smartSharpening
        blackBars = (defaults.string(forKey: Key.blackBars)).flatMap(BlackBarsMode.init(rawValue:)) ?? Defaults.blackBars
        manualNativeWidth = (defaults.object(forKey: "vp.display.manualNativeWidth") as? Double).map { Self.clamp($0, 480, 8192) }
        if !defaults.bool(forKey: "vp.display.nativeWindowSizing") {
            manualNativeWidth = 1280
            defaults.set(1280.0, forKey: "vp.display.manualNativeWidth")
            defaults.set(true, forKey: "vp.display.nativeWindowSizing")
        }
        neuralUpscaling = defaults.object(forKey: "vp.picture.neural") as? Bool ?? true
        frameGeneration = defaults.bool(forKey: "vp.video.frameGeneration")
        let savedBitrate = defaults.integer(forKey: "vp.stream.customBitrate")
        customBitrateMbps = savedBitrate == 0 ? 0 : min(max(savedBitrate, 2), 100)
        imaxScale = Self.clamp(defaults.object(forKey: "vp.display.imaxScale") as? Double ?? 1, 0.5, 6)
        screenPanelPosition = (defaults.array(forKey: "vp.display.panelPosition") as? [Double]).flatMap { $0.count == 3 ? $0 : nil }
        cinemaScreenAngles = (defaults.array(forKey: "vp.cinema.screenAngles") as? [Double]).flatMap { $0.count == 2 ? $0 : nil }
        if abs(screenWidthMeters - 22) < 0.01 { screenWidthMeters = ScreenSize.imaxWidthMeters }
        if !defaults.bool(forKey: "vp.display.centerRayRepair") {
            screenHorizontalOffset = 0
            screenHeightOffset = 0
            pinScreenToRoom = false
            defaults.set(true, forKey: "vp.display.centerRayRepair")
        }
        if !defaults.bool(forKey: "vp.picture.qualitySeatUpgrade") {
            useHighQualityPicture()
            pinScreenToRoom = false
            defaults.set(true, forKey: "vp.picture.qualitySeatUpgrade")
        }
    }

    private static func validPort(_ value: Int?, _ fallback: Int) -> Int {
        guard let value, (1024...65535).contains(value) else { return fallback }
        return value
    }

    /// Restores every preference to its default. Registered consoles and Keychain
    /// credentials are not touched.
    func reset() {
        for key in Key.all { defaults.removeObject(forKey: key) }
        manualNativeWidth = nil
        imaxScale = 1
        neuralUpscaling = true
        frameGeneration = false
        customBitrateMbps = 0
        screenPanelPosition = nil
        cinemaScreenAngles = nil
        resolution = Defaults.resolution
        fps = Defaults.fps
        codec = Defaults.codec
        upscalingEnabled = Defaults.upscalingEnabled
        upscaleMode = Defaults.upscaleMode
        outputTarget = Defaults.outputTarget
        sharpening = Defaults.sharpening
        displayShape = Defaults.displayShape
        screenWidthMeters = Defaults.screenWidthMeters
        viewingDistance = Defaults.viewingDistance
        screenHeightOffset = Defaults.screenHeightOffset
        curvature = Defaults.curvature
        darkEnvironment = Defaults.darkEnvironment
        networkMode = Defaults.networkMode
        reconnection = Defaults.reconnection
        volume = Defaults.volume
        showStats = Defaults.showStats
        motionControls = Defaults.motionControls
        hapticsEnabled = Defaults.hapticsEnabled
        hapticsIntensity = Defaults.hapticsIntensity
        hdrHeadroom = Defaults.hdrHeadroom
        screenHorizontalOffset = Defaults.screenHorizontalOffset
        adaptiveQuality = Defaults.adaptiveQuality
        resumeAfterHeadsetOff = Defaults.resumeAfterHeadsetOff
        internetFixedPorts = Defaults.internetFixedPorts
        internetControlPort = Defaults.internetControlPort
        internetDataPort = Defaults.internetDataPort
        spatialAudio = Defaults.spatialAudio
        roomAcoustics = Defaults.roomAcoustics
        surroundUpmix = Defaults.surroundUpmix
        smoothMotion = Defaults.smoothMotion
        cinemaRoom = Defaults.cinemaRoom
        instantReplay = Defaults.instantReplay
        deblock = Defaults.deblock
        lowLatency = Defaults.lowLatency
        pinScreenToRoom = Defaults.pinScreenToRoom
        pictureMode = .standard
        picture = PictureAdjustments()
        textClarity = Defaults.textClarity
        smartSharpening = Defaults.smartSharpening
        blackBars = Defaults.blackBars
    }

    /// Theater screen width (m): up to IMAX scale.
    /// Up to ~55 km: a 140° screen at 10 km.
    static let screenWidthRange: ClosedRange<Double> = 0.5...60000
    /// Viewing distance (m), chosen freely by the user.
    static let viewingDistanceRange: ClosedRange<Double> = 0.75...10000

    // MARK: Custom Screen — Size (real width) and Distance (how far back it sits)

    /// Size bar: the screen's real width in metres (a cinema screen is ~15–25 m, IMAX ~38 m).
    static let customWidthRange: ClosedRange<Double> = 1...2000
    /// Distance bar in metres.
    static let customDistanceRange: ClosedRange<Double> = 2...10000
    /// Never closer than this much of your view, so a big screen can't end up in your face.
    /// (140°: a 2 km screen can come as close as ~360 m.)
    static let maxComfortAngle: Double = 140

    /// Closest a screen of this width may sit (it then fills `maxComfortAngle` of your view).
    static func minimumDistance(forWidth width: Double) -> Double {
        max(customDistanceRange.lowerBound, width / (2 * tan(maxComfortAngle * .pi / 360)))
    }

    /// Size: the real width. Changing it keeps the distance, unless the screen would be so
    /// big it reaches your face — then it is pushed back just enough.
    var customWidth: Double {
        get { min(max(screenWidthMeters, Self.customWidthRange.lowerBound), Self.customWidthRange.upperBound) }
        set {
            let width = min(max(newValue, Self.customWidthRange.lowerBound), Self.customWidthRange.upperBound)
            screenWidthMeters = width
            let minimum = Self.minimumDistance(forWidth: width)
            if viewingDistance < minimum { viewingDistance = minimum }
        }
    }

    /// Distance: moves the same screen nearer or farther. The size never changes; farther
    /// away it looks smaller, like the back row of a cinema.
    var customDistance: Double {
        get { min(max(viewingDistance, Self.customDistanceRange.lowerBound), Self.customDistanceRange.upperBound) }
        set {
            let distance = min(max(newValue, Self.customDistanceRange.lowerBound), Self.customDistanceRange.upperBound)
            viewingDistance = max(distance, Self.minimumDistance(forWidth: customWidth))
        }
    }

    /// How much of your view it fills (for the labels and preview only).
    var viewAngleDegrees: Double { Self.viewAngle(width: customWidth, distance: customDistance) }

    static func viewAngle(width: Double, distance: Double) -> Double {
        2 * atan(width / (2 * max(distance, 0.01))) * 180 / .pi
    }

    static func describe(angle: Double) -> String {
        switch angle {
        case ..<10: return "far away"
        case ..<20: return "back row"
        case ..<30: return "TV across the room"
        case ..<45: return "middle of a cinema"
        case ..<70: return "front of a cinema"
        default: return "fills your view"
        }
    }

    /// Keeps a saved custom screen in range and out of your face.
    func normalizeCustomScreen() {
        let width = customWidth
        screenWidthMeters = width
        viewingDistance = max(min(max(viewingDistance, Self.customDistanceRange.lowerBound), Self.customDistanceRange.upperBound),
                              Self.minimumDistance(forWidth: width))
    }

    static func width(forAngle degrees: Double, distance: Double) -> Double {
        2 * distance * tan(degrees * .pi / 360)
    }

    /// The preset matching the current width, or `.custom`.
    var screenSize: ScreenSize {
        get { manualNativeWidth == nil ? ScreenSize.matching(widthMeters: screenWidthMeters) : .custom }
        set {
            if newValue == .custom { manualNativeWidth = nativeWindowWidth; return }
            manualNativeWidth = nil
            if let width = newValue.widthMeters { screenWidthMeters = width }
            if newValue != .imax {
                // Each size at its proper distance (55″ ≈ 2 m … 205″ ≈ 4.2 m).
                viewingDistance = newValue.seatDistance
            }
            if newValue == .imax {
                viewingDistance = ScreenSize.imaxViewingDistance
                screenHorizontalOffset = 0
                screenHeightOffset = 0
                displayShape = .flat
                pinScreenToRoom = false
            }
        }
    }

    /// The selected size describes its apparent width at a reference seat.
    /// Scale both axes with depth so distance changes preserve the viewing angle.
    var renderedScreenWidth: Double {
        let reference = screenSize.seatDistance
        return ScreenSize.apparentWidth(screenWidthMeters, distance: viewingDistance, reference: reference)
            * (screenSize == .imax ? imaxScale : 1)
    }

    func useHighQualityPicture() {
        resolution = .p1080
        fps = 60
        codec = .hevc
        networkMode = .highQuality
        adaptiveQuality = false
        lowLatency = false
        upscalingEnabled = true
        upscaleMode = .quality
        outputTarget = .uhd4K
        sharpening = 0.35
        textClarity = 0.3
        deblock = 0.15
        smartSharpening = true
    }

    /// A native window size request; physical placement and depth stay under OS control.
    var nativeWindowWidth: Double {
        if let manualNativeWidth { return min(8192, max(480, manualNativeWidth)) }
        // IMAX asks for the largest window (it used to ask for less than 205″).
        if screenSize == .imax { return min(8192, max(4096, 4096 * imaxScale)) }
        return min(8192, max(480, screenWidthMeters / 3 * 1920))
    }

    /// Snapshot used by the renderer (value type, safe to hand to other threads).
    var upscalerConfiguration: UpscalerConfiguration {
        var config: UpscalerConfiguration
        if lowLatency {
            // Fastest path: single-pass bilinear scale in the compose shader, no clean-up passes.
            config = UpscalerConfiguration(enabled: upscalingEnabled, mode: .performance, outputTarget: outputTarget,
                                           sharpening: 0, hdrHeadroom: Float(hdrHeadroom), deblockStrength: 0)
        } else {
            config = UpscalerConfiguration(enabled: upscalingEnabled, mode: upscaleMode, outputTarget: outputTarget,
                                           sharpening: Float(sharpening), hdrHeadroom: Float(hdrHeadroom),
                                           deblockStrength: Float(deblock))
            config.textClarity = Float(textClarity)
        }
        // Colour adjustments and letterbox handling are free (same pass), so they apply in every mode.
        config.picture = picture
        config.smartSharpening = smartSharpening
        config.blackBars = blackBars
        // Removed (they made gameplay lag): Apple AI upscaling and 120 FPS frame generation.
        // 4K upscaling uses the fast GPU path.
        config.neuralEnabled = false
        config.frameGeneration = false
        return config
    }

    private static func clamp(_ value: Double, _ lo: Double, _ hi: Double) -> Double {
        min(max(value, lo), hi)
    }
}
