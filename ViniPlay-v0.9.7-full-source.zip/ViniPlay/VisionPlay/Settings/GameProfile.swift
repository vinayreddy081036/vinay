import Foundation
import Observation

/// Per-game settings: screen, sound and picture. Pick one by hand, or let VisionPlay switch
/// automatically when the PS5 reports the game you launched (needs PSN sign-in; best effort).
struct GameProfile: Identifiable, Codable, Equatable, Sendable {
    var id = UUID()
    /// Game name as you'd say it, or as PSN reports it ("ASTRO BOT").
    var name: String
    var screenWidthMeters: Double
    var viewingDistance: Double
    var displayShape: DisplayShape
    var curvature: Double
    var spatialAudio: Bool
    var roomAcoustics: Bool
    var surroundUpmix: Bool
    var upscaleMode: UpscaleMode
    var sharpening: Double
    var deblock: Double
    var lowLatency: Bool
    var cinemaRoom: Bool
    /// Added in v0.6; nil in older profiles (picture left as it is).
    var pictureMode: PictureMode? = nil
    var picture: PictureAdjustments? = nil
    var textClarity: Double? = nil
    var blackBars: BlackBarsMode? = nil

    /// Loose name match so "Astro Bot" matches PSN's "ASTRO BOT™".
    static func normalized(_ name: String) -> String {
        name.lowercased().filter { $0.isLetter || $0.isNumber }
    }

    func matches(title: String) -> Bool {
        let a = Self.normalized(name), b = Self.normalized(title)
        return !a.isEmpty && (a == b || b.hasPrefix(a) || a.hasPrefix(b))
    }
}

extension AppSettings {
    func makeProfile(named name: String) -> GameProfile {
        GameProfile(name: name, screenWidthMeters: screenWidthMeters, viewingDistance: viewingDistance,
                    displayShape: displayShape, curvature: curvature, spatialAudio: spatialAudio,
                    roomAcoustics: roomAcoustics, surroundUpmix: surroundUpmix, upscaleMode: upscaleMode,
                    sharpening: sharpening, deblock: deblock, lowLatency: lowLatency, cinemaRoom: cinemaRoom,
                    pictureMode: pictureMode, picture: picture, textClarity: textClarity, blackBars: blackBars)
    }

    func apply(_ p: GameProfile) {
        manualNativeWidth = nil
        screenWidthMeters = p.screenWidthMeters
        viewingDistance = p.viewingDistance
        displayShape = p.displayShape
        curvature = p.curvature
        spatialAudio = p.spatialAudio
        roomAcoustics = p.roomAcoustics
        surroundUpmix = p.surroundUpmix
        upscaleMode = p.upscaleMode
        sharpening = p.sharpening
        deblock = p.deblock
        lowLatency = false   // Low-Latency Mode was removed
        cinemaRoom = p.cinemaRoom
        if let picture = p.picture { restorePicture(mode: p.pictureMode ?? .custom, adjustments: picture) }
        if let text = p.textClarity { textClarity = text }
        if let bars = p.blackBars { blackBars = bars }
    }
}

@Observable
final class GameProfileStore {
    private static let key = "vp.profiles"
    @ObservationIgnored private let defaults: UserDefaults
    private(set) var profiles: [GameProfile] = []
    /// The profile currently applied (nil = your normal settings).
    var activeID: UUID?

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let data = defaults.data(forKey: Self.key),
           let decoded = try? JSONDecoder().decode([GameProfile].self, from: data) {
            profiles = decoded
        }
    }

    var active: GameProfile? { profiles.first { $0.id == activeID } }

    func save(_ profile: GameProfile) {
        if let i = profiles.firstIndex(where: { $0.id == profile.id }) { profiles[i] = profile }
        else { profiles.append(profile) }
        persist()
    }

    func delete(_ id: UUID) {
        profiles.removeAll { $0.id == id }
        if activeID == id { activeID = nil }
        persist()
    }

    func profile(forTitle title: String) -> GameProfile? {
        profiles.first { $0.matches(title: title) }
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(profiles) { defaults.set(data, forKey: Self.key) }
    }
}
