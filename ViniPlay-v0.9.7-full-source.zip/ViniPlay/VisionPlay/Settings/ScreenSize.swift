import Foundation

/// Virtual screen size presets (16:9, measured diagonally like a real TV) for Theater mode.
enum ScreenSize: String, CaseIterable, Identifiable, Codable, Sendable {
    case in55 = "55″"
    case in65 = "65″"
    case in75 = "75″"
    case in85 = "85″"
    case in105 = "105″"
    case in125 = "125″"
    case in175 = "175″"
    case in205 = "205″"
    case imax = "IMAX"
    case custom = "Custom"

    var id: String { rawValue }

    /// Diagonal in inches (nil for IMAX/custom).
    var diagonalInches: Double? {
        switch self {
        case .in55: return 55
        case .in65: return 65
        case .in75: return 75
        case .in85: return 85
        case .in105: return 105
        case .in125: return 125
        case .in175: return 175
        case .in205: return 205
        case .imax, .custom: return nil
        }
    }

    /// Width of the 16:9 picture in metres.
    var widthMeters: Double? {
        if let diagonal = diagonalInches { return Self.width(forDiagonalInches: diagonal) }
        // Guinness-certified Leonberg screen dimensions; game content is fitted separately.
        if self == .imax { return Self.imaxWidthMeters }
        return nil
    }

    static let imaxWidthMeters = 38.8
    static let imaxHeightMeters = 21.0
    /// IMAX seat: close enough that it fills about 100° of your view — clearly bigger than
    /// any TV preset (it used to sit 34 m back, where it looked no bigger than a 175″).
    static let imaxViewingDistance = imaxWidthMeters / (2 * tan(50 * Double.pi / 180))
    /// Fallback seat for sizes without their own distance.
    static let tvSeatDistance = 3.5

    /// A sensible sofa distance for each TV size (about 34° of view for 55″, rising to
    /// ~57° for 205″), so every size sits at a proper distance and a bigger size still
    /// looks bigger.
    var seatDistance: Double {
        switch self {
        case .in55: return 2.0
        case .in65: return 2.2
        case .in75: return 2.4
        case .in85: return 2.6
        case .in105: return 2.9
        case .in125: return 3.2
        case .in175: return 3.8
        case .in205: return 4.2
        case .imax: return Self.imaxViewingDistance
        case .custom: return Self.tvSeatDistance
        }
    }

    static func apparentWidth(_ width: Double, distance: Double, reference: Double) -> Double {
        width * max(distance, 0.01) / max(reference, 0.01)
    }

    /// 16:9 width = diagonal × 16/√(16²+9²), converted from inches to metres.
    static func width(forDiagonalInches diagonal: Double) -> Double {
        diagonal * 0.0254 * 16 / (256.0 + 81.0).squareRoot()
    }

    static func diagonalInches(forWidthMeters width: Double) -> Double {
        width / 0.0254 * (256.0 + 81.0).squareRoot() / 16
    }

    /// Distance at which the screen fills about 40° of your view (THX-style recommendation).
    var recommendedDistance: Double? {
        widthMeters.map { Self.recommendedDistance(forWidthMeters: $0) }
    }

    static func recommendedDistance(forWidthMeters width: Double) -> Double {
        width / (2 * tan(20 * Double.pi / 180))
    }

    /// The preset matching a stored width (within 1 cm), else `.custom`.
    static func matching(widthMeters: Double) -> ScreenSize {
        allCases.first { preset in
            guard let w = preset.widthMeters else { return false }
            return abs(w - widthMeters) < 0.01
        } ?? .custom
    }

    var detail: String {
        guard let width = widthMeters else { return "Your own size" }
        let height = self == .imax ? Self.imaxHeightMeters : width * 9 / 16
        return String(format: "%.2f × %.2f m", width, height)
    }
}
