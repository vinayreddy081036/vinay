import SwiftUI
import UIKit
import Metal
import QuartzCore

/// Render target backed by a CAMetalLayer. Kept separate from the UIView so the render
/// queue can use it without touching main-actor-isolated UIKit state.
final class MetalLayerTarget: RenderTarget, @unchecked Sendable {
    let layer: CAMetalLayer
    private let sizeLock = NSLock()
    private var currentSize = (width: 0, height: 0)

    init(layer: CAMetalLayer, device: MTLDevice) {
        self.layer = layer
        layer.device = device
        // sRGB format: the compose pass outputs linear light and the hardware encodes it.
        layer.pixelFormat = .bgra8Unorm_srgb
        layer.framebufferOnly = true
        layer.maximumDrawableCount = 3
        layer.presentsWithTransaction = false
        layer.contentsGravity = .resizeAspect
        layer.isOpaque = true
    }

    private var hdrEnabled = false
    private var hdrApplied = false

    var pixelFormat: MTLPixelFormat {
        sizeLock.lock(); defer { sizeLock.unlock() }
        return hdrApplied ? .rgba16Float : .bgra8Unorm_srgb
    }
    var expectsLinear: Bool { true }
    var requiresMainThread: Bool { false }
    var supportsEDR: Bool {
        sizeLock.lock(); defer { sizeLock.unlock() }
        return hdrApplied
    }

    /// HDR: a float drawable in extended-linear BT.2020 with EDR enabled, so values above
    /// 1.0 (SDR white) are shown brighter on the Vision Pro's displays.
    func setHDR(_ enabled: Bool) {
        sizeLock.lock()
        let changed = hdrEnabled != enabled
        hdrEnabled = enabled
        sizeLock.unlock()
        guard changed else { return }
        let layer = self.layer
        let apply = { [weak self] in
            if enabled {
                layer.pixelFormat = .rgba16Float
                layer.colorspace = CGColorSpace(name: CGColorSpace.extendedLinearITUR_2020)
                layer.wantsExtendedDynamicRangeContent = true
            } else {
                layer.pixelFormat = .bgra8Unorm_srgb
                layer.colorspace = CGColorSpace(name: CGColorSpace.sRGB)
                layer.wantsExtendedDynamicRangeContent = false
            }
            guard let self else { return }
            self.sizeLock.lock(); self.hdrApplied = enabled; self.sizeLock.unlock()
        }
        if Thread.isMainThread { apply() } else { DispatchQueue.main.async(execute: apply) }
    }

    /// The drawable is sized to the requested output (e.g. 3840×2160) independent of the
    /// window's point size; the visionOS compositor then scales it to the window.
    func prepare(width: Int, height: Int) -> (width: Int, height: Int) {
        let w = min(max(width, 16), 8192)
        let h = min(max(height, 16), 8192)
        sizeLock.lock()
        let changed = currentSize.width != w || currentSize.height != h
        if changed { currentSize = (w, h) }
        sizeLock.unlock()
        if changed {
            let size = CGSize(width: w, height: h)
            let layer = self.layer
            if Thread.isMainThread {
                layer.drawableSize = size
            } else {
                DispatchQueue.main.async { layer.drawableSize = size }
            }
        }
        return (w, h)
    }

    func encode(commandBuffer: MTLCommandBuffer, draw: (MTLTexture) -> Void) -> Bool {
        guard let drawable = layer.nextDrawable() else { return false }
        draw(drawable.texture)
        commandBuffer.present(drawable)
        return true
    }
}

/// CAMetalLayer-backed view used for the windowed (flat) gameplay screen.
final class MetalLayerView: UIView {
    override class var layerClass: AnyClass { CAMetalLayer.self }
    private(set) var target: MetalLayerTarget!

    init(device: MTLDevice) {
        super.init(frame: .zero)
        target = MetalLayerTarget(layer: layer as! CAMetalLayer, device: device)
        backgroundColor = .black
        isUserInteractionEnabled = false
        // Rounded corners done by the layer itself: Core Animation's built-in corner radius
        // is a cheap GPU operation. (A SwiftUI clipShape on this view added an extra mask
        // pass to every frame, which made the game feel slightly laggy.)
        layer.cornerRadius = 46
        layer.cornerCurve = .continuous
        layer.masksToBounds = true
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
}

/// SwiftUI wrapper; the parent applies `.aspectRatio` so the stream is never distorted.
struct MetalStreamView: UIViewRepresentable {
    let renderer: StreamRenderer

    func makeUIView(context: Context) -> MetalLayerView {
        let view = MetalLayerView(device: renderer.device)
        renderer.attach(target: view.target)
        return view
    }

    func updateUIView(_ uiView: MetalLayerView, context: Context) {
        renderer.attach(target: uiView.target)
    }
}
