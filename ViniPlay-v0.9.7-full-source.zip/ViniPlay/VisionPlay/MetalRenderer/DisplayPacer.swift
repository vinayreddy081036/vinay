import UIKit
import Foundation
import QuartzCore

/// Drives presentation from the display's refresh instead of from decode completion.
///
/// A 60 FPS stream on a 90 Hz display can only be shown in an uneven 2-1-2-1 refresh
/// pattern, which reads as judder in camera pans. The pacer asks for 120 Hz (an even
/// multiple of 60) where the device allows it, and otherwise hands the renderer the newest
/// frame on each refresh so it is never shown late. The cost is at most one refresh of
/// extra latency (≈8–11 ms); "Smooth Motion" off restores present-on-decode.
final class DisplayPacer: NSObject {
    private var link: CADisplayLink?
    private weak var windowScene: UIWindowScene?

    func setWindowScene(_ scene: UIWindowScene) {
        guard windowScene !== scene else { return }
        let wasRunning = link != nil
        if wasRunning { stop() }
        windowScene = scene
        if wasRunning { start() }
    }
    private weak var renderer: StreamRenderer?
    private var lastTimestamp: CFTimeInterval = 0
    private var intervalAverage: Double = 0

    init(renderer: StreamRenderer) {
        self.renderer = renderer
    }

    /// Measured display refresh rate in Hz (0 until a few refreshes have passed).
    var measuredHz: Double { intervalAverage > 0 ? 1 / intervalAverage : 0 }

    func start() {
        guard link == nil else { return }
        let link: CADisplayLink
        if #available(visionOS 27.0, *), let sceneLink = windowScene?.displayLink(target: self, selector: #selector(tick(_:))) {
            link = sceneLink
        } else {
            link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        }
        link.preferredFrameRateRange = CAFrameRateRange(minimum: 60, maximum: 120, preferred: 120)
        link.add(to: .main, forMode: .common)
        self.link = link
        renderer?.setDisplayPaced(true)
        vpLog(.info, "render", "Smooth Motion: presenting on display refresh (requested 120 Hz)")
    }

    func stop() {
        link?.invalidate()
        link = nil
        renderer?.setDisplayPaced(false)
        intervalAverage = 0
        lastTimestamp = 0
    }

    @objc private func tick(_ link: CADisplayLink) {
        if lastTimestamp > 0 {
            let interval = link.timestamp - lastTimestamp
            if interval > 0.002 && interval < 0.05 {
                intervalAverage = intervalAverage == 0 ? interval : intervalAverage * 0.95 + interval * 0.05
            }
        }
        lastTimestamp = link.timestamp
        renderer?.displayTick(refreshHz: measuredHz)
    }
}
