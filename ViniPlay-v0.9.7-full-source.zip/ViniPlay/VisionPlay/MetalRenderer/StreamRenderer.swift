import Foundation
import Metal
import CoreVideo
import QuartzCore

/// Something the renderer can draw the final image into: a window's CAMetalLayer or a
/// RealityKit LowLevelTexture on the immersive curved screen.
protocol RenderTarget: AnyObject {
    /// Pixel format of the texture handed to `encodeFinalPass`.
    var pixelFormat: MTLPixelFormat { get }
    /// True when the target's pixel format expects linear light (sRGB or float formats).
    var expectsLinear: Bool { get }
    /// RealityKit textures must be replaced on the main actor.
    var requiresMainThread: Bool { get }
    /// Resize the backing store to the requested output size. Returns the size actually used.
    func prepare(width: Int, height: Int) -> (width: Int, height: Int)
    /// Supplies the destination texture for this frame and schedules presentation.
    /// Returns false if no texture was available (the frame is skipped).
    func encode(commandBuffer: MTLCommandBuffer, draw: (MTLTexture) -> Void) -> Bool
    /// Switches the target into (or out of) extended-dynamic-range output for HDR streams.
    func setHDR(_ enabled: Bool)
    /// True when the target currently displays values above SDR white (EDR).
    var supportsEDR: Bool { get }
}

extension RenderTarget {
    func setHDR(_ enabled: Bool) {}
    var supportsEDR: Bool { false }
}

/// Thread-safe rendering statistics for the HUD and diagnostics.
struct RenderStats: Sendable {
    var framesRendered: UInt64 = 0
    var framesDropped: UInt64 = 0
    var framesSkippedNoDrawable: UInt64 = 0
    var gpuMilliseconds: Double = 0
    var gpuMillisecondsAverage: Double = 0
    /// Decode submission → GPU completion (decode + queue + render).
    var pipelineLatencyMilliseconds: Double = 0
    var outputWidth: Int = 0
    var outputHeight: Int = 0
    var neuralStatus = "Spatial scaling"
    /// 120 fps frame generation status ("" when off).
    var frameGenStatus = ""
    var sourceWidth: Int = 0
    var sourceHeight: Int = 0
    var technique: ScalingTechnique = .none
    var presentedFPS: Double = 0
    var metalFXAvailable = false
    /// e.g. "BT.709" or "BT.2020 PQ (HDR10)".
    var colorDescription: String = "—"
    /// How HDR is being shown: "SDR", "HDR (EDR, headroom 2.0×)" or "HDR tone-mapped to SDR".
    var dynamicRange: String = "SDR"
    /// Smooth Motion: display refresh rate measured by the pacer (0 = present on decode).
    var displayRefreshHz: Double = 0
}

/// The GPU video pipeline. Frames arrive from the decoder on arbitrary threads; at most
/// `maxFramesInFlight` are on the GPU and at most one more waits. A newer frame always
/// replaces a waiting one, so latency cannot accumulate when the GPU or display falls behind.
final class StreamRenderer: @unchecked Sendable {
    let device: MTLDevice
    private let commandQueue: MTLCommandQueue
    private let library: MTLLibrary
    private let ycbcrPipeline: MTLComputePipelineState
    private let deblockPipeline: MTLComputePipelineState
    private var deblockTexture: MTLTexture?
    private var composePipelines: [MTLPixelFormat: MTLRenderPipelineState] = [:]
    private var composeYUVPipelines: [MTLPixelFormat: MTLRenderPipelineState] = [:]
    private let upscaler: SpatialUpscaler
    private var textureCache: CVMetalTextureCache?

    private let renderQueue = DispatchQueue(label: "VisionPlay.render", qos: .userInteractive)
    private let stateLock = NSLock()
    private let neural = LiveNeuralUpscaler()
    private let frameGen = FrameGenerator()
    private var lastPreparedTime: UInt64 = 0
    private var pending: PendingFrame?
    private var framesInFlight = 0
    private var displayPaced = false
    private let maxFramesInFlight = 1
    private var configuration = UpscalerConfiguration.default
    private weak var target: RenderTarget?
    private weak var windowTarget: RenderTarget?
    private weak var theaterTarget: RenderTarget?
    private var stats = RenderStats()
    private var fpsWindowStart = CACurrentMediaTime()
    private var fpsWindowCount = 0

    // Intermediate textures (render-queue / main-thread confined via `encodeLock`).
    private let encodeLock = NSLock()
    private var rgbTexture: MTLTexture?
    private var scaledTexture: MTLTexture?
    private var lastHDRRequest: Bool?
    /// The screen the HDR request was sent to: a new screen (e.g. the window rebuilt after
    /// Custom Screen closes) must be told again, even if the stream's HDR state didn't change.
    private weak var lastHDRTarget: AnyObject?
    private var lastFrame: CVPixelBuffer?
    /// Letterbox detection (fed from submit, read in renderNext).
    let letterbox = LetterboxDetector()
    /// Before/after compare: x position of the divider (0 = off). Set from the main thread.
    private var compareSplitValue: Float = 0
    var compareSplit: Float {
        get { stateLock.lock(); defer { stateLock.unlock() }; return compareSplitValue }
        set { stateLock.lock(); compareSplitValue = newValue; stateLock.unlock() }
    }
    /// Receives every decoded frame (Instant Replay encoder, cinema glow). Called on the decoder thread.
    var frameObserver: ((CVPixelBuffer) -> Void)?

    private struct PendingFrame {
        let pixelBuffer: CVPixelBuffer
        let submittedAt: UInt64
    }

    init(device: MTLDevice? = MTLCreateSystemDefaultDevice()) throws {
        guard let device, let queue = device.makeCommandQueue() else { throw RendererError.noDevice }
        self.device = device
        commandQueue = queue
        commandQueue.label = "VisionPlay.video"
        library = try device.makeDefaultLibrary(bundle: Bundle(for: StreamRenderer.self))
        guard let ycbcr = library.makeFunction(name: "ycbcr_to_rgb") else { throw RendererError.missingFunction("ycbcr_to_rgb") }
        ycbcrPipeline = try device.makeComputePipelineState(function: ycbcr)
        guard let deblock = library.makeFunction(name: "deblock") else { throw RendererError.missingFunction("deblock") }
        deblockPipeline = try device.makeComputePipelineState(function: deblock)
        upscaler = try SpatialUpscaler(device: device, library: library)
        var cache: CVMetalTextureCache?
        let status = CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, device, nil, &cache)
        guard status == kCVReturnSuccess, let cache else { throw RendererError.textureCache(status) }
        textureCache = cache
        stats.metalFXAvailable = upscaler.metalFXAvailable
        vpLog(.info, "render", "Metal device: \(device.name); MetalFX spatial: \(upscaler.metalFXAvailable ? "available" : "unavailable")")
    }

    var currentStats: RenderStats {
        stateLock.lock(); defer { stateLock.unlock() }
        return stats
    }

    func setConfiguration(_ configuration: UpscalerConfiguration) {
        stateLock.lock(); self.configuration = configuration; stateLock.unlock()
    }

    func attach(target: RenderTarget?) {
        stateLock.lock()
        windowTarget = target
        if theaterTarget == nil { self.target = target }
        stateLock.unlock()
    }

    /// True while the Custom Screen is the render target.
    var hasTheaterTarget: Bool {
        stateLock.lock(); defer { stateLock.unlock() }
        return theaterTarget != nil
    }

    func attachTheater(target: RenderTarget) {
        stateLock.lock()
        theaterTarget = target
        self.target = target
        stateLock.unlock()
    }

    func detachTheater(target: RenderTarget) {
        stateLock.lock()
        if theaterTarget === target {
            theaterTarget = nil
            self.target = windowTarget
        }
        stateLock.unlock()
    }

    /// Hands a decoded frame to the renderer. Never blocks.
    func submit(pixelBuffer: CVPixelBuffer, submittedAt: UInt64) {
        letterbox.sample(pixelBuffer)
        frameObserver?(pixelBuffer)
        stateLock.lock()
        // Not on the Custom Screen: there the GPU is shared with RealityKit drawing your room,
        // hands and panel, and the ML pass costs more than it shows at screen distance.
        let useML = theaterTarget == nil && LiveNeuralUpscaler.supports1080p2x && configuration.neuralEnabled && configuration.enabled && configuration.mode == .quality && configuration.outputTarget == .uhd4K && compareSplitValue == 0
        let useFrameGen = !useML && configuration.frameGeneration && FrameGenerator.isAvailable
        if !useFrameGen { stats.frameGenStatus = configuration.frameGeneration && !FrameGenerator.isAvailable ? "Frame generation not available on this device" : "" }
        stateLock.unlock()
        if useFrameGen {
            // 120 fps: show the in-between picture now and this frame half a 60 fps frame later.
            frameGen.submit(pixelBuffer) { [weak self] inBetween, current, status in
                guard let self else { return }
                self.stateLock.lock(); self.stats.frameGenStatus = status; self.stateLock.unlock()
                if let inBetween {
                    self.submitPrepared(pixelBuffer: inBetween, submittedAt: submittedAt)
                    self.renderQueue.asyncAfter(deadline: .now() + 1.0 / 120.0) {
                        self.submitPrepared(pixelBuffer: current, submittedAt: submittedAt)
                    }
                } else {
                    self.submitPrepared(pixelBuffer: current, submittedAt: submittedAt)
                }
            }
            return
        }
        if useML {
            neural.submit(pixelBuffer) { [weak self] output, status in
                guard let self else { return }
                self.stateLock.lock(); self.stats.neuralStatus = status; self.stateLock.unlock()
                self.submitPrepared(pixelBuffer: output, submittedAt: submittedAt)
            }
        } else {
            stateLock.lock(); stats.neuralStatus = "Spatial scaling"; stateLock.unlock()
            submitPrepared(pixelBuffer: pixelBuffer, submittedAt: submittedAt)
        }
    }

    private func submitPrepared(pixelBuffer: CVPixelBuffer, submittedAt: UInt64) {
        stateLock.lock()
        guard submittedAt >= lastPreparedTime else { stateLock.unlock(); return }
        lastPreparedTime = submittedAt
        if pending != nil { stats.framesDropped += 1 }
        pending = PendingFrame(pixelBuffer: pixelBuffer, submittedAt: submittedAt)
        // When paced by the display, the next refresh tick picks the frame up.
        let canStart = !displayPaced && framesInFlight < maxFramesInFlight
        if canStart { framesInFlight += 1 }
        lastFrame = pixelBuffer
        stateLock.unlock()
        if canStart { renderQueue.async { self.renderNext() } }
    }

    /// Called on every display refresh by `DisplayPacer` (main thread).
    func displayTick(refreshHz: Double) {
        stateLock.lock()
        stats.displayRefreshHz = refreshHz
        let canStart = displayPaced && pending != nil && framesInFlight < maxFramesInFlight
        if canStart { framesInFlight += 1 }
        stateLock.unlock()
        if canStart { renderQueue.async { self.renderNext() } }
    }

    func setDisplayPaced(_ paced: Bool) {
        stateLock.lock()
        displayPaced = paced
        if !paced { stats.displayRefreshHz = 0 }
        let kick = !paced && pending != nil && framesInFlight < maxFramesInFlight
        if kick { framesInFlight += 1 }
        stateLock.unlock()
        if kick { renderQueue.async { self.renderNext() } }
    }

    /// Most recent decoded frame (for screenshots).
    var latestFrame: CVPixelBuffer? {
        stateLock.lock(); defer { stateLock.unlock() }
        return lastFrame
    }

    private func renderNext() {
        stateLock.lock()
        guard let frame = pending, let target else {
            framesInFlight -= 1
            stateLock.unlock()
            return
        }
        pending = nil
        let config = configuration
        stateLock.unlock()

        // A RealityKit screen can only be touched on the main thread. All the frame's work
        // (decode planes, clean-up, 4K upscaling, picture) runs here on the render thread into
        // an offscreen texture; the main thread only does one quick copy into RealityKit.
        let drawTarget: RenderTarget = target.requiresMainThread ? mainThreadBridge(for: target) : target
        if !encode(frame: frame, target: drawTarget, config: config) {
            frameFinished(rendered: false)
        }
    }

    private var bridge: MainThreadTargetBridge?

    private func mainThreadBridge(for target: RenderTarget) -> RenderTarget {
        if let bridge, bridge.inner === target { return bridge }
        let created = MainThreadTargetBridge(inner: target, device: device)
        bridge = created
        return created
    }

    private func frameFinished(rendered: Bool) {
        stateLock.lock()
        framesInFlight -= 1
        let hasPending = pending != nil && !displayPaced
        if hasPending { framesInFlight += 1 }
        stateLock.unlock()
        if hasPending { renderQueue.async { self.renderNext() } }
    }

    // MARK: Encoding

    struct PlaneTextures {
        let luma: MTLTexture
        let chroma: MTLTexture
        /// CVMetalTexture wrappers must stay alive until the GPU has finished.
        let retained: [CVMetalTexture]
    }

    /// Wraps the two planes of a bi-planar Y'CbCr pixel buffer as Metal textures (no copy).
    static func makePlaneTextures(from pixelBuffer: CVPixelBuffer, cache: CVMetalTextureCache) -> PlaneTextures? {
        let format = CVPixelBufferGetPixelFormatType(pixelBuffer)
        let tenBit = format == kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange
            || format == kCVPixelFormatType_420YpCbCr10BiPlanarFullRange
        guard CVPixelBufferGetPlaneCount(pixelBuffer) == 2 else { return nil }
        let lumaFormat: MTLPixelFormat = tenBit ? .r16Unorm : .r8Unorm
        let chromaFormat: MTLPixelFormat = tenBit ? .rg16Unorm : .rg8Unorm

        func plane(_ index: Int, _ pixelFormat: MTLPixelFormat) -> CVMetalTexture? {
            var texture: CVMetalTexture?
            let status = CVMetalTextureCacheCreateTextureFromImage(
                kCFAllocatorDefault, cache, pixelBuffer, nil, pixelFormat,
                CVPixelBufferGetWidthOfPlane(pixelBuffer, index),
                CVPixelBufferGetHeightOfPlane(pixelBuffer, index), index, &texture)
            return status == kCVReturnSuccess ? texture : nil
        }
        guard let lumaRef = plane(0, lumaFormat), let chromaRef = plane(1, chromaFormat),
              let luma = CVMetalTextureGetTexture(lumaRef), let chroma = CVMetalTextureGetTexture(chromaRef) else {
            return nil
        }
        return PlaneTextures(luma: luma, chroma: chroma, retained: [lumaRef, chromaRef])
    }

    private func composePipeline(for format: MTLPixelFormat, yuv: Bool) -> MTLRenderPipelineState? {
        if yuv, let cached = composeYUVPipelines[format] { return cached }
        if !yuv, let cached = composePipelines[format] { return cached }
        let descriptor = MTLRenderPipelineDescriptor()
        descriptor.label = yuv ? "compose_yuv" : "compose"
        descriptor.vertexFunction = library.makeFunction(name: "fullscreen_vertex")
        descriptor.fragmentFunction = library.makeFunction(name: yuv ? "compose_yuv_fragment" : "compose_fragment")
        descriptor.colorAttachments[0].pixelFormat = format
        guard let state = try? device.makeRenderPipelineState(descriptor: descriptor) else {
            vpLog(.error, "render", "Failed to build compose pipeline for pixel format \(format.rawValue)")
            return nil
        }
        if yuv { composeYUVPipelines[format] = state } else { composePipelines[format] = state }
        return state
    }

    private func ensureTexture(_ texture: inout MTLTexture?, width: Int, height: Int, usage: MTLTextureUsage, label: String) -> MTLTexture? {
        if let existing = texture, existing.width == width, existing.height == height,
           existing.usage.contains(usage) { return existing }
        let descriptor = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: width,
                                                                  height: height, mipmapped: false)
        descriptor.usage = usage
        descriptor.storageMode = .private
        texture = device.makeTexture(descriptor: descriptor)
        texture?.label = label
        return texture
    }

    /// Encodes and commits one frame. Returns false if nothing was committed.
    private func encode(frame: PendingFrame, target: RenderTarget, config: UpscalerConfiguration) -> Bool {
        encodeLock.lock(); defer { encodeLock.unlock() }
        guard let cache = textureCache,
              let planes = Self.makePlaneTextures(from: frame.pixelBuffer, cache: cache),
              let commandBuffer = commandQueue.makeCommandBuffer() else { return false }
        commandBuffer.label = "VisionPlay.frame"

        let sourceWidth = planes.luma.width
        let sourceHeight = planes.luma.height
        let requested = config.outputSize(sourceWidth: sourceWidth, sourceHeight: sourceHeight)
        let actual = target.prepare(width: requested.width, height: requested.height)
        let rect = aspectFitRect(sourceWidth: sourceWidth, sourceHeight: sourceHeight,
                                 targetWidth: actual.width, targetHeight: actual.height)
        let contentWidth = max(1, Int((rect.z * Float(actual.width)).rounded()))
        let contentHeight = max(1, Int((rect.w * Float(actual.height)).rounded()))
        let colorInfo = FrameColorInfo.from(frame.pixelBuffer)
        var conversion = colorInfo.conversion
        if lastHDRRequest != colorInfo.isPQ || lastHDRTarget !== target {
            lastHDRRequest = colorInfo.isPQ
            lastHDRTarget = target
            target.setHDR(colorInfo.isPQ)
            vpLog(.info, "render", "Stream colour: \(colorInfo.label)")
        }

        let usePerformancePath = !config.enabled || config.mode == .performance
        var technique: ScalingTechnique = .bilinear
        var content: MTLTexture?
        var originalTexture: MTLTexture?

        if !usePerformancePath {
            guard let rgb = ensureTexture(&rgbTexture, width: sourceWidth, height: sourceHeight,
                                          usage: [.shaderRead, .shaderWrite, .renderTarget], label: "VisionPlay.rgb"),
                  let compute = commandBuffer.makeComputeCommandEncoder() else { return false }
            compute.label = "ycbcr_to_rgb"
            compute.setComputePipelineState(ycbcrPipeline)
            compute.setTexture(planes.luma, index: 0)
            compute.setTexture(planes.chroma, index: 1)
            compute.setTexture(rgb, index: 2)
            compute.setBytes(&conversion, length: MemoryLayout<ColorConversionUniforms>.stride, index: 0)
            let w = ycbcrPipeline.threadExecutionWidth
            let h = max(1, ycbcrPipeline.maxTotalThreadsPerThreadgroup / w)
            compute.dispatchThreadgroups(MTLSize(width: (sourceWidth + w - 1) / w, height: (sourceHeight + h - 1) / h, depth: 1),
                                         threadsPerThreadgroup: MTLSize(width: w, height: h, depth: 1))
            compute.endEncoding()

            originalTexture = rgb
            // Optional deblock/deband at source resolution, before anything is enlarged.
            var source = rgb
            if config.deblockStrength > 0,
               let cleaned = ensureTexture(&deblockTexture, width: sourceWidth, height: sourceHeight,
                                           usage: [.shaderRead, .shaderWrite], label: "VisionPlay.deblock"),
               let pass = commandBuffer.makeComputeCommandEncoder() {
                pass.label = "deblock"
                pass.setComputePipelineState(deblockPipeline)
                pass.setTexture(rgb, index: 0)
                pass.setTexture(cleaned, index: 1)
                var strength = config.deblockStrength
                pass.setBytes(&strength, length: MemoryLayout<Float>.stride, index: 0)
                let dw = deblockPipeline.threadExecutionWidth
                let dh = max(1, deblockPipeline.maxTotalThreadsPerThreadgroup / dw)
                pass.dispatchThreadgroups(MTLSize(width: (sourceWidth + dw - 1) / dw, height: (sourceHeight + dh - 1) / dh, depth: 1),
                                          threadsPerThreadgroup: MTLSize(width: dw, height: dh, depth: 1))
                pass.endEncoding()
                source = cleaned
            }

            if contentWidth == sourceWidth && contentHeight == sourceHeight {
                content = source
                technique = .none
            } else {
                let usesMetalFX = upscaler.willUseMetalFX(mode: config.mode, inputSize: (sourceWidth, sourceHeight),
                                                          outputSize: (contentWidth, contentHeight))
                var usage: MTLTextureUsage = [.shaderRead, .shaderWrite, .renderTarget]
                if usesMetalFX { usage.formUnion(upscaler.requiredOutputUsage) }
                guard let scaled = ensureTexture(&scaledTexture, width: contentWidth, height: contentHeight,
                                                 usage: usage, label: "VisionPlay.scaled") else { return false }
                technique = upscaler.encode(commandBuffer: commandBuffer, input: source, output: scaled, mode: config.mode)
                content = scaled
            }
        }

        let sharpen = usePerformancePath ? 0 : config.effectiveSharpening
        var compose = ComposeUniforms(contentRect: rect,
                                      contentSize: SIMD2(Float(content?.width ?? sourceWidth), Float(content?.height ?? sourceHeight)),
                                      casPeakDenominator: UpscalerConfiguration.casPeakDenominator(forAmount: sharpen),
                                      sharpenAmount: sharpen,
                                      decodeToLinear: 0,
                                      headroom: config.hdrHeadroom)
        let picture = config.picture.clamped()
        compose.picture = SIMD4(Float(picture.brightness), Float(picture.contrast), Float(picture.saturation), Float(picture.temperature))
        let split: Float = usePerformancePath ? 0 : compareSplit
        compose.extra = SIMD4(Float(picture.shadowLift), usePerformancePath ? 0 : config.textClarity, split, colorInfo.sourcePeakNits)
        compose.smartSharpen = config.smartSharpening ? 1 : 0
        compose.barsMode = config.blackBars.shaderValue
        if config.blackBars != .off {
            let bars = letterbox.bars
            compose.bars = SIMD2(bars.top, bars.bottom)
        }
        if usePerformancePath { technique = (contentWidth == sourceWidth && contentHeight == sourceHeight) ? .none : .bilinear }

        var presentedSize = actual
        var dynamicRange = "SDR"
        let edrAvailable = target.supportsEDR
        let drew = target.encode(commandBuffer: commandBuffer) { destination in
            presentedSize = (destination.width, destination.height)
            // The pipeline and output encoding follow the texture actually handed to us, so a
            // target switching formats (SDR ⇄ EDR) can never mismatch the pipeline.
            let format = destination.pixelFormat
            compose.decodeToLinear = format.expectsLinearLight ? 1 : 0
            if colorInfo.isPQ {
                if format.isFloat && edrAvailable {
                    compose.transferMode = 1
                    dynamicRange = String(format: "HDR (EDR, headroom %.1f×)", config.hdrHeadroom)
                } else {
                    compose.transferMode = 2
                    dynamicRange = "HDR tone-mapped to SDR"
                }
            }
            guard let pipeline = self.composePipeline(for: format, yuv: usePerformancePath) else { return }
            let pass = MTLRenderPassDescriptor()
            pass.colorAttachments[0].texture = destination
            pass.colorAttachments[0].loadAction = .dontCare
            pass.colorAttachments[0].storeAction = .store
            guard let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: pass) else { return }
            encoder.label = "compose"
            encoder.setRenderPipelineState(pipeline)
            if usePerformancePath {
                encoder.setFragmentTexture(planes.luma, index: 0)
                encoder.setFragmentTexture(planes.chroma, index: 1)
                encoder.setFragmentBytes(&conversion, length: MemoryLayout<ColorConversionUniforms>.stride, index: 1)
            } else {
                encoder.setFragmentTexture(content, index: 0)
                encoder.setFragmentTexture(originalTexture ?? content, index: 1)
            }
            encoder.setFragmentBytes(&compose, length: MemoryLayout<ComposeUniforms>.stride, index: 0)
            encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            encoder.endEncoding()
        }
        guard drew else {
            stateLock.lock(); stats.framesSkippedNoDrawable += 1; stateLock.unlock()
            return false
        }

        let retained = planes.retained
        let submittedAt = frame.submittedAt
        let outputSize = presentedSize
        let usedTechnique = technique
        let colorLabel = colorInfo.label
        let rangeLabel = dynamicRange
        commandBuffer.addCompletedHandler { [weak self] buffer in
            _ = retained
            self?.recordCompletion(buffer: buffer, submittedAt: submittedAt, source: (sourceWidth, sourceHeight),
                                   output: outputSize, technique: usedTechnique,
                                   color: colorLabel, dynamicRange: rangeLabel)
            self?.frameFinished(rendered: true)
        }
        commandBuffer.commit()
        return true
    }

    private func recordCompletion(buffer: MTLCommandBuffer, submittedAt: UInt64, source: (Int, Int),
                                  output: (width: Int, height: Int), technique: ScalingTechnique,
                                  color: String, dynamicRange: String) {
        let gpu = max(0, (buffer.gpuEndTime - buffer.gpuStartTime) * 1000)
        let latency = MachTime.milliseconds(from: submittedAt, to: mach_absolute_time())
        let now = CACurrentMediaTime()
        stateLock.lock()
        stats.framesRendered += 1
        stats.gpuMilliseconds = gpu
        stats.gpuMillisecondsAverage = stats.gpuMillisecondsAverage == 0 ? gpu : stats.gpuMillisecondsAverage * 0.95 + gpu * 0.05
        stats.pipelineLatencyMilliseconds = latency
        stats.sourceWidth = source.0
        stats.sourceHeight = source.1
        stats.outputWidth = output.width
        stats.outputHeight = output.height
        stats.technique = technique
        stats.colorDescription = color
        stats.dynamicRange = dynamicRange
        fpsWindowCount += 1
        if now - fpsWindowStart >= 1.0 {
            stats.presentedFPS = Double(fpsWindowCount) / (now - fpsWindowStart)
            fpsWindowCount = 0
            fpsWindowStart = now
        }
        stateLock.unlock()
        if let error = buffer.error {
            vpLog(.warning, "render", "GPU command buffer error: \(error.localizedDescription)")
        }
    }

    /// Drops cached textures and pipelines (called when streaming stops).
    func releaseResources() {
        stateLock.lock()
        pending = nil
        stateLock.unlock()
        encodeLock.lock()
        rgbTexture = nil
        deblockTexture = nil
        scaledTexture = nil
        lastHDRRequest = nil
        upscaler.releaseResources()
        stateLock.lock(); lastFrame = nil; stateLock.unlock()
        letterbox.reset()
        if let textureCache { CVMetalTextureCacheFlush(textureCache, 0) }
        encodeLock.unlock()
    }

    func resetStats() {
        frameGen.reset()   // new stream: nothing to interpolate from yet
        stateLock.lock()
        stats = RenderStats()
        stats.metalFXAvailable = upscaler.metalFXAvailable
        stateLock.unlock()
    }

    var hasPendingWork: Bool {
        stateLock.lock(); defer { stateLock.unlock() }
        return pending != nil || framesInFlight > 0
    }
}

/// Lets a main-thread-only target (the RealityKit screen) be drawn from the render thread.
/// The renderer draws into one of three offscreen textures; the frame's command buffer is
/// enqueued (fixing its place in the GPU queue), then the main thread encodes a single blit
/// from that texture into RealityKit's texture on the same queue, so it runs after the draw.
final class MainThreadTargetBridge: RenderTarget, @unchecked Sendable {
    let inner: RenderTarget
    private let device: MTLDevice
    private var ring: [MTLTexture] = []
    private var next = 0
    private var size = (width: 0, height: 0)

    init(inner: RenderTarget, device: MTLDevice) {
        self.inner = inner
        self.device = device
    }

    var pixelFormat: MTLPixelFormat { inner.pixelFormat }
    var expectsLinear: Bool { inner.expectsLinear }
    var requiresMainThread: Bool { false }
    var supportsEDR: Bool { inner.supportsEDR }

    func setHDR(_ enabled: Bool) {
        let inner = self.inner
        DispatchQueue.main.async { inner.setHDR(enabled) }
    }

    /// Size changes are rare: resize RealityKit's texture on the main thread, then match it.
    func prepare(width: Int, height: Int) -> (width: Int, height: Int) {
        if size.width == width && size.height == height && !ring.isEmpty { return size }
        let inner = self.inner
        let actual = Thread.isMainThread
            ? inner.prepare(width: width, height: height)
            : DispatchQueue.main.sync { inner.prepare(width: width, height: height) }
        let descriptor = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: inner.pixelFormat, width: actual.width,
                                                                  height: actual.height, mipmapped: false)
        descriptor.usage = [.shaderRead, .shaderWrite, .renderTarget]
        descriptor.storageMode = .private
        ring = (0..<3).compactMap { _ in device.makeTexture(descriptor: descriptor) }
        ring.enumerated().forEach { $0.element.label = "VisionPlay.screenBridge.\($0.offset)" }
        size = (width, height)
        return actual
    }

    func encode(commandBuffer: MTLCommandBuffer, draw: (MTLTexture) -> Void) -> Bool {
        guard !ring.isEmpty else { return false }
        let texture = ring[next]
        next = (next + 1) % ring.count
        draw(texture)
        // Reserve this buffer's place in the queue now, so the copy below runs after it.
        commandBuffer.enqueue()
        let queue = commandBuffer.commandQueue
        let inner = self.inner
        DispatchQueue.main.async {
            guard let copy = queue.makeCommandBuffer() else { return }
            copy.label = "VisionPlay.screenCopy"
            _ = inner.encode(commandBuffer: copy) { destination in
                guard destination.width == texture.width, destination.height == texture.height,
                      let blit = copy.makeBlitCommandEncoder() else { return }
                blit.copy(from: texture, to: destination)
                blit.endEncoding()
            }
            copy.commit()
        }
        return true
    }
}
