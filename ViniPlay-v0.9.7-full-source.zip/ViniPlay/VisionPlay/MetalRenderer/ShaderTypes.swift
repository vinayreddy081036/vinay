import simd
import CoreVideo
import Metal

/// Swift mirrors of the uniform structs in VisionPlayShaders.metal.
/// Layouts are verified by `ShaderCompilationTests`.
struct ColorConversionUniforms {
    var matrix: simd_float3x3
    var offset: SIMD3<Float>
    var scale: SIMD3<Float>

    /// ITU-R BT.709, limited ("video") range — what the PS5 sends for SDR.
    static let bt709VideoRange = ColorConversionUniforms(
        matrix: simd_float3x3(columns: (
            SIMD3<Float>(1.0, 1.0, 1.0),
            SIMD3<Float>(0.0, -0.187_324, 1.855_6),
            SIMD3<Float>(1.574_8, -0.468_124, 0.0))),
        offset: SIMD3<Float>(16.0 / 255.0, 128.0 / 255.0, 128.0 / 255.0),
        scale: SIMD3<Float>(255.0 / 219.0, 255.0 / 224.0, 255.0 / 224.0))

    /// ITU-R BT.601, limited range (used for SD resolutions).
    static let bt601VideoRange = ColorConversionUniforms(
        matrix: simd_float3x3(columns: (
            SIMD3<Float>(1.0, 1.0, 1.0),
            SIMD3<Float>(0.0, -0.344_136, 1.772),
            SIMD3<Float>(1.402, -0.714_136, 0.0))),
        offset: SIMD3<Float>(16.0 / 255.0, 128.0 / 255.0, 128.0 / 255.0),
        scale: SIMD3<Float>(255.0 / 219.0, 255.0 / 224.0, 255.0 / 224.0))

    /// ITU-R BT.2020 non-constant luminance, limited range — PS5 HDR (HEVC Main10).
    /// Offsets/scales are for 10-bit codes stored in the high bits of 16-bit samples
    /// (x420 pixel buffers read through r16Unorm/rg16Unorm textures).
    static let bt2020TenBitVideoRange = ColorConversionUniforms(
        matrix: simd_float3x3(columns: (
            SIMD3<Float>(1.0, 1.0, 1.0),
            SIMD3<Float>(0.0, -0.164_553, 1.881_4),
            SIMD3<Float>(1.474_6, -0.571_353, 0.0))),
        offset: SIMD3<Float>(64 * 64 / 65535.0, 512 * 64 / 65535.0, 512 * 64 / 65535.0),
        scale: SIMD3<Float>(65535.0 / (876 * 64), 65535.0 / (896 * 64), 65535.0 / (896 * 64)))

    /// BT.709 for 10-bit (SDR Main10) buffers.
    static let bt709TenBitVideoRange = ColorConversionUniforms(
        matrix: bt709VideoRange.matrix,
        offset: SIMD3<Float>(64 * 64 / 65535.0, 512 * 64 / 65535.0, 512 * 64 / 65535.0),
        scale: SIMD3<Float>(65535.0 / (876 * 64), 65535.0 / (896 * 64), 65535.0 / (896 * 64)))

    func convert(y: Float, cb: Float, cr: Float) -> SIMD3<Float> {
        let ycc = (SIMD3<Float>(y, cb, cr) - offset) * scale
        let rgb = matrix * ycc
        return simd_clamp(rgb, SIMD3<Float>(repeating: 0), SIMD3<Float>(repeating: 1))
    }
}

struct ScaleUniforms {
    var sourceSize: SIMD2<Float>
    var destSize: SIMD2<Float>
    var support: Float
    var filter: UInt32       // 0 = Catmull-Rom, 1 = Lanczos-3
    var horizontal: UInt32
    var pad: Float = 0
}

struct ComposeUniforms {
    var contentRect: SIMD4<Float>
    var contentSize: SIMD2<Float>
    var casPeakDenominator: Float
    var sharpenAmount: Float
    var decodeToLinear: UInt32
    /// 0 = SDR video, 1 = PQ → EDR (BT.2020 linear), 2 = PQ → tone-mapped SDR (BT.709 linear).
    var transferMode: UInt32 = 0
    var headroom: Float = 2
    var referenceWhiteNits: Float = 203
    /// brightness, contrast, saturation, temperature
    var picture = SIMD4<Float>(0, 1, 1, 0)
    /// shadowLift, textClarity, compareSplit (0 = off), sourcePeakNits (0 = unknown → 1000)
    var extra = SIMD4<Float>(0, 0, 0, 0)
    /// letterbox top / bottom fractions
    var bars = SIMD2<Float>(0, 0)
    /// 0 leave, 1 force black, 2 zoom to fill
    var barsMode: UInt32 = 0
    var smartSharpen: UInt32 = 1
}

/// Colour description of a decoded frame, read from VideoToolbox's buffer attachments
/// (which come from the stream's VUI), with sensible fallbacks.
struct FrameColorInfo: Equatable {
    var conversion: ColorConversionUniforms
    var isPQ: Bool
    var isTenBit: Bool
    var label: String
    /// Brightest the game says it gets (HDR10 MaxCLL, else mastering display peak), nits. 0 = not sent.
    var sourcePeakNits: Float = 0

    static func == (a: FrameColorInfo, b: FrameColorInfo) -> Bool {
        a.isPQ == b.isPQ && a.isTenBit == b.isTenBit && a.label == b.label
    }

    static func from(_ pixelBuffer: CVPixelBuffer) -> FrameColorInfo {
        let format = CVPixelBufferGetPixelFormatType(pixelBuffer)
        let tenBit = format == kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange
            || format == kCVPixelFormatType_420YpCbCr10BiPlanarFullRange
        func attachment(_ key: CFString) -> String? {
            CVBufferCopyAttachment(pixelBuffer, key, nil) as? String
        }
        let matrix = attachment(kCVImageBufferYCbCrMatrixKey)
        let transfer = attachment(kCVImageBufferTransferFunctionKey)
        let isPQ = transfer == (kCVImageBufferTransferFunction_SMPTE_ST_2084_PQ as String)
        let is2020 = matrix == (kCVImageBufferYCbCrMatrix_ITU_R_2020 as String) || (isPQ && matrix == nil)
        let is601 = matrix == (kCVImageBufferYCbCrMatrix_ITU_R_601_4 as String)
            || (matrix == nil && CVPixelBufferGetHeight(pixelBuffer) <= 576)
        let conversion: ColorConversionUniforms
        let label: String
        switch (is2020, tenBit, is601) {
        case (true, _, _):
            conversion = .bt2020TenBitVideoRange; label = "BT.2020"
        case (false, true, _):
            conversion = .bt709TenBitVideoRange; label = "BT.709 10-bit"
        case (false, false, true):
            conversion = .bt601VideoRange; label = "BT.601"
        default:
            conversion = .bt709VideoRange; label = "BT.709"
        }
        var info = FrameColorInfo(conversion: conversion, isPQ: isPQ, isTenBit: tenBit,
                                  label: isPQ ? "\(label) PQ (HDR10)" : label)
        if isPQ {
            let cll = CVBufferCopyAttachment(pixelBuffer, kCVImageBufferContentLightLevelInfoKey, nil) as? Data
            let mastering = CVBufferCopyAttachment(pixelBuffer, kCVImageBufferMasteringDisplayColorVolumeKey, nil) as? Data
            info.sourcePeakNits = Self.peakNits(contentLightLevel: cll, masteringDisplay: mastering)
            if info.sourcePeakNits > 0 { info.label += String(format: ", peak %.0f nits", info.sourcePeakNits) }
        }
        return info
    }

    /// HDR10 static metadata (big-endian, as VideoToolbox attaches it): Content Light Level
    /// Info = MaxCLL (UInt16 nits) + MaxFALL; Mastering Display Colour Volume = 6×UInt16
    /// primaries, 2×UInt16 white point, UInt32 max luminance (0.0001 nits), UInt32 min.
    /// MaxCLL is preferred (it describes the content); implausible values are ignored.
    static func peakNits(contentLightLevel: Data?, masteringDisplay: Data?) -> Float {
        if let cll = contentLightLevel, cll.count >= 2 {
            let maxCLL = Float(UInt16(cll[cll.startIndex]) << 8 | UInt16(cll[cll.startIndex + 1]))
            if maxCLL >= 100 && maxCLL <= 10_000 { return maxCLL }
        }
        if let md = masteringDisplay, md.count >= 24 {
            let i = md.startIndex + 16
            let raw = UInt32(md[i]) << 24 | UInt32(md[i + 1]) << 16 | UInt32(md[i + 2]) << 8 | UInt32(md[i + 3])
            let nits = Float(raw) / 10_000
            if nits >= 100 && nits <= 10_000 { return nits }
        }
        return 0
    }
}

extension MTLPixelFormat {
    /// Formats whose shader output is linear light (sRGB encodes in hardware; float is linear).
    var expectsLinearLight: Bool {
        switch self {
        case .bgra8Unorm_srgb, .rgba8Unorm_srgb, .rgba16Float, .rgba32Float, .bgr10_xr_srgb: return true
        default: return false
        }
    }

    var isFloat: Bool { self == .rgba16Float || self == .rgba32Float }
}

/// Fits a source aspect ratio inside a target, centred (letterbox / pillarbox).
/// Returns a normalized rect (x, y, width, height).
func aspectFitRect(sourceWidth: Int, sourceHeight: Int, targetWidth: Int, targetHeight: Int) -> SIMD4<Float> {
    guard sourceWidth > 0, sourceHeight > 0, targetWidth > 0, targetHeight > 0 else { return SIMD4(0, 0, 1, 1) }
    let sourceAspect = Float(sourceWidth) / Float(sourceHeight)
    let targetAspect = Float(targetWidth) / Float(targetHeight)
    if abs(sourceAspect - targetAspect) < 0.001 { return SIMD4(0, 0, 1, 1) }
    if sourceAspect > targetAspect {
        let h = targetAspect / sourceAspect
        return SIMD4(0, (1 - h) / 2, 1, h)
    } else {
        let w = sourceAspect / targetAspect
        return SIMD4((1 - w) / 2, 0, w, 1)
    }
}
