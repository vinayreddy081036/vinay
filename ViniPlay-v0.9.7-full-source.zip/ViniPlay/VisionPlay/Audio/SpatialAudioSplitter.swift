import Foundation
import AudioToolbox
import os

/// Feeds several mono spatial sources (front L/R, rear L/R) from one stereo ring buffer.
///
/// Each AVAudioSourceNode pulls on the same real-time thread with the same timestamp, so
/// the first pull in a render cycle reads the stereo frames once and the others reuse
/// them. Real-time safe: fixed buffers, no allocation, an unfair lock only.
final class SpatialAudioSplitter: @unchecked Sendable {
    enum Channel: Int { case frontLeft = 0, frontRight, rearLeft, rearRight }

    private let ring: AudioRingBuffer
    private let maxFrames = 4096
    private var left: UnsafeMutablePointer<Float>
    private var right: UnsafeMutablePointer<Float>
    private var side: UnsafeMutablePointer<Float>
    // Delay line (≈12 ms at 48 kHz) that decorrelates the rear ambience from the front.
    private let delayLength = 576
    private var delay: UnsafeMutablePointer<Float>
    private var delayIndex = 0
    private var cachedSampleTime: Float64 = -1
    private var cachedFrames = 0
    private var lock = os_unfair_lock()

    init(ring: AudioRingBuffer) {
        self.ring = ring
        left = .allocate(capacity: maxFrames); left.initialize(repeating: 0, count: maxFrames)
        right = .allocate(capacity: maxFrames); right.initialize(repeating: 0, count: maxFrames)
        side = .allocate(capacity: maxFrames); side.initialize(repeating: 0, count: maxFrames)
        delay = .allocate(capacity: delayLength); delay.initialize(repeating: 0, count: delayLength)
    }

    deinit {
        left.deallocate(); right.deallocate(); side.deallocate(); delay.deallocate()
    }

    /// Fills `output` (mono Float32) for one source.
    func render(_ channel: Channel, sampleTime: Float64, frames: Int, into output: UnsafeMutablePointer<Float>) {
        let n = min(frames, maxFrames)
        os_unfair_lock_lock(&lock)
        if sampleTime != cachedSampleTime || n != cachedFrames {
            cachedSampleTime = sampleTime
            cachedFrames = n
            ring.readStereo(left: left, right: right, frames: n)
            for i in 0..<n {
                // Rear ambience = delayed stereo difference (what's only on one side).
                let s = (left[i] - right[i]) * 0.5
                side[i] = delay[delayIndex]
                delay[delayIndex] = s
                delayIndex = (delayIndex + 1) % delayLength
            }
        }
        switch channel {
        case .frontLeft: output.update(from: left, count: n)
        case .frontRight: output.update(from: right, count: n)
        case .rearLeft: output.update(from: side, count: n)
        case .rearRight:
            for i in 0..<n { output[i] = -side[i] }
        }
        os_unfair_lock_unlock(&lock)
        if frames > n { (output + n).update(repeating: 0, count: frames - n) }
    }
}
