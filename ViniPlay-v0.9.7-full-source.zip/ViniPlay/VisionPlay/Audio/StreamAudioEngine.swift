import Foundation
import AVFoundation
import AudioToolbox

/// Decodes the PS5's Opus audio and plays it with minimal buffering.
///
/// Sync strategy: Remote Play delivers audio and video in real time, so both are played
/// "as soon as decoded". The ring buffer targets ~30 ms of audio and is hard-limited
/// (default 100 ms); anything older is dropped, so audio stays within that window of the
/// video instead of accumulating delay after network hiccups.
final class StreamAudioEngine: @unchecked Sendable {
    struct Stats: Sendable {
        var packetsDecoded: UInt64 = 0
        var decodeErrors: UInt64 = 0
        var bufferedMilliseconds: Double = 0
        var underruns: UInt64 = 0
        var overflowDrops: UInt64 = 0
        var sampleRate: Int = 0
        var channels: Int = 0
        var running = false
        var microphoneActive = false
        var microphonePacketsSent: UInt64 = 0
        var spatialDescription = "Spatial (window)"
    }

    /// Receives decoded interleaved stereo PCM (Instant Replay). Called on the audio queue.
    var pcmObserver: ((UnsafeBufferPointer<Float>) -> Void)?
    private let queue = DispatchQueue(label: "VisionPlay.audio", qos: .userInteractive)
    private let engine = AVAudioEngine()
    private var sourceNode: AVAudioSourceNode?
    // Spatial audio graph: mono sources → environment (HRTF, head tracking, room) → mixer.
    private let environment = AVAudioEnvironmentNode()
    private var environmentAttached = false
    private var spatialNodes: [(SpatialAudioSplitter.Channel, AVAudioSourceNode)] = []
    private var splitter: SpatialAudioSplitter?
    private var layout = SpatialAudioLayout.windowDefault
    private var converter: AVAudioConverter?
    private var inputFormat: AVAudioFormat?
    private var outputFormat: AVAudioFormat?
    private var pcmBuffer: AVAudioPCMBuffer?
    private var interleaveScratch: [Float] = []
    private var ring: AudioRingBuffer?
    private var sampleRate = 48_000
    private var channels = 2
    private var frameSize = 480
    private var primed = false
    private var stats = Stats()
    private let statsLock = NSLock()
    private var observers: [NSObjectProtocol] = []

    // Microphone (party chat): captured with voice processing (echo cancellation), converted
    // to 48 kHz stereo int16 and delivered in 10 ms blocks of 480 frames.
    private var microphoneActive = false
    private var micSink: ((UnsafePointer<Int16>) -> Void)?
    private var micConverter: AVAudioConverter?
    private var micFIFO: [Int16] = []
    /// Guards micSink / micConverter / micFIFO: the input tap runs on its own thread while
    /// setMicrophone and stop() change them on the audio queue.
    private let micLock = NSLock()
    private let micFormat = AVAudioFormat(commonFormat: .pcmFormatInt16, sampleRate: 48_000, channels: 2, interleaved: true)!
    static let micFramesPerPacket = 480

    var targetLatencyMilliseconds: Double = 30
    var maxLatencyMilliseconds: Double = 100

    var volume: Float = 1.0 {
        didSet { let v = volume; queue.async { self.engine.mainMixerNode.outputVolume = v } }
    }

    var currentStats: Stats {
        statsLock.lock(); var s = stats; statsLock.unlock()
        if let ring {
            s.bufferedMilliseconds = Double(ring.bufferedFrames) * 1000 / Double(max(sampleRate, 1))
            s.underruns = ring.underruns
            s.overflowDrops = ring.overflowDrops
        }
        return s
    }

    init() {
        let center = NotificationCenter.default
        observers.append(center.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: nil) { [weak self] note in
            self?.handleInterruption(note)
        })
        observers.append(center.addObserver(forName: .AVAudioEngineConfigurationChange, object: engine, queue: nil) { [weak self] _ in
            vpLog(.info, "audio", "Audio route/configuration changed; restarting engine")
            self?.queue.async { self?.restartEngine() }
        })
        observers.append(center.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: nil) { note in
            if let reason = note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt {
                vpLog(.info, "audio", "Audio route change (reason \(reason))")
            }
        })
    }

    deinit {
        for observer in observers { NotificationCenter.default.removeObserver(observer) }
        engine.stop()
    }

    /// Called when the stream announces its audio format (normally 48 kHz stereo, 480-sample Opus frames).
    func configure(channels: Int, sampleRate: Int, frameSize: Int) {
        queue.async { self.setUp(channels: channels, sampleRate: sampleRate, frameSize: frameSize) }
    }

    private func setUp(channels: Int, sampleRate: Int, frameSize: Int) {
        self.channels = max(1, min(channels, 8))
        self.sampleRate = sampleRate > 0 ? sampleRate : 48_000
        self.frameSize = frameSize > 0 ? frameSize : 480

        var opus = AudioStreamBasicDescription()
        opus.mFormatID = kAudioFormatOpus
        opus.mSampleRate = Double(self.sampleRate)
        opus.mChannelsPerFrame = UInt32(self.channels)
        opus.mFramesPerPacket = UInt32(self.frameSize)
        guard let input = AVAudioFormat(streamDescription: &opus),
              let output = AVAudioFormat(standardFormatWithSampleRate: Double(self.sampleRate),
                                         channels: AVAudioChannelCount(self.channels)),
              let converter = AVAudioConverter(from: input, to: output),
              let pcm = AVAudioPCMBuffer(pcmFormat: output, frameCapacity: AVAudioFrameCount(self.frameSize * 4)) else {
            vpLog(.error, "audio", "Could not create Opus decoder for \(channels) ch @ \(sampleRate) Hz")
            return
        }
        inputFormat = input
        outputFormat = output
        self.converter = converter
        pcmBuffer = pcm
        interleaveScratch = [Float](repeating: 0, count: self.frameSize * 4 * self.channels)
        ring = AudioRingBuffer(channels: self.channels, capacityFrames: self.sampleRate / 2)
        primed = false
        statsLock.lock()
        stats.sampleRate = self.sampleRate
        stats.channels = self.channels
        statsLock.unlock()
        vpLog(.info, "audio", "Opus stream: \(self.channels) ch, \(self.sampleRate) Hz, \(self.frameSize) samples/packet")
        startEngine()
    }

    private func startEngine() {
        do {
            let session = AVAudioSession.sharedInstance()
            if microphoneActive {
                try session.setCategory(.playAndRecord, mode: .default, options: [])
            } else {
                try session.setCategory(.playback, mode: .moviePlayback, options: [])
            }
            try? session.setPreferredIOBufferDuration(0.005)
            try? session.setPreferredSampleRate(Double(sampleRate))
            try session.setActive(true)
        } catch {
            vpLog(.warning, "audio", "AVAudioSession setup failed: \(error.localizedDescription)")
        }

        detachPlaybackNodes()
        guard let outputFormat else { return }
        // Capture the ring buffer directly: render blocks must not allocate or touch `self`.
        guard let ring else { return }
        if layout.enabled {
            buildSpatialGraph(ring: ring)
        } else {
            let node = AVAudioSourceNode(format: outputFormat) { _, _, frameCount, audioBufferList -> OSStatus in
                ring.read(into: UnsafeMutableAudioBufferListPointer(audioBufferList), frames: Int(frameCount))
                return noErr
            }
            sourceNode = node
            engine.attach(node)
            engine.connect(node, to: engine.mainMixerNode, format: outputFormat)
        }
        engine.mainMixerNode.outputVolume = volume
        engine.prepare()
        do {
            try engine.start()
            statsLock.lock(); stats.running = true; statsLock.unlock()
        } catch {
            vpLog(.error, "audio", "AVAudioEngine failed to start: \(error.localizedDescription)")
            statsLock.lock(); stats.running = false; statsLock.unlock()
        }
    }

    private func detachPlaybackNodes() {
        if let sourceNode {
            engine.detach(sourceNode)
            self.sourceNode = nil
        }
        for (_, node) in spatialNodes { engine.detach(node) }
        spatialNodes.removeAll()
        if environmentAttached {
            engine.detach(environment)
            environmentAttached = false
        }
        splitter = nil
    }

    private func buildSpatialGraph(ring: AudioRingBuffer) {
        guard let mono = AVAudioFormat(standardFormatWithSampleRate: Double(sampleRate), channels: 1) else { return }
        let splitter = SpatialAudioSplitter(ring: ring)
        self.splitter = splitter
        engine.attach(environment)
        environmentAttached = true
        // Head tracking keeps the sound anchored to the screen as you turn. Set dynamically so the
        // project builds on SDKs where the property isn't exposed (visionOS head-tracks by default).
        if environment.responds(to: NSSelectorFromString("setListenerHeadTrackingEnabled:")) {
            environment.setValue(true, forKey: "listenerHeadTrackingEnabled")
        }
        environment.listenerPosition = AVAudio3DPoint(x: 0, y: 0, z: 0)
        engine.connect(environment, to: engine.mainMixerNode, format: nil)

        var channels: [SpatialAudioSplitter.Channel] = [.frontLeft, .frontRight]
        if layout.surroundUpmix { channels += [.rearLeft, .rearRight] }
        for channel in channels {
            let node = AVAudioSourceNode(format: mono) { _, timestamp, frameCount, audioBufferList -> OSStatus in
                let buffers = UnsafeMutableAudioBufferListPointer(audioBufferList)
                if let data = buffers.first?.mData {
                    splitter.render(channel, sampleTime: timestamp.pointee.mSampleTime, frames: Int(frameCount),
                                    into: data.assumingMemoryBound(to: Float.self))
                }
                return noErr
            }
            engine.attach(node)
            engine.connect(node, to: environment, format: mono)
            node.renderingAlgorithm = .HRTFHQ
            spatialNodes.append((channel, node))
        }
        applyLayout()
        vpLog(.info, "audio", "Spatial audio on: \(layout.room.rawValue) \(layout.roomAcoustics ? "acoustics" : "dry"), upmix \(layout.surroundUpmix ? "on" : "off")")
    }

    /// Updates positions, distance model and reverb without rebuilding the graph.
    private func applyLayout() {
        guard environmentAttached else { return }
        let params = environment.distanceAttenuationParameters
        params.distanceAttenuationModel = .inverse
        // Keep loudness steady at the screen's distance; distance is conveyed by HRTF and the room.
        params.referenceDistance = max(0.5, layout.screenDistance)
        params.maximumDistance = 200
        params.rolloffFactor = 0.5
        environment.reverbParameters.enable = layout.roomAcoustics
        if layout.roomAcoustics {
            environment.reverbParameters.loadFactoryReverbPreset(layout.reverbPreset)
            environment.reverbParameters.level = -4
        }
        for (channel, node) in spatialNodes {
            let p: SIMD3<Float>
            switch channel {
            case .frontLeft: p = layout.leftPosition
            case .frontRight: p = layout.rightPosition
            case .rearLeft: p = layout.rearLeftPosition
            case .rearRight: p = layout.rearRightPosition
            }
            node.position = AVAudio3DPoint(x: p.x, y: p.y, z: p.z)
            node.reverbBlend = layout.reverbBlend
            node.volume = (channel == .rearLeft || channel == .rearRight) ? SpatialAudioLayout.rearGain : 1
        }
    }

    /// Screen position/size or audio options changed. Rebuilds the graph only when needed.
    func setSpatialLayout(_ newLayout: SpatialAudioLayout) {
        queue.async {
            let old = self.layout
            self.layout = newLayout
            guard old != newLayout else { return }
            let structural = old.enabled != newLayout.enabled || old.surroundUpmix != newLayout.surroundUpmix
            if structural {
                if self.outputFormat != nil { self.restartEngine() }
            } else {
                self.applyLayout()
            }
            self.statsLock.lock(); self.stats.spatialDescription = self.describe(newLayout); self.statsLock.unlock()
        }
    }

    private func describe(_ l: SpatialAudioLayout) -> String {
        guard l.enabled else { return "Stereo" }
        var parts = [String(format: "Spatial (screen %.1f m wide, %.1f m away)", l.screenWidth, l.screenDistance)]
        if l.roomAcoustics { parts.append(l.room.rawValue + " acoustics") }
        if l.surroundUpmix { parts.append("surround upmix") }
        return parts.joined(separator: ", ")
    }

    private func restartEngine() {
        guard outputFormat != nil else { return }
        engine.stop()
        ring?.clear()
        startEngine()
    }

    /// Decodes one Opus packet. Called on the Chiaki audio thread; copies the bytes and
    /// decodes on the audio queue.
    func enqueue(packet: UnsafeBufferPointer<UInt8>) {
        guard packet.count > 0 else { return }
        let data = Data(buffer: packet)
        queue.async { self.decode(data) }
    }

    private func decode(_ packet: Data) {
        guard let converter, let inputFormat, let pcmBuffer, let ring else { return }
        let compressed = AVAudioCompressedBuffer(format: inputFormat, packetCapacity: 1, maximumPacketSize: packet.count)
        packet.withUnsafeBytes { raw in
            compressed.data.copyMemory(from: raw.baseAddress!, byteCount: packet.count)
        }
        compressed.packetDescriptions?.pointee = AudioStreamPacketDescription(mStartOffset: 0, mVariableFramesInPacket: 0,
                                                                              mDataByteSize: UInt32(packet.count))
        compressed.packetCount = 1
        compressed.byteLength = UInt32(packet.count)

        pcmBuffer.frameLength = 0
        var supplied = false
        var error: NSError?
        let status = converter.convert(to: pcmBuffer, error: &error) { _, outStatus in
            if supplied {
                outStatus.pointee = .noDataNow
                return nil
            }
            supplied = true
            outStatus.pointee = .haveData
            return compressed
        }
        guard status != .error, pcmBuffer.frameLength > 0, let channelData = pcmBuffer.floatChannelData else {
            statsLock.lock(); stats.decodeErrors += 1; statsLock.unlock()
            if let error { vpLog(.debug, "audio", "Opus decode error: \(error.localizedDescription)") }
            return
        }

        let frames = Int(pcmBuffer.frameLength)
        let channelCount = Int(pcmBuffer.format.channelCount)
        if interleaveScratch.count < frames * channelCount {
            interleaveScratch = [Float](repeating: 0, count: frames * channelCount)
        }
        interleaveScratch.withUnsafeMutableBufferPointer { scratch in
            for frame in 0..<frames {
                for channel in 0..<channelCount {
                    scratch[frame * channelCount + channel] = channelData[channel][frame]
                }
            }
            let maxFrames = Int(maxLatencyMilliseconds / 1000 * Double(sampleRate))
            ring.write(interleaved: scratch.baseAddress!, frames: frames, maxLatencyFrames: maxFrames)
            if channelCount == 2, let observer = pcmObserver {
                observer(UnsafeBufferPointer(start: scratch.baseAddress, count: frames * 2))
            }
        }
        statsLock.lock(); stats.packetsDecoded += 1; statsLock.unlock()
    }

    /// Requests microphone permission if needed. Calls back on the main thread.
    static func requestMicrophonePermission(_ completion: @escaping (Bool) -> Void) {
        AVAudioApplication.requestRecordPermission { granted in
            DispatchQueue.main.async { completion(granted) }
        }
    }

    /// Starts or stops microphone capture. `sink` receives 480×2 interleaved int16 samples per call.
    func setMicrophone(enabled: Bool, sink: ((UnsafePointer<Int16>) -> Void)?) {
        queue.async {
            guard enabled != self.microphoneActive else { return }
            self.engine.stop()
            let input = self.engine.inputNode
            if enabled {
                do {
                    self.microphoneActive = true
                    // The input only reports a usable format once the session allows recording.
                    let audioSession = AVAudioSession.sharedInstance()
                    try audioSession.setCategory(.playAndRecord, mode: .default, options: [])
                    try audioSession.setActive(true)
                    try input.setVoiceProcessingEnabled(true)
                    let inputFormat = input.outputFormat(forBus: 0)
                    guard inputFormat.sampleRate > 0, let converter = AVAudioConverter(from: inputFormat, to: self.micFormat) else {
                        throw NSError(domain: "VisionPlay", code: 1, userInfo: [NSLocalizedDescriptionKey: "no usable input format"])
                    }
                    self.micLock.lock()
                    self.micConverter = converter
                    self.micSink = sink
                    self.micFIFO.removeAll(keepingCapacity: true)
                    self.micLock.unlock()
                    input.removeTap(onBus: 0)
                    input.installTap(onBus: 0, bufferSize: 480, format: inputFormat) { [weak self] buffer, _ in
                        self?.processMicrophone(buffer)
                    }
                    vpLog(.info, "audio", "Microphone on (\(Int(inputFormat.sampleRate)) Hz, \(inputFormat.channelCount) ch, voice processing)")
                } catch {
                    vpLog(.error, "audio", "Microphone could not start: \(error.localizedDescription)")
                    self.microphoneActive = false
                    self.micLock.lock(); self.micSink = nil; self.micLock.unlock()
                    try? input.setVoiceProcessingEnabled(false)
                }
            } else {
                input.removeTap(onBus: 0)
                try? input.setVoiceProcessingEnabled(false)
                self.microphoneActive = false
                self.micLock.lock(); self.micSink = nil; self.micConverter = nil; self.micLock.unlock()
                vpLog(.info, "audio", "Microphone off")
            }
            self.statsLock.lock(); self.stats.microphoneActive = self.microphoneActive; self.statsLock.unlock()
            if self.outputFormat != nil {
                self.startEngine()
            } else if self.microphoneActive {
                self.engine.prepare()
                try? self.engine.start()
            }
        }
    }

    private func processMicrophone(_ buffer: AVAudioPCMBuffer) {
        micLock.lock(); defer { micLock.unlock() }
        guard let converter = micConverter, let sink = micSink else { return }
        let ratio = micFormat.sampleRate / buffer.format.sampleRate
        let capacity = AVAudioFrameCount(Double(buffer.frameLength) * ratio + 64)
        guard let output = AVAudioPCMBuffer(pcmFormat: micFormat, frameCapacity: capacity) else { return }
        var supplied = false
        var error: NSError?
        converter.convert(to: output, error: &error) { _, status in
            if supplied { status.pointee = .noDataNow; return nil }
            supplied = true
            status.pointee = .haveData
            return buffer
        }
        guard output.frameLength > 0, let samples = output.int16ChannelData?[0] else { return }
        micFIFO.append(contentsOf: UnsafeBufferPointer(start: samples, count: Int(output.frameLength) * 2))
        let packetSamples = Self.micFramesPerPacket * 2
        var sent: UInt64 = 0
        while micFIFO.count >= packetSamples {
            micFIFO.withUnsafeBufferPointer { sink($0.baseAddress!) }
            micFIFO.removeFirst(packetSamples)
            sent += 1
        }
        // Never let the microphone queue build latency (keep at most 3 packets).
        if micFIFO.count > packetSamples * 3 { micFIFO.removeFirst(micFIFO.count - packetSamples) }
        if sent > 0 { statsLock.lock(); stats.microphonePacketsSent += sent; statsLock.unlock() }
    }

    func stop() {
        queue.async {
            if self.microphoneActive {
                self.engine.inputNode.removeTap(onBus: 0)
                try? self.engine.inputNode.setVoiceProcessingEnabled(false)
                self.microphoneActive = false
                self.micLock.lock(); self.micSink = nil; self.micConverter = nil; self.micLock.unlock()
                self.statsLock.lock(); self.stats.microphoneActive = false; self.statsLock.unlock()
            }
            self.engine.stop()
            // No stream any more: route changes, interruptions or layout changes must not
            // restart the engine (and re-activate the audio session) until the next stream.
            self.outputFormat = nil
            self.detachPlaybackNodes()
            self.ring?.clear()
            self.converter = nil
            self.statsLock.lock(); self.stats.running = false; self.statsLock.unlock()
            try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        }
    }

    private func handleInterruption(_ note: Notification) {
        guard let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
        switch type {
        case .began:
            vpLog(.info, "audio", "Audio interrupted")
            queue.async { self.ring?.clear() }
        case .ended:
            vpLog(.info, "audio", "Audio interruption ended; resuming")
            queue.async { self.restartEngine() }
        @unknown default:
            break
        }
    }
}
