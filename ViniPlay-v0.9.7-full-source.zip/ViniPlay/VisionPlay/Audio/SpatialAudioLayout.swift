import Foundation
import AVFoundation
import simd

/// Where the game sound comes from and how the "room" sounds.
///
/// The PS5 sends stereo only, so this does not invent real surround channels: the left and
/// right channels are placed at the left and right edges of the virtual screen, rendered
/// with head-tracked HRTF by visionOS. Optional extras: a room reverb sized to the screen,
/// and a soft rear ambience made from the stereo difference signal (upmix).
struct SpatialAudioLayout: Equatable, Sendable {
    var enabled: Bool
    var roomAcoustics: Bool
    var surroundUpmix: Bool
    /// Screen width and distance in metres (window mode uses a typical window size).
    var screenWidth: Float
    var screenDistance: Float

    static let windowDefault = SpatialAudioLayout(enabled: true, roomAcoustics: false, surroundUpmix: false,
                                                  screenWidth: 1.6, screenDistance: 1.8)

    /// Source positions in listener space (listener at the origin facing −Z).
    var leftPosition: SIMD3<Float> { SIMD3(-screenWidth * 0.42, 0, -screenDistance) }
    var rightPosition: SIMD3<Float> { SIMD3(screenWidth * 0.42, 0, -screenDistance) }
    /// Rear ambience sits behind and to the sides (±120°), 2 m away.
    var rearLeftPosition: SIMD3<Float> { SIMD3(-1.73, 0, 1.0) }
    var rearRightPosition: SIMD3<Float> { SIMD3(1.73, 0, 1.0) }

    /// Room size that matches the screen: living room for TVs, cinema for big screens, auditorium for IMAX.
    enum Room: String, Sendable {
        case livingRoom = "Living room"
        case largeRoom = "Large room"
        case cinema = "Cinema"
        case auditorium = "Auditorium"
    }

    var room: Room {
        let diagonal = ScreenSize.diagonalInches(forWidthMeters: Double(screenWidth))
        switch diagonal {
        case ..<90: return .livingRoom
        case ..<130: return .largeRoom
        case ..<300: return .cinema
        default: return .auditorium
        }
    }

    var reverbPreset: AVAudioUnitReverbPreset {
        switch room {
        case .livingRoom: return .mediumRoom
        case .largeRoom: return .largeRoom
        case .cinema: return .mediumHall
        case .auditorium: return .largeHall
        }
    }

    /// Per-source wet amount in percent: subtle, a little more for bigger rooms.
    var reverbBlend: Float {
        guard roomAcoustics else { return 0 }
        switch room {
        case .livingRoom: return 0.08
        case .largeRoom: return 0.12
        case .cinema: return 0.16
        case .auditorium: return 0.22
        }
    }

    /// Rear ambience level relative to the front (−11 dB).
    static let rearGain: Float = 0.28
}
