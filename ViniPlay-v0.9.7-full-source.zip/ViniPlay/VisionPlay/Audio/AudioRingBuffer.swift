import AVFAudio
import Foundation
import os
import AudioToolbox

/// Lock-protected interleaved Float32 ring buffer between the network/decoder thread
/// and the real-time audio render callback.
///
/// The buffer is bounded: when more than `maxLatencyFrames` are queued the oldest
/// samples are discarded so audio can never drift behind the video.
final class AudioRingBuffer: @unchecked Sendable {
    let channels: Int
    let capacityFrames: Int
    private var storage: [Float]
    private var readIndex = 0      // in frames
    private var writeIndex = 0     // in frames
    private var available = 0      // in frames
    private var lock = os_unfair_lock()

    private(set) var underruns: UInt64 = 0
    private(set) var overflowDrops: UInt64 = 0

    init(channels: Int, capacityFrames: Int) {
        precondition(channels > 0 && capacityFrames > 0)
        self.channels = channels
        self.capacityFrames = capacityFrames
        storage = [Float](repeating: 0, count: channels * capacityFrames)
    }

    var bufferedFrames: Int {
        os_unfair_lock_lock(&lock); defer { os_unfair_lock_unlock(&lock) }
        return available
    }

    /// Appends interleaved samples. If `maxLatencyFrames` would be exceeded, the oldest
    /// frames are dropped first.
    func write(interleaved samples: UnsafePointer<Float>, frames: Int, maxLatencyFrames: Int) {
        guard frames > 0 else { return }
        os_unfair_lock_lock(&lock); defer { os_unfair_lock_unlock(&lock) }
        let limit = min(maxLatencyFrames, capacityFrames)
        var framesToWrite = frames
        var source = samples
        if framesToWrite > limit {
            // Only keep the newest `limit` frames of this write.
            source = samples + (framesToWrite - limit) * channels
            overflowDrops += UInt64(framesToWrite - limit)
            framesToWrite = limit
        }
        let overflow = available + framesToWrite - limit
        if overflow > 0 {
            readIndex = (readIndex + overflow) % capacityFrames
            available -= overflow
            overflowDrops += UInt64(overflow)
        }
        storage.withUnsafeMutableBufferPointer { buffer in
            var remaining = framesToWrite
            var src = source
            while remaining > 0 {
                let chunk = min(remaining, capacityFrames - writeIndex)
                (buffer.baseAddress! + writeIndex * channels).update(from: src, count: chunk * channels)
                writeIndex = (writeIndex + chunk) % capacityFrames
                src += chunk * channels
                remaining -= chunk
            }
        }
        available += framesToWrite
    }

    /// Reads up to `frames` frames into per-channel destination buffers (deinterleaving).
    /// Missing frames are filled with silence. Returns the number of real frames read.
    @discardableResult
    func read(into channelBuffers: [UnsafeMutablePointer<Float>], frames: Int) -> Int {
        os_unfair_lock_lock(&lock); defer { os_unfair_lock_unlock(&lock) }
        let toRead = min(frames, available)
        storage.withUnsafeBufferPointer { buffer in
            var index = readIndex
            for frame in 0..<toRead {
                let base = index * channels
                for channel in 0..<min(channels, channelBuffers.count) {
                    channelBuffers[channel][frame] = buffer[base + channel]
                }
                index += 1
                if index == capacityFrames { index = 0 }
            }
        }
        if toRead < frames {
            for channel in 0..<channelBuffers.count {
                (channelBuffers[channel] + toRead).update(repeating: 0, count: frames - toRead)
            }
            if available == 0 && frames > 0 { underruns += 1 }
        }
        // Mono buffer into stereo output: duplicate.
        if channels == 1 && channelBuffers.count > 1 {
            for channel in 1..<channelBuffers.count {
                channelBuffers[channel].update(from: channelBuffers[0], count: frames)
            }
        }
        readIndex = (readIndex + toRead) % capacityFrames
        available -= toRead
        return toRead
    }

    /// Real-time-safe read straight into a deinterleaved Float32 AudioBufferList
    /// (no allocations, no Swift arrays). Used by the audio render callback.
    func read(into list: UnsafeMutableAudioBufferListPointer, frames: Int) {
        os_unfair_lock_lock(&lock); defer { os_unfair_lock_unlock(&lock) }
        let toRead = min(frames, available)
        let outputs = list.count
        storage.withUnsafeBufferPointer { buffer in
            for output in 0..<outputs {
                guard let raw = list[output].mData else { continue }
                let destination = raw.assumingMemoryBound(to: Float.self)
                let channel = min(output, channels - 1) // mono source fills every output
                var index = readIndex
                for frame in 0..<toRead {
                    destination[frame] = buffer[index * channels + channel]
                    index += 1
                    if index == capacityFrames { index = 0 }
                }
                if toRead < frames { (destination + toRead).update(repeating: 0, count: frames - toRead) }
            }
        }
        if toRead < frames && available == 0 && frames > 0 { underruns += 1 }
        readIndex = (readIndex + toRead) % capacityFrames
        available -= toRead
    }

    /// Allocation-free stereo read (mono sources are duplicated) for real-time callers.
    func readStereo(left: UnsafeMutablePointer<Float>, right: UnsafeMutablePointer<Float>, frames: Int) {
        os_unfair_lock_lock(&lock); defer { os_unfair_lock_unlock(&lock) }
        let toRead = min(frames, available)
        storage.withUnsafeBufferPointer { buffer in
            var index = readIndex
            for frame in 0..<toRead {
                let base = index * channels
                left[frame] = buffer[base]
                right[frame] = buffer[base + min(1, channels - 1)]
                index += 1
                if index == capacityFrames { index = 0 }
            }
        }
        if toRead < frames {
            (left + toRead).update(repeating: 0, count: frames - toRead)
            (right + toRead).update(repeating: 0, count: frames - toRead)
            if available == 0 && frames > 0 { underruns += 1 }
        }
        readIndex = (readIndex + toRead) % capacityFrames
        available -= toRead
    }

    func clear() {
        os_unfair_lock_lock(&lock); defer { os_unfair_lock_unlock(&lock) }
        readIndex = 0; writeIndex = 0; available = 0
    }
}
