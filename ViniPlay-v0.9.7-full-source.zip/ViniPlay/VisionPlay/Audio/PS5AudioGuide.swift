import Foundation

/// Plain-language help for getting the best sound out of the PS5 over Remote Play.
enum PS5AudioGuide {
    static let text = """
    Remote Play carries the game sound as a stereo stream. When 3D Audio is on, the PS5 renders \
    Tempest 3D AudioTech into that stereo mix for headphones, so you hear height and direction.

    On the PS5: Settings › Sound › Audio Output › turn on "Enable 3D Audio for Headphones" (and \
    run "Adjust 3D Audio Profile" if you like). Some systems only offer this while a headset is \
    selected as the output; if the option is missing, set Output Device to a headset first.

    If you use PS5 3D Audio, turn off "Sound From the Screen" here: the PS5's 3D mix expects to go \
    straight to your ears, and placing it on a virtual screen would blur it. Use "Sound From the \
    Screen" for games without 3D Audio, or when you want the sound to stay with the screen.
    """
}
