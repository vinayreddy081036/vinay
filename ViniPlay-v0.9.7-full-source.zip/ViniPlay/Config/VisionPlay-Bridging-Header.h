// Exposes the C bridge over the chiaki-ng Remote Play core to Swift.
#include "vp_bridge.h"
